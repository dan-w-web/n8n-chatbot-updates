# n8n Chatbot Widget — WordPress plugin

Read this before touching a client site. Most of it is failures that have already happened on live
sites; none of it is theoretical.

**Current version: 2.1.1.** Source is private (`dan-w-web/W-Web-N8N-Chatbot`). Updates come from a
**public** channel repo — see *Updates* below.

---

## If you are here to put the plugin on a client site

That is the common case, so it is first. Everything after this section is background.

### 1. Work out what the site already has

**Do this before anything else.** Two plugin folders can exist with the same `Plugin Name` and the
same `Update URI`, so nothing in wp-admin tells them apart, and *which one is live is inverted
between the local copy and the servers*.

```bash
ssh root@red.wwebdesign.co.uk
cd /home/<user>/public_html
ls wp-content/plugins | grep -iE 'n8n-chatbot|W-Web-N8N'
sudo -u <user> /home/<user>/bin/wp option get active_plugins --format=json | tr ',' '\n' | grep -i n8n
```

`wp` is **not** on root's PATH for these users. It is at `/home/<user>/bin/wp`. `sudo -u <user> wp`
fails with "command not found".

Possible states:

| What you find | What it means |
|---|---|
| `n8n-chatbot/` is a real directory and is in `active_plugins` | Normal. Update in place. |
| `W-Web-N8N-Chatbot-1.0.0/` is the active one | Old naming. Deactivate → rename to `n8n-chatbot` → reactivate, *then* update. |
| `n8n-chatbot` is a **dangling symlink** | An rsync copied Dan's Mac symlink up. WordPress does not list it. Delete it — but read the warning below first. |
| Nothing | Fresh install. |

### 2. Installing

**Fresh install:**

```bash
sudo -u <user> /home/<user>/bin/wp plugin install \
  https://github.com/dan-w-web/n8n-chatbot-updates/releases/latest/download/n8n-chatbot.zip \
  --activate
```

**Existing install — update:**

```bash
W=/home/<user>/bin/wp
# Plugin Update Checker caches its own answer for 12 hours in this option, and clearing
# WordPress's update_plugins transient does NOT touch it. Without this you get
# "Success: Plugin already updated." while a newer release plainly exists.
sudo -u <user> $W option delete external_updates-n8n-chatbot
sudo -u <user> $W eval 'delete_site_transient("update_plugins"); wp_update_plugins();'
sudo -u <user> $W plugin update n8n-chatbot
```

### The one action that breaks a site

**Never install by uploading the zip through Plugins → Add New when a dangling `n8n-chatbot`
symlink exists.** The zip's top-level folder is `n8n-chatbot/`, so WordPress targets that path;
`file_exists()` is false for a dangling symlink so it proceeds, clears the old folder, then
`mkdir()` fails with `EEXIST` because the symlink still owns the name. The plugin is gone and the
new one never lands.

The in-admin **Update now** path is safe: Plugin Update Checker hooks `upgrader_source_selection`
and renames the extracted folder to match the *existing* install directory. That guard fires on
**upgrade only, never on a fresh install** — which is exactly why the manual upload breaks.

Deleting the dangling symlink first removes the trap entirely.

### 3. Configure it

The plugin has **two settings stores** and picks automatically:

- **ACF path** — used when an ACF options page with the slug `fsc-site-options` exists. That slug is
  FSC-specific and filterable: `add_filter( 'n8nchat_options_page', fn() => 'my-theme-options' )`.
  Settings appear as a *Chatbot* box on that page. Values live in `options_n8nchat_*` rows.
  **`gmppolfed` does this** (`inc/acf-options.php` → `gmppf-site-options`, 2026-08-20) so the
  whole site is administered from one page — a worked example if another theme wants the same.
- **Native path** — everything else. Its own **Chatbot** admin screen. One `n8nchat_options` row.

Check which one a site is on:

```bash
sudo -u <user> $W eval 'echo n8nchat_uses_acf() ? "ACF" : "native";'
```

Minimum to make the widget appear — **`webhook_url` is the gate**; with it empty nothing renders at
all and `grep -c n8nchat` on the homepage returns 0:

| Setting | Notes |
|---|---|
| `webhook_url` | The site's **own** n8n Chat Trigger URL. Not shared between clients. |
| `enabled` | 1 |
| `title`, `greeting`, `starter_prompts` | Client wording |
| `primary_color` | Client brand hex |
| `color_scheme` | `light` or `dark` |
| `bot_id` | Only for platform-portal bots. Blank for a dedicated webhook. |

Setting them from the CLI (ACF path uses **field keys**, not names):

```bash
sudo -u <user> $W eval 'update_field("field_n8nchat_webhook_url", "https://…/chat", "option");'
```

**Never write an array into an ACF `list` field** (`starter_prompts`, `page_rules`). Use a newline
string. Writing an array used to fatal the whole options page — fixed in 2.0.7, but the newline form
is what the screen saves anyway.

### 3b. Upgrading a site that is still on 1.3.x

**None left — the whole estate is on 2.1.0 as of 2026-08-20** (`essexpolfed`, `gmppolfed` and the
`polfed.wwebdesign.dev` demo all moved that day). Kept because the failure below will recur on any
1.3.x install that resurfaces from a backup or a staging copy.

The polfed demo took the public-zip route below with no drama: it had **no**
`W_WEB_CHATBOT_UPDATE_KEY` in `wp-config.php` at all, so the private check had never worked and
`plugin list` had shown `update: none` since install. Its docroot is
`/home/polfed/polfed.wwebdesign.dev`, **not** `public_html` — `public_html` exists and is empty,
so a `--path`-less `wp` there fails with "not a WordPress installation".

**Do not rely on the token path.** The theory was that a 1.3.x install checks the *private* source
repo, so it needs a working `W_WEB_CHATBOT_UPDATE_KEY` in `wp-config.php` to see 2.1.0 at all.
In practice **gmppolfed's PAT had already expired**, which is precisely *why* it was still on
1.3.4 — the check 401s and PUC reports the site as up to date, silently. `wp plugin update` says
`Success: Plugin already updated.` and `plugin list` shows `update: none`. Clearing the PUC cache
does not help; there is nothing wrong with the cache.

Check the token before trusting it:

```bash
$W eval 'echo wp_remote_retrieve_response_code(wp_remote_get(
  "https://api.github.com/repos/dan-w-web/W-Web-N8N-Chatbot/releases/latest",
  ["headers"=>["Authorization"=>"token ".W_WEB_CHATBOT_UPDATE_KEY,"User-Agent"=>"wp"]]));'
```

`401` means the token is dead. **The fix is to skip the private channel entirely** — install
2.1.0 straight from the public channel, which needs no credential and is the same zip:

```bash
$W plugin install \
  https://github.com/dan-w-web/n8n-chatbot-updates/releases/latest/download/n8n-chatbot.zip \
  --force --activate
```

`--force` is required (wp-cli otherwise refuses to overwrite an existing folder). This is safe
**only because there is no dangling symlink** — check first; with one present it hits the same
`EEXIST` trap as an admin upload. Settings live in the `n8nchat_options` DB row, so replacing the
folder does not touch them. Once on 2.1.0 the token row is deleted from the database automatically
and the constant is never read again — remove it then, not before.

Their settings live in the **native** `n8nchat_options` row, not ACF (`n8nchat_uses_acf()` looks for
an options page slugged `fsc-site-options`, which is FSC-only). All eleven 1.x settings keep their
exact names in 2.x and carry across untouched — `tests/upgrade.php` §2b proves it against
essexpolfed's real stored blob, not a synthetic one.

What visibly changes for them:

- The widget stops loading `@n8n/chat` from jsdelivr (~355 KiB gzipped → ~8.4 KiB).
- **Stacking order** drops from an effective 9,999 to the new default 9,000. Both sites' consent
  banners sit far above that, so nothing regresses — but check the site's own nav and modals.
- Settings they never had (scheme, handoff, consent, page rules) appear at their defaults.
- **Their greeting probably renders wrong until you edit it.** 1.3.x used `@n8n/chat`'s full
  markdown library, so greetings were authored with backslash hard-breaks (`*…*\` at end of line).
  `markdown.js:111` closes emphasis on `(?=[\s.,;:!?)]|$)`, and `\` is in none of those — so the
  italic never closes *and* the backslashes render literally. Essex's greeting hit this exactly.
  Fix is content, not code: drop the `\` markers and use blank lines (newlines already become
  `<br>`/`<p>`). Check gmppolfed's greeting for the same pattern before you call the upgrade done.

Verify against the live URL afterwards, not just `wp plugin get`.

### 4. n8n side — required, and easy to forget

Each site needs its **own** Chat Trigger, and its **Allowed Origins** set to that site's URL
(include the `www.` variant). Leaving it `*` lets any website embed the bot and bill the OpenAI
account.

CORS is a **browser** control. It stops other *sites* embedding the bot; it does not stop `curl`.
The webhook URL is effectively a bearer credential — do not paste it anywhere public.

### 5. Verify — on the live URL, in a browser

Server-side checks cannot see a CORS failure or a JS error. Purge the page cache first
(`wp fastest-cache clear all` where WP Fastest Cache is active), then:

```bash
curl -s "https://<site>/?wwc=$RANDOM" | grep -o 'widget\.js?ver=[0-9.]*'   # matches installed version
curl -s "https://<site>/?wwc=$RANDOM" | grep -c 'jsdelivr'                  # must be 0 on 2.x
```

Then actually open it and send a message. There are Playwright probes in this repo's test suite
(`tests/browser/run.mjs`) worth copying for that.

**If the widget covers the site's own navigation or a modal**, lower **Advanced → Stacking order**.
The default is `9000`: above sticky headers and floating bars, below Elementor popups (9,999) and
cookie banners (99,999+). Some themes stack their own drawers far lower — FSC's is at 200 and needs
the widget on 120.

---

## Updates: no token, and nothing to configure

Since 2.1.0 client sites need **no credential**. They check a public repository that holds no source,
only the release zip:

```
PRIVATE  dan-w-web/W-Web-N8N-Chatbot      source, history, tests
   |  release.yml builds the zip, then pushes dist/ + the tag over SSH
   |  using deploy key MIRROR_DEPLOY_KEY
   v
PUBLIC   dan-w-web/n8n-chatbot-updates    README + dist/ only
   |  its own publish.yml fires on that tag and creates the release
   v
client sites — Plugin Update Checker, anonymous
```

Before 2.1.0 every site held a live GitHub PAT in `wp-config.php` or the database. It expired, and
when it did the failure was **silent** — the check returned nothing and the Plugins screen showed
the site as up to date.

**Upgrading a 2.0.x site:** the stored token is deleted on the next admin request. A
`W_WEB_CHATBOT_UPDATE_KEY` constant left in `wp-config.php` is never read again and can be removed.
**The PATs can now be revoked** — as of 2026-08-20 no site uses one. Both `essexpolfed` and
`gmppolfed` had their `W_WEB_CHATBOT_UPDATE_KEY` line removed from `wp-config.php` that day, with
backups under `/home/<user>/chatbot-backups/`. gmppolfed's PAT was already expired when it was
removed. Anything still on 1.3.x cannot use the old path either — see §3b for the public-zip route.

A deploy key, not a PAT, because deploy keys do not expire. The chain works because a push
authenticated with `GITHUB_TOKEN` does not trigger workflows but one authenticated with a deploy
key does.

---

## Cutting a release (maintainer)

1. Bump the version in **two** places in `n8n-chatbot.php` — the `Version:` header and
   `N8NCHAT_VERSION`. CI hard-fails when tag, header and constant disagree.
2. Commit, push, then `gh release create vX.Y.Z`.
3. CI builds, attaches the zip here, and mirrors it to the public channel. **The mirror step is what
   client sites see** — it is deliberately not `continue-on-error`.

Two frictions that recur:

- Commit signing is 1Password SSH and locks periodically ("failed to fill whole buffer"). Ask Dan to
  unlock and retry; nothing is lost. If the lock desyncs tag and header, CI fails the release and
  attaches no asset — which is the guard working.
- `git push` 404s on the private repo unless the credential helper list is **reset** first:
  `git -c credential.helper= -c credential.helper='!gh auth git-credential' push origin main`

---

## Traps worth knowing before you change anything

**Assets are served `Cache-Control: max-age=31536000` — a year.** Every asset URL must carry
`?ver=`. `widgetUrl` did not, and 2.0.1 and 2.0.2 both shipped JavaScript that never ran on the live
site; the CSS half working disguised it. A static `import './x.js'` also **drops its parent's query
string**, so `widget.js` re-attaches it from `import.meta.url`. To check a fix actually landed,
fetch the URL the page prints and grep the response for something only the new build has —
`cf-cache-status: HIT` with an old `last-modified` is the tell. Purging WP Fastest Cache does not
touch it.

**`display` beats `[hidden]`.** Three separate bugs in this stylesheet have been an author
`display:` rule overriding the user-agent `[hidden] { display: none }`, or overriding an earlier
rule by source order. If you add a `display` to a shared class, check what else uses it.

**Reading a settings blob off a live site:** `wp db query` mangles it — greetings contain real
newlines, so the TSV output truncates and `unserialize()` fails partway. Use
`wp eval 'echo base64_encode(serialize(get_option("n8nchat_options")));'`.

**The plugin can take down the host theme's options page.** A PHP fatal inside one metabox kills
every metabox rendered after it, and nothing reaches the error log because the response has already
been sent. If a client reports "Site Options only shows X", render the groups directly:

```bash
sudo -u <user> $W eval '
$g = acf_get_field_group("group_n8nchat");
ob_start(); try { acf_render_fields(acf_get_fields($g), "options", "div", "label"); }
catch (\Throwable $e) { echo "ERROR: ".$e->getMessage(); } $h = ob_get_clean();
echo strlen($h)." bytes\n";'
```

---

## Testing

Eight suites, **647 assertions**, no dependencies beyond the PHP and Node already on the machine:

```bash
for t in tests/*.php; do php "$t"; done
for t in tests/*.mjs; do node "$t"; done
node tests/browser/run.mjs                 # needs Playwright; ~2 min, longer than the default timeout
WWC_ENGINE=webkit node tests/browser/run.mjs
```

`node tests/browser/run.mjs "some title"` runs one test. The browser suite mocks the Chat Trigger
inside a host page whose CSS deliberately attacks the widget.

**Tests here assert consequences, not implementation.** Several bugs shipped precisely because a
test asserted the defect as the requirement — the action-bar test asserted every button was
`disabled` after a rating, which is what the bug did. If a test fails after a deliberate change,
check whether it was testing the right thing before you edit it.

---

## Not implemented

**Structured replies** (quick replies, cards) need an agreed change to what the n8n workflow emits,
so they are a platform-repo decision as much as a plugin one. Same for per-reply follow-up chips.
File upload and voice input were **removed** in 2.0 — they had settings that were wired to nothing.
