<?php
/**
 * The live preview: a self-contained document that boots the REAL widget against a mock backend.
 *
 * There is exactly one way to know what a brand colour, a corner radius or a greeting will look
 * like, and that is to render the thing itself. So this is not a drawing of the widget — it is
 * assets/boot.js and assets/widget/widget.js, unmodified, given a configuration built by the same
 * n8nchat_boot_config() the front end uses, inside an iframe on the settings screen.
 *
 * IT MUST NEVER TALK TO THE CUSTOMER'S WORKFLOW. Every message sent in this preview would otherwise
 * be one n8n execution and one round of OpenAI tokens billed to the client, spent by an
 * administrator dragging a colour picker. Three independent things stop that, because one would be
 * a single point of failure for somebody else's money:
 *
 *   1. The configuration's webhook is replaced with a URL on the `.invalid` TLD, which RFC 2606
 *      guarantees can never resolve. Even a total failure of everything below produces a DNS error,
 *      not a request to a real host.
 *   2. `fetch` is replaced inside the frame before the widget loads, and answers the canned NDJSON
 *      stream below instead. It intercepts EVERY request, not just the webhook, so the lead-capture
 *      and transcript-email endpoints in inc/rest.php cannot fire either — a preview that emailed a
 *      client's inbox would be a support call, not a feature.
 *   3. The document is served with `connect-src 'none'`, so the browser itself refuses any XHR,
 *      fetch, WebSocket or beacon the frame attempts.
 *
 * It must also leave no trace in the administrator's browser. The widget keeps the visitor's session
 * id, transcript and open state in localStorage, and wp-admin is the same origin as the front end —
 * so an unmodified preview would adopt, rewrite, and (with "remember a conversation for" set to 0)
 * actively PURGE the state belonging to the administrator's own visits to the live site. Storage is
 * therefore replaced with an in-memory object before the widget boots.
 *
 * Reachable only by a logged-in administrator holding a valid nonce, and only on the native settings
 * path — the same gate as the screen itself. See inc/admin/page.php.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** The nonce action shared by the preview document and its configuration endpoint. */
if ( ! defined( 'N8NCHAT_PREVIEW_NONCE' ) ) { define( 'N8NCHAT_PREVIEW_NONCE', 'n8nchat_preview' ); }

/**
 * A host that cannot exist.
 *
 * `.invalid` is reserved by RFC 2606 precisely so that a name can be guaranteed not to resolve.
 * Using it rather than, say, "https://example.com/" means the worst case if the fetch interceptor
 * is ever bypassed is a DNS failure the widget renders as its own error message — never a request
 * to a real server, and never one that could be mistaken for the customer's own.
 */
function n8nchat_preview_endpoint( $path = 'webhook' ) {
	return 'https://preview.n8n-chatbot.invalid/' . $path;
}

/** The preview document's URL, nonce included. */
function n8nchat_preview_url() {
	return add_query_arg(
		[
			'action'   => 'n8nchat_preview',
			'_wpnonce' => wp_create_nonce( N8NCHAT_PREVIEW_NONCE ),
		],
		admin_url( 'admin-post.php' )
	);
}

/**
 * The gate both endpoints share.
 *
 * Three checks, and all three are load-bearing. The capability check is the one that matters — this
 * document prints the site's webhook URL, which is the address of the customer's bot. The nonce
 * stops a third-party page from framing it inside a logged-in administrator's browser and reading
 * the settings out of it. And the ACF check keeps the promise the rest of the screen makes: on a
 * site whose settings live on somebody else's options page, none of this exists.
 */
function n8nchat_preview_gate() {
	if ( n8nchat_uses_acf() ) {
		wp_die( esc_html__( 'The chatbot preview is not available on this site.', 'n8n-chatbot' ), 403 );
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to preview the chatbot.', 'n8n-chatbot' ), 403 );
	}
	check_admin_referer( N8NCHAT_PREVIEW_NONCE );
}

/**
 * The widget configuration, hardened for the preview.
 *
 * Built by calling the real n8nchat_boot_config() and then overriding — in that order, deliberately.
 * A site is entitled to filter `n8nchat_boot_config`, and a filter that reinstated the real webhook
 * would turn every preview into a billed workflow run. Overriding afterwards means the mock always
 * wins, whatever anybody hooks.
 */
function n8nchat_preview_boot_config( $s ) {
	$config = n8nchat_boot_config( $s );

	$config['webhook'] = n8nchat_preview_endpoint( 'webhook' );
	$config['restUrl'] = n8nchat_preview_endpoint( 'rest' );

	// Its own storage namespace, so that even if the in-memory shim below fails to install on some
	// browser, the preview writes beside the real widget's state rather than over it.
	$config['sessionKey']  = 'n8n-chat/preview/sessionId';
	$config['scope']       = 'preview';
	$config['scopeStrict'] = false;

	/*
	 * Three settings are overridden because they govern the visitor's browser, and the preview has
	 * no visitor.
	 *
	 * A zero TTL, or a consent mode still waiting for a signal that will never arrive on an admin
	 * screen, both make the widget refuse to persist — and the preview re-mounts the widget on every
	 * settings change, so a sample conversation would evaporate the moment the administrator touched
	 * another field. None of the three changes a single pixel of what is being previewed.
	 */
	$config['storage']['ttl']         = 3600 * 1000;
	$config['storage']['consentMode'] = 'off';
	$config['storage']['consentKey']  = '';

	/*
	 * The teaser is the one piece of behaviour a preview cannot show honestly at its real setting: a
	 * 45-second dwell before it appears is correct on a live site and useless on a screen somebody is
	 * looking at for ten. The delay is cut to a beat and the per-visit cap lifted, so that closing
	 * the chat window in the preview toolbar shows the teaser straight away and shows it again after
	 * the next change. The delay and cap the site actually chose are untouched in the settings.
	 */
	if ( ! empty( $config['teaser']['enabled'] ) ) {
		$config['teaser']['delay']  = 1;
		$config['teaser']['scroll'] = 0;
		$config['teaser']['max']    = 99;
	}

	return $config;
}

/**
 * The canned reply, as Markdown.
 *
 * Deliberately not "Hello! How can I help?". The point of a preview is to show the widget carrying a
 * REAL answer, so this exercises every block the renderer supports and the site owner is likely to
 * meet: emphasis, a bullet list, a table and a link. Those are also the four things most likely to
 * look wrong at a given corner radius, density or window width — a table is what discovers that a
 * 320px window is too narrow, and nothing else in the widget does.
 */
function n8nchat_preview_reply() {
	$reply = implode(
		"\n",
		[
			__( 'Yes — **membership is open all year**, and which level you want depends on how many people you need to cover.', 'n8n-chatbot' ),
			'',
			__( 'The three levels are:', 'n8n-chatbot' ),
			'',
			__( '- **Individual** — one named person', 'n8n-chatbot' ),
			__( '- **Corporate** — up to 25 named people, plus a seat on the technical committee', 'n8n-chatbot' ),
			__( '- *Associate* — for suppliers and consultants', 'n8n-chatbot' ),
			'',
			__( '| Level | Annual fee | Votes |', 'n8n-chatbot' ),
			'| --- | --- | --- |',
			__( '| Individual | £95 | 1 |', 'n8n-chatbot' ),
			__( '| Corporate | £480 | 3 |', 'n8n-chatbot' ),
			__( '| Associate | £250 | 0 |', 'n8n-chatbot' ),
			'',
			__( 'The full terms are on the [membership page](https://example.com/membership). Shall I put you through to somebody who can take you through it?', 'n8n-chatbot' ),
		]
	);

	/**
	 * Filter the preview's canned reply.
	 *
	 * @param string $reply Markdown, streamed to the preview widget as if it came from n8n.
	 */
	return (string) apply_filters( 'n8nchat_preview_reply', $reply );
}

/** The question the "Play a sample reply" button types into the preview. */
function n8nchat_preview_question() {
	return (string) apply_filters( 'n8nchat_preview_question', __( 'Can I still join this year?', 'n8n-chatbot' ) );
}

/**
 * JSON for embedding in an inline <script>.
 *
 * wp_json_encode() alone is not enough here. The HTML tokenizer ends a <script> block at the first
 * literal "</script" whatever the JavaScript around it is doing, so a settings value containing that
 * string would break out of the block entirely. JSON_HEX_TAG escapes every angle bracket as a
 * six-character unicode sequence, which JavaScript reads identically and the HTML tokenizer cannot
 * see at all. The other three flags close the same door on `&`, `'` and `"` for anything that
 * later lands in an attribute.
 */
function n8nchat_preview_json( $value ) {
	return wp_json_encode( $value, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
}

/**
 * Configuration for a form that has not been saved yet.
 *
 * The screen posts its whole form here on every change and gets back exactly what the widget would
 * boot from if that form were saved — which means the preview is running the real sanitiser and the
 * real reader, not an approximation of them. The alternative, rebuilding the config shape in
 * JavaScript, would be a second copy of n8nchat_boot_config() to keep in step with the first; this
 * plugin has been bitten by a second copy of a rule before, and the fix was to delete it.
 */
add_action( 'wp_ajax_n8nchat_preview_config', function () {
	if ( n8nchat_uses_acf() ) { wp_send_json_error( [ 'message' => 'unavailable' ], 403 ); }
	if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( [ 'message' => 'forbidden' ], 403 ); }
	check_ajax_referer( N8NCHAT_PREVIEW_NONCE, 'nonce' );

	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- check_ajax_referer above.
	$posted = isset( $_POST[ N8NCHAT_OPTION ] ) && is_array( $_POST[ N8NCHAT_OPTION ] )
		? wp_unslash( $_POST[ N8NCHAT_OPTION ] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitised on the next line by the plugin's own sanitiser.
		: [];

	// The two halves of a save, in the same order a save applies them: sanitise the submission, then
	// resolve it through the reader's empty-means-default rules. Run the other way round, a blank
	// non-blankable field would preview as blank and then save as its default.
	$settings = n8nchat_resolve_settings( n8nchat_sanitize_options( $posted ) );

	wp_send_json_success( [
		'config' => n8nchat_preview_boot_config( $settings ),
		'css'    => n8nchat_theme_css( $settings, '#n8nchat-host' ),
		'scheme' => $settings['color_scheme'],
	] );
} );

/**
 * The preview document.
 */
add_action( 'admin_post_n8nchat_preview', 'n8nchat_render_preview_document' );

function n8nchat_render_preview_document() {
	n8nchat_preview_gate();

	$settings = n8nchat_settings();
	$config   = n8nchat_preview_boot_config( $settings );

	/*
	 * A content policy for the frame, on top of the sandbox attribute the parent sets.
	 *
	 * `connect-src 'none'` is the important line: it is the browser, rather than our own interceptor,
	 * refusing to let this document reach the customer's n8n instance. `form-action 'none'` and
	 * `base-uri 'none'` close the two ways a stray bit of markup could still exfiltrate what is on
	 * the page. Images are allowed from anywhere over https because the launcher icon and the
	 * assistant avatar are free-form URLs pointing at whatever the site uses.
	 *
	 * The plugin's own origin is added to script-src and style-src explicitly rather than relying on
	 * 'self': plugin_dir_url() follows WP_CONTENT_URL, and a site serving wp-content from a CDN
	 * domain would otherwise have the widget module blocked here and nowhere else.
	 */
	$asset_origin = '';
	$parts        = wp_parse_url( N8NCHAT_URL );
	if ( ! empty( $parts['scheme'] ) && ! empty( $parts['host'] ) ) {
		$asset_origin = ' ' . $parts['scheme'] . '://' . $parts['host'] . ( empty( $parts['port'] ) ? '' : ':' . (int) $parts['port'] );
	}

	nocache_headers();
	header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
	header( 'X-Robots-Tag: noindex, nofollow', true );
	header( 'X-Content-Type-Options: nosniff', true );
	header(
		"Content-Security-Policy: default-src 'none'; "
		. "script-src 'self' 'unsafe-inline'" . $asset_origin . '; '
		. "style-src 'self' 'unsafe-inline'" . $asset_origin . '; '
		. "img-src 'self' data: https:; font-src 'self' data:; "
		. "connect-src 'none'; form-action 'none'; base-uri 'none'; frame-ancestors 'self'",
		true
	);
	send_frame_options_header();

	$lang = get_bloginfo( 'language' );
	$dir  = is_rtl() ? 'rtl' : 'ltr';

	?>
<!DOCTYPE html>
<html lang="<?php echo esc_attr( $lang ); ?>" dir="<?php echo esc_attr( $dir ); ?>">
<head>
<meta charset="<?php echo esc_attr( get_option( 'blog_charset' ) ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<title><?php esc_html_e( 'Chat widget preview', 'n8n-chatbot' ); ?></title>
<style>
/*
 * A mock page for the widget to sit on.
 *
 * Kept resolutely light, and kept that way even when a dark widget is being previewed. That is not
 * an oversight — it is the whole argument the colour-scheme setting makes. Almost every WordPress
 * site this plugin runs on is light-only, so a widget set to follow the visitor's device really does
 * end up dark on a light page, and the only way to make that decision informed is to show it.
 */
:root { color-scheme: light; }
* { box-sizing: border-box; }
html, body { height: 100%; }
body {
	margin: 0;
	background: #f6f7f9;
	color: #1a1d21;
	font: 400 15px/1.6 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
	overflow: hidden; /* the widget is position:fixed; a scrollbar here would only ever be noise */
}
.mock { padding: 0 24px 24px; max-width: 720px; }
.mock-bar {
	display: flex; align-items: center; gap: 10px;
	margin: 0 -24px 26px; padding: 14px 24px;
	background: #fff; border-bottom: 1px solid #e7e9ee;
}
.mock-logo { width: 26px; height: 26px; border-radius: 7px; background: #d7dae0; }
.mock-logo + span { width: 96px; height: 9px; border-radius: 5px; background: #d7dae0; }
.mock-nav { margin-inline-start: auto; display: flex; gap: 14px; }
.mock-nav i { display: block; width: 46px; height: 8px; border-radius: 4px; background: #e2e5ea; }
.mock h1 { margin: 0 0 14px; font-size: 26px; line-height: 1.25; color: #b9bec6; letter-spacing: -0.01em; }
.mock p { margin: 0 0 12px; }
.mock i { display: block; height: 10px; border-radius: 5px; background: #e2e5ea; margin-bottom: 9px; }
.mock i.s { width: 62%; }
.mock i.m { width: 84%; }
.mock .card { margin-top: 22px; padding: 18px; background: #fff; border: 1px solid #e7e9ee; border-radius: 12px; }
@media (prefers-reduced-motion: reduce) { * { animation: none !important; transition: none !important; } }
</style>
<style id="n8nchat-theme"><?php echo n8nchat_theme_css( $settings, '#n8nchat-host' ); // phpcs:ignore WordPress.Security.EscapeOutput -- every value is escaped by n8nchat_tokens_declarations(). ?></style>
<?php
/*
 * The live override, empty until the settings screen sends one.
 *
 * It exists as a SECOND stylesheet after the first rather than as inline styles on the host element,
 * because the accent tokens differ between the light and dark themes and an inline style cannot
 * express a media query. Appending a block that mirrors what n8nchat_theme_css() emits keeps the
 * override honest in all three colour-scheme settings; a `style.setProperty()` would have silently
 * pinned the light-theme value in dark mode.
 */
?>
<style id="n8nchat-theme-live"></style>
</head>
<body>

<div class="mock" aria-hidden="true">
	<div class="mock-bar"><span class="mock-logo"></span><span></span><span class="mock-nav"><i></i><i></i><i></i></span></div>
	<h1><?php esc_html_e( 'Your page', 'n8n-chatbot' ); ?></h1>
	<p><i></i><i class="m"></i><i class="s"></i></p>
	<div class="card"><i></i><i class="m"></i><i class="s"></i></div>
	<p style="margin-top:22px"><i class="m"></i><i></i><i class="s"></i></p>
</div>

<script>
/*
 * Everything below runs BEFORE assets/boot.js is inserted, which is the only order in which any of
 * it works: the widget captures window.N8NCHAT and calls fetch() and localStorage from module scope.
 */
(function () {
	'use strict';

	var ORIGIN   = <?php echo n8nchat_preview_json( n8nchat_admin_origin() ); ?>;
	var BOOT     = <?php echo n8nchat_preview_json( N8NCHAT_URL . 'assets/boot.js?ver=' . rawurlencode( N8NCHAT_VERSION ) ); ?>;
	var MOCK     = <?php echo n8nchat_preview_json( n8nchat_preview_endpoint( '' ) ); ?>;
	var REPLY    = <?php echo n8nchat_preview_json( n8nchat_preview_reply() ); ?>;
	var QUESTION = <?php echo n8nchat_preview_json( n8nchat_preview_question() ); ?>;

	window.N8NCHAT = <?php echo n8nchat_preview_json( $config ); ?>;

	/* ------------------------------------------------------------------ storage
	 *
	 * wp-admin and the front end are the same origin, so an unmodified widget previewing here reads
	 * and writes the very keys the administrator's own visits to the live site use. Two of those
	 * writes are destructive: claiming the session slot for a different scope DELETES the stored
	 * conversation, and a site with "remember a conversation for" set to 0 makes boot.js purge every
	 * key it knows about outright. Neither is acceptable as a side effect of opening a settings page.
	 *
	 * Replaced rather than namespaced because namespacing cannot help: boot.js keeps the scope-owner
	 * key deliberately UNscoped, so the preview would still reach it. The shim also survives a
	 * re-mount, which is what keeps a sample conversation on screen while settings are being changed.
	 */
	var mem = {};
	var shim = {
		getItem: function (k) { return Object.prototype.hasOwnProperty.call(mem, k) ? mem[k] : null; },
		setItem: function (k, v) { mem[k] = String(v); },
		removeItem: function (k) { delete mem[k]; },
		clear: function () { mem = {}; },
		key: function (i) { var keys = Object.keys(mem); return i < keys.length ? keys[i] : null; }
	};
	Object.defineProperty(shim, 'length', { get: function () { return Object.keys(mem).length; } });
	try {
		Object.defineProperty(window, 'localStorage', { value: shim, configurable: true });
		Object.defineProperty(window, 'sessionStorage', { value: shim, configurable: true });
	} catch (e) {
		// A browser that will not let the property be shadowed still gets a working preview: the
		// config above puts the session under its own key, so the worst case is a few stray entries
		// rather than the destructive rewrite this shim exists to prevent.
	}

	/* ------------------------------------------------------------------ the mock backend */

	var encoder = new TextEncoder();

	/**
	 * The canned reply as n8n would actually send it.
	 *
	 * Streaming responses are newline-delimited JSON: one `begin`, many `item`s, one `end`, all
	 * carrying the same nodeId and runIndex so the widget groups them into a single bubble. Chunking
	 * mid-word is not sloppiness — a language model emits tokens, not sentences, and rendering
	 * Markdown that is half-arrived is exactly the case the widget's streaming renderer exists for.
	 */
	function lines() {
		var meta = { nodeId: 'preview', nodeName: 'AI Agent', runIndex: 0 };
		var out = [JSON.stringify({ type: 'begin', metadata: meta })];
		var chunks = REPLY.match(/[\s\S]{1,16}/g) || [];
		for (var i = 0; i < chunks.length; i++) {
			out.push(JSON.stringify({ type: 'item', content: chunks[i], metadata: meta }));
		}
		out.push(JSON.stringify({ type: 'end', metadata: meta }));
		return out;
	}

	function stream(signal) {
		var body = new ReadableStream({
			start: function (controller) {
				var queue = lines();
				var i = 0;
				var timer = null;
				var stopped = false;

				function abort() {
					if (stopped) { return; }
					stopped = true;
					clearTimeout(timer);
					// The widget's stop button aborts the fetch; with a mocked response the fetch
					// promise has already resolved, so the abort has to reach the reader instead or
					// reader.read() would simply never settle and the composer would stay locked.
					try { controller.error(new DOMException('Aborted', 'AbortError')); } catch (e) {}
				}
				if (signal) {
					if (signal.aborted) { abort(); return; }
					signal.addEventListener('abort', abort);
				}

				(function push() {
					if (stopped) { return; }
					if (i >= queue.length) { controller.close(); return; }
					controller.enqueue(encoder.encode(queue[i++] + '\n'));
					timer = setTimeout(push, 22);
				})();
			}
		});

		// A beat before the first byte, so the typing indicator is part of what gets previewed. A
		// reply that appears instantly is the one thing a real RAG workflow never does.
		return new Promise(function (resolve) {
			setTimeout(function () {
				resolve(new Response(body, { status: 200, headers: { 'Content-Type': 'application/json' } }));
			}, 420);
		});
	}

	/**
	 * Every request, without exception.
	 *
	 * Not just the webhook: inc/rest.php gives the widget lead-capture and transcript-email
	 * endpoints, and a preview that posted to those would send a real email to the site's real
	 * inbox — from a screen the administrator thinks is a drawing.
	 */
	window.fetch = function (input, init) {
		var url = typeof input === 'string' ? input : (input && input.url) || '';
		var signal = (init && init.signal) || (input && input.signal) || null;
		if (url.indexOf(MOCK + 'webhook') === 0) { return stream(signal); }
		return Promise.resolve(new Response('{"ok":true}', {
			status: 200,
			headers: { 'Content-Type': 'application/json' }
		}));
	};
	// sendBeacon has no interceptor of its own and would bypass the one above entirely.
	if (navigator.sendBeacon) { navigator.sendBeacon = function () { return true; }; }

	/* ------------------------------------------------------------------ mounting */

	var script = null;
	var wanted = { open: true, scheme: '' };

	function host() { return document.getElementById('n8nchat-host'); }

	/**
	 * Apply the preview-only view state to a freshly mounted widget.
	 *
	 * The scheme branch mirrors what boot.js does with the same value, because clearing an override
	 * has to put the host back to whatever the SETTING says rather than to no attribute at all —
	 * "as set" on a site configured "Always dark" means dark, not auto.
	 */
	function applyState() {
		var el = host();
		if (!el) { return; }
		var scheme = wanted.scheme || (window.N8NCHAT.ui || {}).scheme;
		if (scheme === 'light' || scheme === 'dark') { el.setAttribute('data-wwc-scheme', scheme); }
		else { el.removeAttribute('data-wwc-scheme'); }

		if (!window.n8nChatbot) { return; }
		try { wanted.open ? window.n8nChatbot.open() : window.n8nChatbot.close(); } catch (e) {}
	}

	/**
	 * Re-mount the widget from a new configuration.
	 *
	 * boot.js refuses to run twice against the same host element, so the old one is removed first and
	 * the script re-inserted — inserting a <script> element executes it again, from cache, with no
	 * network. The close() first is not tidiness: the widget registers a document-level keydown
	 * handler for Escape and the focus trap, and an instance discarded while it still believes it is
	 * open would go on answering keystrokes from behind the new one.
	 */
	function remount(config, css) {
		// destroy() rather than close(): closing hides the window but leaves the document keydown
		// handler, the matchMedia listener, the teaser's scroll listener and the consent poll in
		// place, and this function runs on every edit. Falls back to close() so a preview served
		// against an older widget still does what it can.
		if (window.n8nChatbot) {
			try { (window.n8nChatbot.destroy || window.n8nChatbot.close)(); } catch (e) {}
		}
		var old = host();
		if (old) { old.parentNode.removeChild(old); }
		if (script) { script.parentNode.removeChild(script); script = null; }

		if (config) { window.N8NCHAT = config; }
		if (typeof css === 'string') {
			document.getElementById('n8nchat-theme').textContent = css;
			// The server has now said the last word on the theme, so the client-side stand-in that
			// was covering the round trip has to go — otherwise it would keep overriding a value the
			// administrator has since changed back.
			document.getElementById('n8nchat-theme-live').textContent = '';
		}

		script = document.createElement('script');
		script.src = BOOT;
		script.onload = function () { setTimeout(applyState, 0); };
		document.body.appendChild(script);
	}

	/* ------------------------------------------------------------------ the live theme override
	 *
	 * The settings screen derives the brand colours in the browser — it has to, because the same
	 * arithmetic draws the contrast readout beside the picker — and sends the five resulting values
	 * here. Assembling the stylesheet is done at THIS end, because whether a dark block should be
	 * emitted at all depends on the colour scheme, and this is the end that holds the configuration.
	 *
	 * The structure below mirrors n8nchat_theme_css() exactly, including emitting the dark half
	 * twice under "auto": once behind prefers-color-scheme for the visitor's own setting, and once
	 * behind the attribute so that forcing a scheme wins in BOTH directions, which one media query
	 * cannot do.
	 *
	 * Every value is checked against a hex pattern before it reaches a declaration. These arrive over
	 * postMessage, and a stylesheet built by string concatenation from a message is exactly the kind
	 * of seam that is safe right up until somebody adds a second sender.
	 */
	function hex(value) {
		return /^#[0-9a-f]{6}$/i.test(String(value)) ? String(value) : '';
	}

	function rgb(value) {
		return [1, 3, 5].map(function (i) { return parseInt(value.substr(i, 2), 16); }).join(', ');
	}

	function liveTheme(t) {
		if (!t) { return ''; }
		var accent = hex(t.accent);
		var ink = hex(t.ink);
		var hover = hex(t.hover);
		var inkLight = hex(t.inkLight);
		var inkDark = hex(t.inkDark);
		if (!accent || !ink || !hover || !inkLight || !inkDark) { return ''; }

		var at = '#n8nchat-host';
		var common = '--wwc-accent:' + accent + ';--wwc-accent-rgb:' + rgb(accent) +
			';--wwc-accent-hover:' + hover + ';--wwc-on-accent:' + ink +
			';--wwc-on-accent-rgb:' + rgb(ink) + ';';

		var css = at + '{' + common + '--wwc-accent-ink:' + inkLight + '}';
		var scheme = (window.N8NCHAT.ui || {}).scheme;
		if (scheme === 'dark') {
			css += at + '{--wwc-accent-ink:' + inkDark + '}';
		} else if (scheme === 'auto') {
			css += '@media (prefers-color-scheme: dark){' + at + ':not([data-wwc-scheme="light"]){--wwc-accent-ink:' + inkDark + '}}';
			css += at + '[data-wwc-scheme="dark"]{--wwc-accent-ink:' + inkDark + '}';
		}
		return css;
	}

	/**
	 * Type the sample question into the widget and send it, exactly as a visitor would.
	 *
	 * Sent with an Enter keypress rather than by submitting the composer's form, and the reason is
	 * the sandbox: `form.requestSubmit()` enters the form-submission algorithm, which a frame
	 * without `allow-forms` is not permitted to do, so the browser blocks it before the widget's own
	 * submit listener ever runs — "Blocked form submission because the form's frame is sandboxed",
	 * and a demo button that silently does nothing. Adding allow-forms to make a form we never
	 * intend to submit submittable would be fixing it from the wrong end.
	 *
	 * Enter is also simply what a visitor presses.
	 */
	function demo() {
		var el = host();
		if (!el || !el.shadowRoot) { return; }
		wanted.open = true;
		applyState();
		setTimeout(function () {
			var field = el.shadowRoot.querySelector('form textarea');
			if (!field) { return; }
			field.value = QUESTION;
			// The send button is disabled until the composer has content, and it is an `input`
			// listener that enables it — so setting .value alone would send nothing.
			field.dispatchEvent(new Event('input', { bubbles: true }));
			field.dispatchEvent(new KeyboardEvent('keydown', {
				key: 'Enter', bubbles: true, cancelable: true
			}));
		}, 260);
	}

	/* ------------------------------------------------------------------ the channel */

	window.addEventListener('message', function (event) {
		// Same-origin only. The frame is sandboxed and this document contains nothing secret, but a
		// listener that acts on any message from any frame is a habit worth not having.
		if (ORIGIN && event.origin !== ORIGIN) { return; }
		var data = event.data;
		if (!data || data.ns !== 'n8nchat') { return; }

		switch (data.type) {
			case 'theme':
				document.getElementById('n8nchat-theme-live').textContent = liveTheme(data.tokens);
				break;
			case 'config':
				remount(data.config, data.css);
				break;
			case 'scheme':
				wanted.scheme = (data.value === 'light' || data.value === 'dark') ? data.value : '';
				applyState();
				break;
			case 'open':
				wanted.open = !!data.value;
				/*
				 * Closing re-mounts; opening does not.
				 *
				 * The teaser is armed once, when the widget boots, and refuses to appear while the
				 * window is open — which in the preview it always is, so simply closing the window
				 * would show a launcher and never the teaser the administrator has just switched on.
				 * Booting again with the window shut arms it against a closed widget, which is the
				 * only state a real visitor ever sees it in. Opening needs none of that.
				 */
				if (wanted.open) { applyState(); } else { remount(null, null); }
				break;
			case 'demo':
				demo();
				break;
		}
	});

	remount(null, null);

	// The screen may hold edits that were never saved, and this document was rendered from the store.
	// Announcing readiness rather than assuming it is also what makes the widget's own "New chat"
	// button — which reloads the frame — come back with the administrator's unsaved values.
	if (window.parent !== window) {
		window.parent.postMessage({ ns: 'n8nchat', type: 'ready' }, ORIGIN || '*');
	}
})();
</script>
</body>
</html>
	<?php
	exit;
}
