<?php
/**
 * The native settings screen: one tab per schema group, with a live preview of the real widget
 * beside it.
 *
 * This replaces the flat Settings-API form that used to live in inc/native-settings.php. Fifty
 * fields in one column is not a screen anybody can use — the previous arrangement asked a site
 * owner to scroll past the whole of Appearance to reach the webhook that decides whether anything
 * renders at all, and gave no way to see what a brand colour or a corner radius would look like
 * short of saving and loading the front end.
 *
 * WHAT IS DELIBERATELY UNCHANGED, and why it matters more than the layout:
 *
 * This is a PRESENTATION change and nothing else. The form still posts to options.php, still calls
 * settings_fields() for its nonce and its option_page, and is still saved by the very same
 * n8nchat_sanitize_options() registered in inc/native-settings.php. Nothing here writes an option,
 * and nothing here decides what a value means. A settings screen that quietly acquired its own save
 * path would be a second sanitiser to keep in step with the first, which is precisely the class of
 * drift this plugin has already been bitten by.
 *
 * EVERYTHING IS GENERATED FROM inc/schema.php. There is not one settings name typed into this file
 * — not in the markup, not in the CSS, not in the JavaScript. The tabs are n8nchat_groups(), the
 * fields are n8nchat_group_fields(), the preset cards are n8nchat_presets(), and where the screen
 * needs to single a field out (the colour readout belongs beside the one `color` field; the preset
 * cards belong on whichever tab owns `preset`) it asks the schema which field that is rather than
 * naming it. Adding a setting still means editing the schema and nothing else.
 *
 * TABS WITHOUT JAVASCRIPT. Every panel is rendered on every request and the inactive ones carry
 * `hidden`; a `?tab=` query argument chooses which. That is not only for the no-JS case. Hidden
 * inputs are still submitted, and they MUST be: n8nchat_sanitize_options() rebuilds the option from
 * the schema, so a form that posted only the visible tab's fields would blank every setting on the
 * other five tabs on every save. Rendering one tab at a time is the obvious implementation and it
 * would silently destroy a site's configuration.
 *
 * The ACF path is untouched. Every hook below returns early when n8nchat_uses_acf() is true, so on
 * a site whose settings live on somebody else's ACF options page this screen does not exist —
 * no menu, no sections, no assets, and (see inc/admin/preview.php) no preview endpoint either.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** The admin page slug, and the group query argument the tabs use. */
if ( ! defined( 'N8NCHAT_ADMIN_SLUG' ) ) { define( 'N8NCHAT_ADMIN_SLUG', 'n8n-chatbot' ); }

/**
 * Register the top-level "Chatbot" menu (native path only).
 *
 * Moved here from inc/native-settings.php along with the rest of the screen. It is registered in
 * exactly one place; two add_menu_page() calls with the same slug produce one menu whose callback
 * is whichever registration ran last, which is the sort of bug that is invisible until somebody
 * wonders why their edits to a settings page have no effect.
 */
add_action( 'admin_menu', function () {
	if ( n8nchat_uses_acf() ) { return; }

	add_menu_page(
		__( 'Chatbot', 'n8n-chatbot' ),
		__( 'Chatbot', 'n8n-chatbot' ),
		'manage_options',
		N8NCHAT_ADMIN_SLUG,
		'n8nchat_render_settings_page',
		'dashicons-format-chat',
		58
	);
} );

/**
 * Register one Settings-API section per group, each on its own PAGE slug.
 *
 * do_settings_sections() renders every section registered against a page, in one run, and there is
 * no way to ask it for a single section. Giving each group its own page slug — "n8n-chatbot-
 * appearance" and so on — is what lets the screen call it once per panel and put the six results in
 * six containers. The alternative, rendering the whole page and slicing it up with JavaScript, is
 * both fragile and unavailable to anyone with JavaScript off.
 */
add_action( 'admin_init', function () {
	if ( n8nchat_uses_acf() ) { return; }

	foreach ( n8nchat_groups() as $group => $meta ) {
		$in_group = n8nchat_group_fields( $group );
		if ( empty( $in_group ) ) { continue; }

		$page = N8NCHAT_ADMIN_SLUG . '-' . $group;

		// No section title: the tab already names the group, and a heading repeating the tab label
		// directly under it reads as a rendering mistake.
		add_settings_section( 'n8nchat_' . $group, '', '__return_false', $page );

		foreach ( $in_group as $name => $field ) {
			add_settings_field(
				'n8nchat_' . $name,
				esc_html( $field['label'] ),
				'n8nchat_render_field',
				$page,
				'n8nchat_' . $group,
				[
					'key'       => $name,
					'field'     => $field,
					// label_for makes the <th> a real <label> pointing at the control, which is the
					// only reason clicking a field's name focuses it. Checkboxes render their own
					// wrapping label, so pointing a second one at them would produce two labels for
					// one control and a screen reader reading the name twice.
					'label_for' => 'bool' === $field['type'] ? '' : 'n8nchat_' . $name,
					'class'     => 'n8nchat-row n8nchat-row-' . $field['type'],
				]
			);
		}
	}
} );

/**
 * Render a single settings field.
 *
 * Values come from the saved option RAW — not through n8nchat_settings() — so the form shows what
 * is actually stored rather than what the reader resolves it to. That distinction matters for the
 * blankable fields: a deliberately empty subtitle must render as an empty box, not silently
 * redisplay the default it is overriding, or saving the form would reinstate the default the admin
 * cleared.
 *
 * Every control carries `data-n8nchat-field` naming its setting. That is the seam the live preview
 * reads: assets/admin/admin.js walks the form, collects name/value pairs and posts them, and it can
 * therefore do so without knowing a single field name — which is the whole point.
 */
function n8nchat_render_field( $args ) {
	$key   = $args['key'];
	$field = $args['field'];

	$stored = get_option( N8NCHAT_OPTION, [] );
	if ( ! is_array( $stored ) ) { $stored = []; }
	$value = array_key_exists( $key, $stored ) ? $stored[ $key ] : $field['default'];

	$name = N8NCHAT_OPTION . '[' . $key . ']';
	$id   = 'n8nchat_' . $key;
	$data = ' data-n8nchat-field="' . esc_attr( $key ) . '"';

	switch ( $field['type'] ) {
		case 'bool':
			// The checkbox carries its own description inline, so it returns early below.
			printf(
				'<label><input type="checkbox" id="%s" name="%s" value="1" %s%s> %s</label>',
				esc_attr( $id ),
				esc_attr( $name ),
				checked( ! empty( $value ), true, false ),
				$data, // phpcs:ignore WordPress.Security.EscapeOutput -- built from esc_attr above.
				isset( $field['help'] ) ? wp_kses_post( $field['help'] ) : ''
			);
			return;

		case 'textarea':
			printf(
				'<textarea id="%s" name="%s" rows="3" class="large-text"%s>%s</textarea>',
				esc_attr( $id ),
				esc_attr( $name ),
				$data, // phpcs:ignore WordPress.Security.EscapeOutput
				esc_textarea( (string) $value )
			);
			break;

		case 'css':
			printf(
				'<textarea id="%s" name="%s" rows="8" class="large-text code" spellcheck="false"%s>%s</textarea>',
				esc_attr( $id ),
				esc_attr( $name ),
				$data, // phpcs:ignore WordPress.Security.EscapeOutput
				esc_textarea( (string) $value )
			);
			break;

		case 'list':
			// One entry per line. The stored value is an array on this path and a newline block on
			// the ACF path; n8nchat_sanitize_value() accepts either, so only the display differs.
			$text = is_array( $value ) ? implode( "\n", $value ) : (string) $value;
			printf(
				'<textarea id="%s" name="%s" rows="%d" class="large-text"%s>%s</textarea>',
				esc_attr( $id ),
				esc_attr( $name ),
				isset( $field['max_items'] ) ? (int) min( 8, max( 3, $field['max_items'] ) ) : 4,
				$data, // phpcs:ignore WordPress.Security.EscapeOutput
				esc_textarea( $text )
			);
			break;

		case 'color':
			// The readout beside it is filled in by assets/admin/admin.js, which recomputes the
			// contrast maths from inc/theme.php in the browser. Empty and aria-live here so that a
			// colour whose surface had to be nudged announces itself rather than only looking
			// slightly different from what was picked.
			printf(
				'<span class="n8nchat-color"><input type="color" id="%s" name="%s" value="%s"%s>'
					. '<output class="n8nchat-contrast" for="%s" aria-live="polite"></output></span>',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( (string) $value ),
				$data, // phpcs:ignore WordPress.Security.EscapeOutput
				esc_attr( $id )
			);
			break;

		case 'select':
			$options = isset( $field['options'] ) ? $field['options'] : [];
			printf(
				'<select id="%s" name="%s"%s>',
				esc_attr( $id ),
				esc_attr( $name ),
				$data // phpcs:ignore WordPress.Security.EscapeOutput
			);
			foreach ( $options as $option_value => $option_label ) {
				printf(
					'<option value="%s" %s>%s</option>',
					esc_attr( $option_value ),
					selected( (string) $value, (string) $option_value, false ),
					esc_html( $option_label )
				);
			}
			echo '</select>';
			break;

		case 'number':
			printf(
				'<input type="number" id="%s" name="%s" value="%s"%s%s class="small-text"%s>',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( (string) $value ),
				isset( $field['min'] ) ? ' min="' . esc_attr( $field['min'] ) . '"' : '',
				isset( $field['max'] ) ? ' max="' . esc_attr( $field['max'] ) . '"' : '',
				$data // phpcs:ignore WordPress.Security.EscapeOutput
			);
			if ( ! empty( $field['unit'] ) ) {
				printf( ' <span class="description">%s</span>', esc_html( $field['unit'] ) );
			}
			break;

		case 'url':
		case 'image':
			printf(
				'<input type="url" id="%s" name="%s" value="%s" class="regular-text" placeholder="https://…"%s>',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( (string) $value ),
				$data // phpcs:ignore WordPress.Security.EscapeOutput
			);
			break;

		case 'email':
			printf(
				'<input type="email" id="%s" name="%s" value="%s" class="regular-text"%s>',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( (string) $value ),
				$data // phpcs:ignore WordPress.Security.EscapeOutput
			);
			break;

		default: // text
			printf(
				'<input type="text" id="%s" name="%s" value="%s" class="regular-text"%s>',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( (string) $value ),
				$data // phpcs:ignore WordPress.Security.EscapeOutput
			);
			break;
	}

	if ( ! empty( $field['help'] ) ) {
		printf( '<p class="description">%s</p>', wp_kses_post( $field['help'] ) );
	}
}

/**
 * The one field of a given type, or '' when there is not exactly one.
 *
 * Used to find the colour picker the contrast readout attaches to. Hardcoding `primary_color` would
 * be the first crack in "everything comes from the schema"; asking which field is the `color` one
 * keeps the screen honest, and rename the setting and this still finds it.
 *
 * Ambiguity returns '' rather than guessing. A site that filters a second colour into the schema
 * gets no readout at all, which is plainly a gap, rather than a readout silently wired to the wrong
 * picker, which looks like a working feature and lies.
 */
function n8nchat_admin_only_field_of_type( $type ) {
	$found = '';
	foreach ( n8nchat_schema() as $name => $field ) {
		if ( $type !== $field['type'] ) { continue; }
		if ( '' !== $found ) { return ''; }
		$found = $name;
	}
	return $found;
}

/**
 * The setting the style presets choose between, or '' when the schema has no such field.
 *
 * Identified as the select that has an option for every key of n8nchat_presets(). That is a
 * roundabout way of saying "the preset field", and it is deliberate: the presets and the field that
 * names them are declared next to each other in the schema, so matching them to each other there
 * means neither this file nor the JavaScript has to know what the field is called.
 *
 * A containment test rather than an equality test, because the two are filterable independently. A
 * site that filters the preset map down to two entries still has a three-option select, and under
 * equality the cards would have vanished entirely rather than showing the two that remain — a
 * silent, total failure in response to a perfectly reasonable filter.
 */
function n8nchat_admin_preset_field() {
	$presets = array_keys( n8nchat_presets() );
	if ( empty( $presets ) ) { return ''; }

	foreach ( n8nchat_schema() as $name => $field ) {
		if ( 'select' !== $field['type'] || empty( $field['options'] ) ) { continue; }
		if ( [] === array_diff( $presets, array_keys( $field['options'] ) ) ) { return $name; }
	}
	return '';
}

/**
 * The preset map, with anything the schema does not recognise removed.
 *
 * n8nchat_presets() is filterable, and a filter is exactly where a stale settings name survives an
 * upgrade. A preset that sets a field the schema no longer declares would write a key the sanitiser
 * then drops on save — so the card would appear to work, the preview would even change, and the
 * setting would vanish the moment anyone pressed Save. Dropping it here means the card simply sets
 * one fewer field, which is visible and harmless.
 *
 * Values are put through the field's own sanitiser too, so a preset cannot smuggle an out-of-range
 * number or an unknown select option past the schema's min/max.
 */
function n8nchat_admin_preset_values() {
	$out = [];
	foreach ( n8nchat_presets() as $preset => $values ) {
		if ( ! is_array( $values ) ) { continue; }
		$clean = [];
		foreach ( $values as $name => $value ) {
			$field = n8nchat_field( $name );
			if ( ! $field ) { continue; }
			$clean[ $name ] = n8nchat_sanitize_value( $name, $field, $value );
		}
		if ( $clean ) { $out[ $preset ] = $clean; }
	}
	return $out;
}

/**
 * The tab currently selected, validated against the groups that actually exist.
 *
 * Read-only and never trusted: `?tab=` is user input on a page that renders it into markup, and the
 * only safe way to use it is to look it up rather than print it.
 */
function n8nchat_admin_current_tab() {
	$groups = array_keys( n8nchat_groups() );
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only navigation state.
	$asked = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : '';
	return in_array( $asked, $groups, true ) ? $asked : (string) reset( $groups );
}

/** The screen's own URL, optionally for one tab. */
function n8nchat_admin_url( $tab = '' ) {
	$url = admin_url( 'admin.php?page=' . N8NCHAT_ADMIN_SLUG );
	return $tab ? add_query_arg( 'tab', $tab, $url ) : $url;
}

/**
 * Assets, on this screen only.
 *
 * The hook suffix is compared rather than the page query argument, because $hook is what WordPress
 * itself derived from the menu registration and cannot be spoofed by a URL. Enqueuing globally
 * would put the preview's postMessage listener on every admin screen in the site, which is both
 * rude and a needless surface.
 */
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'toplevel_page_' . N8NCHAT_ADMIN_SLUG !== $hook ) { return; }
	if ( n8nchat_uses_acf() ) { return; }

	wp_enqueue_style( 'n8nchat-admin', N8NCHAT_URL . 'assets/admin/admin.css', [], N8NCHAT_VERSION );
	wp_enqueue_script( 'n8nchat-admin', N8NCHAT_URL . 'assets/admin/admin.js', [], N8NCHAT_VERSION, true );

	$presets = n8nchat_admin_preset_values();
	$tokens  = n8nchat_tokens( n8nchat_settings() );

	// Only the fields the presets touch: their schema default (so the script can tell "I chose this"
	// from "a preset put it there") and their label (so it can say which ones it left alone).
	$preset_defaults = [];
	$preset_labels   = [];
	foreach ( $presets as $values ) {
		foreach ( array_keys( $values ) as $name ) {
			$preset_defaults[ $name ] = n8nchat_field( $name )['default'];
			$preset_labels[ $name ]   = n8nchat_field( $name )['label'];
		}
	}

	// n8nchat_preview_json() rather than wp_json_encode(): it is the same inline-<script> problem
	// here as in the preview document, and a translated label containing "</script" would otherwise
	// end the block early. See its docblock in inc/admin/preview.php.
	wp_add_inline_script(
		'n8nchat-admin',
		'window.N8NCHAT_ADMIN=' . n8nchat_preview_json( [
			'presetField'    => n8nchat_admin_preset_field(),
			'presets'        => $presets,
			'presetDefaults' => $preset_defaults,
			'labels'         => $preset_labels,
			'colorField'     => n8nchat_admin_only_field_of_type( 'color' ),

			/*
			 * The four colours the contrast maths is anchored to, asked of inc/theme.php rather than
			 * written down twice.
			 *
			 * The surfaces are simply the light and dark themes' own backgrounds. The two candidate
			 * inks are recovered by asking n8nchat_on_color() what it would lay over pure black and
			 * pure white — which is white and near-black by definition, and stays correct if either
			 * is ever changed. Hardcoding them in the JavaScript would have produced a readout that
			 * quietly described a widget the plugin had stopped drawing.
			 */
			'surfaces'       => [
				'light' => $tokens['light']['--wwc-bg'],
				'dark'  => $tokens['dark']['--wwc-bg'],
			],
			'inks'           => [
				'light' => n8nchat_on_color( [ '#000000' ] ),
				'dark'  => n8nchat_on_color( [ '#ffffff' ] ),
			],

			'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
			'configAction'   => 'n8nchat_preview_config',
			'nonce'          => wp_create_nonce( N8NCHAT_PREVIEW_NONCE ),
			'origin'         => n8nchat_admin_origin(),
			'i18n'           => [
				'pass'     => __( 'AA pass', 'n8n-chatbot' ),
				'fail'     => __( 'below AA', 'n8n-chatbot' ),
				'onAccent' => __( 'Text on the brand colour', 'n8n-chatbot' ),
				'asText'   => __( 'Brand colour as text', 'n8n-chatbot' ),
				'willUse'  => __( 'The widget will use', 'n8n-chatbot' ),
				/* translators: %s: the adjusted hex colour the widget will actually paint. */
				'nudged'   => __( 'Neither white nor near-black text reaches AA on the colour you picked, so the launcher and the visitor’s own messages will use %s instead. Everything else keeps your colour.', 'n8n-chatbot' ),
				'schemeFixed' => __( 'This site uses one fixed colour scheme, so there is nothing to switch between. Choose “Auto (follow the visitor)” to preview both.', 'n8n-chatbot' ),
				'applied'  => __( 'Preset applied.', 'n8n-chatbot' ),
				/* translators: %s: a comma-separated list of setting labels. */
				'kept'     => __( 'Left as you set them: %s.', 'n8n-chatbot' ),
			],
		] ) . ';',
		'before'
	);
} );

/**
 * The origin this admin screen is served from.
 *
 * Both ends of the postMessage channel check it. Same-origin is guaranteed here — the preview is an
 * admin-post.php URL on this very site — but a postMessage without a target origin is broadcast to
 * whatever document happens to be in the frame, and one that does not check event.origin will act
 * on anything any frame sends it. Neither is exploitable through this screen today; both are free.
 */
function n8nchat_admin_origin() {
	$home = wp_parse_url( admin_url() );
	if ( empty( $home['scheme'] ) || empty( $home['host'] ) ) { return ''; }
	$origin = $home['scheme'] . '://' . $home['host'];
	if ( ! empty( $home['port'] ) ) { $origin .= ':' . (int) $home['port']; }
	return $origin;
}

/**
 * Render the screen.
 */
function n8nchat_render_settings_page() {
	// Belt and braces. add_menu_page() already gates on manage_options and WordPress will not route
	// here without it, but a callback that renders a site's webhook URL should not depend on the
	// caller having got that right.
	if ( ! current_user_can( 'manage_options' ) ) { return; }

	$groups       = n8nchat_groups();
	$current      = n8nchat_admin_current_tab();
	$resolved     = n8nchat_settings();
	$preset_field = n8nchat_admin_preset_field();
	$preset_group = $preset_field ? n8nchat_field( $preset_field )['group'] : '';

	// The tab the webhook lives on, for the warning below. Looked up rather than assumed: the schema
	// is filterable, and a screen that fatals on `null['group']` because somebody moved a field is a
	// far worse outcome than a warning that has no link on it.
	$webhook      = n8nchat_field( 'webhook_url' );
	$webhook_tab  = $webhook ? $webhook['group'] : '';
	?>
	<div class="wrap n8nchat-screen">
		<h1 class="wp-heading-inline"><?php esc_html_e( 'Chatbot', 'n8n-chatbot' ); ?></h1>

		<?php if ( empty( $resolved['webhook_url'] ) ) : ?>
			<?php
			/*
			 * The one failure that makes the whole plugin look broken, so it is stated once, at the
			 * top, and it links to the tab that fixes it rather than telling the reader to look
			 * "below" — which, now that the fields are on six tabs, they might not be.
			 */
			?>
			<div class="notice notice-warning n8nchat-alert">
				<p>
					<strong><?php esc_html_e( 'No webhook URL set.', 'n8n-chatbot' ); ?></strong>
					<?php esc_html_e( 'The chat widget will not appear anywhere on the site until you set one.', 'n8n-chatbot' ); ?>
					<?php if ( $webhook_tab ) : ?>
						<a href="<?php echo esc_url( n8nchat_admin_url( $webhook_tab ) ); ?>" data-n8nchat-goto="<?php echo esc_attr( $webhook_tab ); ?>"><?php esc_html_e( 'Set it now', 'n8n-chatbot' ); ?></a>
					<?php endif; ?>
				</p>
			</div>
		<?php elseif ( empty( $resolved['enabled'] ) ) : ?>
			<div class="notice notice-info n8nchat-alert">
				<p><?php esc_html_e( 'The chatbot is configured but switched off, so nothing renders on the front end. The preview below still works.', 'n8n-chatbot' ); ?></p>
			</div>
		<?php endif; ?>

		<?php
		/*
		 * A <nav> of links, not buttons. Each href is the same screen with ?tab=, so the tabs work
		 * with JavaScript off, survive a bookmark, and put a working Back button between panels.
		 * assets/admin/admin.js intercepts the click and swaps panels instantly, then rewrites the
		 * address bar with replaceState so the two behaviours agree about where you are.
		 */
		?>
		<nav class="nav-tab-wrapper wp-clearfix n8nchat-tabs" aria-label="<?php esc_attr_e( 'Settings sections', 'n8n-chatbot' ); ?>">
			<?php foreach ( $groups as $group => $meta ) : ?>
				<a
					class="nav-tab <?php echo $group === $current ? 'nav-tab-active' : ''; ?>"
					id="n8nchat-tab-<?php echo esc_attr( $group ); ?>"
					href="<?php echo esc_url( n8nchat_admin_url( $group ) ); ?>"
					data-n8nchat-tab="<?php echo esc_attr( $group ); ?>"
					aria-controls="n8nchat-panel-<?php echo esc_attr( $group ); ?>"
					aria-current="<?php echo $group === $current ? 'page' : 'false'; ?>"
				><?php echo esc_html( $meta['label'] ); ?></a>
			<?php endforeach; ?>
		</nav>

		<div class="n8nchat-layout">
			<?php
			/*
			 * novalidate, and it is not laziness.
			 *
			 * Four settings render as <input type="url">. A browser refuses to submit a form
			 * containing an invalid one and then tries to focus it to explain why — but a field on
			 * an inactive tab is inside a `hidden` subtree and cannot be focused, so Chrome logs
			 * "An invalid form control is not focusable" to a console nobody has open and the save
			 * does NOTHING AT ALL. No error, no notice, the page simply does not submit. Turning
			 * native validation off and doing it ourselves (admin.js switches to the offending
			 * field's tab first, then asks the browser to report it) is the only arrangement where
			 * the message reaches the person who typed the value.
			 *
			 * The server is the authority regardless: n8nchat_sanitize_value() runs esc_url_raw()
			 * with an explicit http/https whitelist whatever the browser thought of the input.
			 */
			?>
			<?php n8nchat_admin_render_feedback(); ?>

			<form method="post" action="options.php" class="n8nchat-form" id="n8nchat-form" novalidate>
				<?php settings_fields( 'n8nchat_settings_group' ); ?>

				<?php foreach ( $groups as $group => $meta ) : ?>
					<section
						class="n8nchat-panel"
						id="n8nchat-panel-<?php echo esc_attr( $group ); ?>"
						data-n8nchat-panel="<?php echo esc_attr( $group ); ?>"
						aria-labelledby="n8nchat-tab-<?php echo esc_attr( $group ); ?>"
						<?php echo $group === $current ? '' : 'hidden'; ?>
					>
						<?php if ( ! empty( $meta['help'] ) ) : ?>
							<p class="description n8nchat-group-help"><?php echo wp_kses_post( $meta['help'] ); ?></p>
						<?php endif; ?>

						<?php if ( $group === $preset_group ) { n8nchat_admin_render_presets( $preset_field ); } ?>

						<?php do_settings_sections( N8NCHAT_ADMIN_SLUG . '-' . $group ); ?>
					</section>
				<?php endforeach; ?>

				<?php submit_button(); ?>
			</form>

			<?php n8nchat_admin_render_preview_pane( $resolved ); ?>
		</div>
	</div>
	<?php
}

/**
 * What visitors made of the answers.
 *
 * Rendered only once there is something to render, so a site that has just been set up is not shown
 * an empty scoreboard. Reads the option inc/rest.php writes — aggregate counts plus the last fifty
 * page URLs, and deliberately nothing that identifies a conversation.
 *
 * This exists because the thumbs shipped in 2.0.0 wired to nothing at all: they acknowledged the
 * click and discarded the rating. A rating control whose output no one can see is the same defect
 * wearing a different hat, so the endpoint and this readout landed together.
 */
function n8nchat_admin_render_feedback() {
	$store = get_option( 'n8nchat_feedback', [] );
	if ( ! is_array( $store ) ) { return; }

	$up    = isset( $store['up'] ) ? (int) $store['up'] : 0;
	$down  = isset( $store['down'] ) ? (int) $store['down'] : 0;
	$total = $up + $down;
	if ( $total < 1 ) { return; }

	// The pages behind the thumbs-down, most-complained-about first. This is the actionable half:
	// a count on its own says something is wrong, this says where to look.
	$pages  = [];
	$recent = isset( $store['recent'] ) && is_array( $store['recent'] ) ? $store['recent'] : [];
	foreach ( $recent as $entry ) {
		if ( ! is_array( $entry ) || 'down' !== ( isset( $entry['r'] ) ? $entry['r'] : '' ) ) { continue; }
		$page = isset( $entry['p'] ) ? (string) $entry['p'] : '';
		if ( '' === $page ) { continue; }
		$pages[ $page ] = isset( $pages[ $page ] ) ? $pages[ $page ] + 1 : 1;
	}
	arsort( $pages );
	$pages = array_slice( $pages, 0, 5, true );
	?>
	<div class="n8nchat-feedback notice notice-info inline">
		<p>
			<strong><?php esc_html_e( 'Answer ratings', 'n8n-chatbot' ); ?></strong>
			<?php
			printf(
				/* translators: 1: thumbs-up count, 2: thumbs-down count, 3: percentage rated good. */
				esc_html__( '%1$s good, %2$s needs work (%3$s%% positive).', 'n8n-chatbot' ),
				esc_html( number_format_i18n( $up ) ),
				esc_html( number_format_i18n( $down ) ),
				esc_html( number_format_i18n( (int) round( ( $up / max( 1, $total ) ) * 100 ) ) )
			);
			?>
		</p>
		<?php if ( $pages ) : ?>
			<p class="description">
				<?php esc_html_e( 'Recent thumbs-down came from:', 'n8n-chatbot' ); ?>
			</p>
			<ul class="n8nchat-feedback-pages">
				<?php foreach ( $pages as $page => $count ) : ?>
					<li>
						<a href="<?php echo esc_url( $page ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $page ); ?></a>
						<?php echo esc_html( sprintf( _n( '(%s rating)', '(%s ratings)', $count, 'n8n-chatbot' ), number_format_i18n( $count ) ) ); ?>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * The style-preset cards.
 *
 * Hidden until assets/admin/admin.js reveals them, and the select they stand in for is hidden by
 * the same script at the same moment. Two controls for one setting is worse than the plain select,
 * so with JavaScript off the select is what you get and the cards — which can do nothing without a
 * script to set the other fields — are never shown at all.
 */
function n8nchat_admin_render_presets( $preset_field ) {
	if ( ! $preset_field ) { return; }

	$field   = n8nchat_field( $preset_field );
	$presets = n8nchat_admin_preset_values();
	$stored  = get_option( N8NCHAT_OPTION, [] );
	$current = ( is_array( $stored ) && isset( $stored[ $preset_field ] ) ) ? $stored[ $preset_field ] : $field['default'];
	?>
	<div class="n8nchat-presets" data-n8nchat-presets hidden>
		<h3 class="n8nchat-presets-title"><?php echo esc_html( $field['label'] ); ?></h3>
		<div class="n8nchat-preset-cards" role="radiogroup" aria-label="<?php echo esc_attr( $field['label'] ); ?>">
			<?php foreach ( $presets as $preset => $values ) : ?>
				<?php
				if ( ! isset( $field['options'][ $preset ] ) ) { continue; }
				/*
				 * The option label carries both halves of the card — "Modern minimal — flat
				 * replies, tight type, one accent" — because that string is already written, is
				 * already translated, and is what the select shows. Splitting it here rather than
				 * declaring a second set of card labels is what stops the two describing the same
				 * preset differently, which is the exact failure the schema exists to prevent.
				 */
				$parts = preg_split( '/\s+[—–-]\s+/u', (string) $field['options'][ $preset ], 2 );
				$name  = $parts[0];
				$blurb = isset( $parts[1] ) ? $parts[1] : '';
				?>
				<button
					type="button"
					class="n8nchat-preset-card <?php echo (string) $current === (string) $preset ? 'is-current' : ''; ?>"
					data-n8nchat-preset="<?php echo esc_attr( $preset ); ?>"
					role="radio"
					aria-checked="<?php echo (string) $current === (string) $preset ? 'true' : 'false'; ?>"
				>
					<span class="n8nchat-preset-swatch" data-n8nchat-preset-swatch aria-hidden="true">
						<span class="n8nchat-preset-bubble" style="border-radius:<?php echo isset( $values['corner_radius'] ) ? (int) $values['corner_radius'] : 14; ?>px"></span>
						<span class="n8nchat-preset-bubble n8nchat-preset-bubble-me" style="border-radius:<?php echo isset( $values['corner_radius'] ) ? (int) $values['corner_radius'] : 14; ?>px"></span>
					</span>
					<span class="n8nchat-preset-name"><?php echo esc_html( $name ); ?></span>
					<?php if ( '' !== $blurb ) : ?>
						<span class="n8nchat-preset-blurb"><?php echo esc_html( $blurb ); ?></span>
					<?php endif; ?>
				</button>
			<?php endforeach; ?>
		</div>
		<p class="description n8nchat-preset-status" role="status" aria-live="polite"></p>
	</div>
	<?php
}

/**
 * The preview column.
 *
 * The iframe is empty in the markup and its src is set by admin.js. That is not decoration: the
 * preview URL carries a nonce, and a nonce printed into an `src` attribute is requested on every
 * page load whether or not anyone looks at the preview — including by a prefetching browser. Doing
 * it from script keeps the request to the one case where somebody is actually on the screen, and
 * lets the pane degrade to a plain explanatory line with JavaScript off, where a live preview could
 * not work anyway.
 */
function n8nchat_admin_render_preview_pane( $resolved ) {
	?>
	<aside class="n8nchat-preview" aria-labelledby="n8nchat-preview-title">
		<div class="n8nchat-preview-sticky">
			<div class="n8nchat-preview-head">
				<h2 id="n8nchat-preview-title" class="n8nchat-preview-title"><?php esc_html_e( 'Live preview', 'n8n-chatbot' ); ?></h2>
				<p class="description"><?php esc_html_e( 'The real widget, with the values in the form beside it. It answers from a canned reply, so nothing here reaches your workflow.', 'n8n-chatbot' ); ?></p>
			</div>

			<div class="n8nchat-preview-tools" data-n8nchat-tools hidden>
				<div class="n8nchat-toolgroup" role="group" aria-label="<?php esc_attr_e( 'Colour scheme', 'n8n-chatbot' ); ?>">
					<button type="button" class="button button-small is-on" data-n8nchat-scheme=""><?php esc_html_e( 'As set', 'n8n-chatbot' ); ?></button>
					<button type="button" class="button button-small" data-n8nchat-scheme="light"><?php esc_html_e( 'Light', 'n8n-chatbot' ); ?></button>
					<button type="button" class="button button-small" data-n8nchat-scheme="dark"><?php esc_html_e( 'Dark', 'n8n-chatbot' ); ?></button>
				</div>
				<div class="n8nchat-toolgroup" role="group" aria-label="<?php esc_attr_e( 'Screen size', 'n8n-chatbot' ); ?>">
					<button type="button" class="button button-small is-on" data-n8nchat-size="desktop"><?php esc_html_e( 'Desktop', 'n8n-chatbot' ); ?></button>
					<button type="button" class="button button-small" data-n8nchat-size="mobile"><?php esc_html_e( 'Phone', 'n8n-chatbot' ); ?></button>
				</div>
				<div class="n8nchat-toolgroup" role="group" aria-label="<?php esc_attr_e( 'Chat window', 'n8n-chatbot' ); ?>">
					<button type="button" class="button button-small is-on" data-n8nchat-open="1"><?php esc_html_e( 'Open', 'n8n-chatbot' ); ?></button>
					<button type="button" class="button button-small" data-n8nchat-open="0"><?php esc_html_e( 'Closed', 'n8n-chatbot' ); ?></button>
				</div>
				<button type="button" class="button button-small" data-n8nchat-demo><?php esc_html_e( 'Play a sample reply', 'n8n-chatbot' ); ?></button>
			</div>

			<div class="n8nchat-frame" data-n8nchat-frame>
				<?php
				/*
				 * sandbox, and specifically WITH allow-same-origin.
				 *
				 * The widget is an ES module the browser fetches with CORS semantics. Dropping
				 * allow-same-origin puts the document on an opaque origin, from which a same-origin
				 * module URL becomes a cross-origin request with `Origin: null` — and nothing serves
				 * `Access-Control-Allow-Origin: null` for a static plugin file, so the preview would
				 * load a launcher and then fail to import the chat. What the sandbox is still doing
				 * is real: no top-level navigation, no popups, no form submission, no plugins, no
				 * downloads. The document itself is generated by inc/admin/preview.php from this
				 * site's own settings and never renders anything a visitor typed.
				 *
				 * Storage is neutralised inside the frame instead — see preview.php, which replaces
				 * localStorage with an in-memory shim before the widget boots, so previewing never
				 * writes to (or purges) the state the real widget keeps for this browser.
				 */
				?>
				<iframe
					title="<?php esc_attr_e( 'Chat widget preview', 'n8n-chatbot' ); ?>"
					class="n8nchat-iframe"
					data-n8nchat-iframe
					data-src="<?php echo esc_url( n8nchat_preview_url() ); ?>"
					sandbox="allow-scripts allow-same-origin"
					loading="lazy"
				></iframe>
				<p class="n8nchat-noscript description"><?php esc_html_e( 'The live preview needs JavaScript.', 'n8n-chatbot' ); ?></p>
			</div>

			<p class="description n8nchat-preview-foot">
				<?php esc_html_e( 'The mock page behind the widget is always light. Most WordPress themes are, which is why “Always light” is the right colour scheme for most sites — a dark widget on a light page reads as broken rather than as considerate.', 'n8n-chatbot' ); ?>
			</p>
		</div>
	</aside>
	<?php
}
