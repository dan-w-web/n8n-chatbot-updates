<?php
/**
 * Front-end output: decide whether the widget runs on this request, print its theme, and hand the
 * boot stub everything it needs.
 *
 * What changed in 2.0, and why it matters more than it looks: 1.x imported ~355 KiB gzipped of
 * third-party Vue from jsDelivr on EVERY page view, whether or not a visitor ever opened the chat,
 * and enqueued that package's stylesheet render-blocking in <head> alongside it. Neither is here
 * any more. This file now enqueues one ~3 KB stub, inlines the derived theme, and the stub imports
 * the widget itself only when someone actually interacts. On a client site where nobody opens the
 * chat — which is most page views on most sites — the cost is now a rounding error.
 *
 * The n8n contract is unchanged: the browser POSTs directly to the Chat Trigger webhook, because
 * that node's Allowed Origins is locked per bot to the customer's own domain and proxying through
 * WordPress would fail CORS on every bot already in production.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * localStorage key the widget keeps its session id under.
 *
 * Kept at the name 1.x used, deliberately. A visitor who was mid-conversation when 2.0 lands has a
 * session id under this key and n8n still holds the matching memory against it, so reusing the key
 * carries their conversation across the upgrade instead of silently abandoning it.
 */
function n8nchat_session_key() {
	return 'n8n-chat/sessionId';
}

/**
 * Per-site scope token for the widget's client-side state.
 *
 * Browsers scope localStorage to ORIGIN, never to path. On a SUBDIRECTORY multisite
 * (example.com/site-a/, example.com/site-b/) every subsite is therefore one storage area, while
 * settings — webhook_url and bot_id included — are per-subsite. Left unscoped, subsite B reads the
 * session id and transcript subsite A wrote, and one tenant's conversation is handed to another
 * tenant's backend. That is a privacy failure, not an inconvenience.
 *
 * Derived from the blog id AND the tenant routing, so repointing a site at a different webhook or
 * bot also retires the conversations that belonged to the old one. Nothing is exposed by doing so:
 * the webhook URL is already printed in full in the config below.
 */
function n8nchat_site_scope( $s ) {
	$blog    = function_exists( 'get_current_blog_id' ) ? (int) get_current_blog_id() : 0;
	$webhook = isset( $s['webhook_url'] ) ? (string) $s['webhook_url'] : '';
	$bot     = isset( $s['bot_id'] ) ? (string) $s['bot_id'] : '';
	return substr( md5( $blog . '|' . $webhook . '|' . $bot ), 0, 12 );
}

/**
 * Is this the one topology where another site can have left state in our storage area?
 *
 * Only subdirectory multisite shares an origin between sites. Single-site installs, and subdomain
 * or domain-mapped multisite, cannot — so there an unowned session can safely be ADOPTED on first
 * run, which is what keeps a visitor who was mid-conversation across an upgrade. On subdirectory
 * multisite that adoption is exactly the cross-tenant carry being closed, so it is refused and the
 * first page view starts clean instead.
 */
function n8nchat_scope_is_strict() {
	return function_exists( 'is_multisite' ) && is_multisite()
		&& function_exists( 'is_subdomain_install' ) && ! is_subdomain_install();
}

/**
 * n8nchat_settings() memoised for the life of the request.
 *
 * On the ACF path each call is one get_field() per setting — around fifty in 2.0 — and the front
 * end asks on every hook this file runs on. Front-end only by design: every caller sits behind
 * n8nchat_active(), which bails in wp-admin, so no settings save can be served a stale memo.
 */
function n8nchat_settings_cached() {
	static $memo = null;
	if ( null === $memo ) {
		$memo = n8nchat_settings();
	}
	return $memo;
}

/**
 * The current request's path, normalised for matching against the page rules.
 *
 * Always leading-slashed, always trailing-slashed, query string and fragment discarded, so that
 * `/checkout`, `/checkout/` and `/checkout?step=2` are one rule rather than three.
 */
function n8nchat_current_path() {
	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
	$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
	if ( '' === $path ) { $path = '/'; }
	return '/' . trim( $path, '/' ) . '/';
}

/**
 * Does a path match one of the configured rules?
 *
 * A rule is a plain path, optionally ending in `*` to match everything below it. Deliberately not
 * a regular expression: these are typed into a settings box by whoever runs the site, and a bad
 * regex there would either match nothing or, worse, everything.
 */
function n8nchat_path_matches( $path, $rules ) {
	foreach ( (array) $rules as $rule ) {
		$rule = trim( (string) $rule );
		if ( '' === $rule ) { continue; }

		if ( '*' === substr( $rule, -1 ) ) {
			$prefix = '/' . ltrim( rtrim( substr( $rule, 0, -1 ), '/' ), '/' );
			// A bare "/*" is "everything", and rtrim leaves it as "/" — which every path starts
			// with, so the general case below already covers it correctly.
			if ( 0 === strpos( $path, $prefix ) ) { return true; }
			continue;
		}

		if ( $path === '/' . trim( $rule, '/' ) . '/' ) { return true; }
	}
	return false;
}

/**
 * Should the widget render on this request?
 *
 * Four gates, cheapest first: never in wp-admin, never without the toggle, never without a webhook
 * (an unconfigured site shows nothing rather than pointing visitors at somebody else's bot), and
 * finally the site's own page rules.
 */
function n8nchat_active() {
	if ( is_admin() ) { return false; }

	$s = n8nchat_settings_cached();
	if ( empty( $s['enabled'] ) || empty( $s['webhook_url'] ) ) { return false; }

	$mode = isset( $s['page_rules_mode'] ) ? $s['page_rules_mode'] : 'all';
	if ( 'all' !== $mode ) {
		$matched = n8nchat_path_matches( n8nchat_current_path(), $s['page_rules'] );
		if ( 'include' === $mode && ! $matched ) { return false; }
		if ( 'exclude' === $mode && $matched ) { return false; }
	}

	/**
	 * Filter whether the widget renders on this request.
	 *
	 * The hook for anything the page rules cannot express — a post type, a user role, a logged-in
	 * check, a consent manager that gates third-party requests server-side.
	 *
	 * @param bool  $active Whether the widget will render.
	 * @param array $s      Resolved plugin settings.
	 */
	return (bool) apply_filters( 'n8nchat_active', true, $s );
}

/**
 * Warm the connection to the n8n host.
 *
 * The first thing the widget does when a visitor sends a message is POST to the Chat Trigger, and
 * that is a cross-origin request to a host the browser has never spoken to — DNS, TLS and TCP all
 * on the critical path of the very interaction the visitor is waiting on. Paying for it during idle
 * time instead takes a visible bite out of time-to-first-token.
 *
 * Only the origin is hinted, never the full webhook path: a preconnect appears in the page source,
 * and the path is the part that identifies the bot.
 */
add_filter( 'wp_resource_hints', function ( $urls, $relation ) {
	if ( 'preconnect' !== $relation ) { return $urls; }
	if ( ! n8nchat_active() ) { return $urls; }

	$s      = n8nchat_settings_cached();
	$scheme = wp_parse_url( $s['webhook_url'], PHP_URL_SCHEME );
	$host   = wp_parse_url( $s['webhook_url'], PHP_URL_HOST );

	// Both halves or nothing: a missing host would otherwise emit a preconnect to the literal
	// "https://", which browsers log as an error on every page load of the site.
	if ( $scheme && $host ) {
		$urls[] = [ 'href' => $scheme . '://' . $host, 'crossorigin' ];
	}
	return $urls;
}, 10, 2 );

/**
 * Every visitor-facing string, in one place.
 *
 * These are the strings 1.x hardcoded in English inside assets/chat.js — "New chat", "Copy",
 * "Copied!", and every accessible name — where no site could change them and no translation could
 * reach them. They travel to the widget as data instead, so a site's own wording and a translated
 * WordPress both work, and the widget itself contains no English.
 */
function n8nchat_strings( $s ) {
	return [
		'title'        => $s['title'],
		'subtitle'     => $s['subtitle'],
		'status'       => $s['status_text'],
		'offline'      => $s['offline_text'],
		'greeting'     => $s['greeting'],
		'placeholder'  => $s['placeholder'],
		'botLabel'     => $s['bot_label'],
		'userLabel'    => $s['user_label'],
		'error'        => $s['error_text'],
		'handoff'      => $s['handoff_label'],
		'handoffIntro' => $s['handoff_intro'],

		'open'         => __( 'Open chat', 'n8n-chatbot' ),
		'close'        => __( 'Close chat', 'n8n-chatbot' ),
		'dialog'       => __( 'Chat', 'n8n-chatbot' ),
		'send'         => __( 'Send message', 'n8n-chatbot' ),
		'stop'         => __( 'Stop generating', 'n8n-chatbot' ),
		'newChat'      => __( 'Start a new chat', 'n8n-chatbot' ),
		'expand'       => __( 'Expand', 'n8n-chatbot' ),
		'collapse'     => __( 'Shrink', 'n8n-chatbot' ),
		'jumpToLatest' => __( 'Jump to latest', 'n8n-chatbot' ),
		'copy'         => __( 'Copy', 'n8n-chatbot' ),
		'copied'       => __( 'Copied', 'n8n-chatbot' ),
		'copyFailed'   => __( 'Press Ctrl+C to copy', 'n8n-chatbot' ),
		'retry'        => __( 'Try again', 'n8n-chatbot' ),
		'good'         => __( 'Good response', 'n8n-chatbot' ),
		'bad'          => __( 'Needs work', 'n8n-chatbot' ),
		'thanks'       => __( 'Thanks for the feedback', 'n8n-chatbot' ),
		// Clicking the same thumb again clears the rating, so there has to be something to announce
		// for the undo as well. Silence would leave a screen-reader user unsure it had happened.
		'ratingCleared' => __( 'Rating removed', 'n8n-chatbot' ),
		'emailIt'      => __( 'Email me this conversation', 'n8n-chatbot' ),
		'typing'       => __( 'Assistant is typing', 'n8n-chatbot' ),
		'sent'         => __( 'Message sent', 'n8n-chatbot' ),
		// Spoken after New chat clears the transcript. It needs its own string: reusing
		// 'newChat' would announce the button's label back at you rather than what happened.
		'newChatDone'  => __( 'New chat started', 'n8n-chatbot' ),
		'timeout'      => __( 'The assistant took too long to reply. Please try again.', 'n8n-chatbot' ),
		'offlineNet'   => __( 'You appear to be offline. Check your connection and try again.', 'n8n-chatbot' ),
		'name'         => __( 'Your name', 'n8n-chatbot' ),
		'email'        => __( 'Your email', 'n8n-chatbot' ),
		'message'      => __( 'How can we help?', 'n8n-chatbot' ),
		'submit'       => __( 'Send', 'n8n-chatbot' ),
		'sentThanks'   => __( 'Thanks — we’ll be in touch.', 'n8n-chatbot' ),

		// The handoff card's own copy, and a note that applies to every string in this array.
		//
		// All of them are written into the DOM with textContent, never as HTML, so they must be
		// plain UTF-8 and NOT HTML entities. A literal `&#8217;` here reaches the visitor as the
		// seven characters `&#8217;` rather than as an apostrophe — which is exactly what the line
		// above did until this release, and what `subtitle`'s default in inc/schema.php did on
		// every site that had never edited it.
		'optional'     => __( 'optional', 'n8n-chatbot' ),
		'cancel'       => __( 'Cancel', 'n8n-chatbot' ),
		// Starting a new chat is irreversible — it clears the transcript AND mints a new session id,
		// so n8n forgets the conversation too — and it sits behind a small icon in the header next
		// to Close. The wording names both halves of what is lost, because "this cannot be undone"
		// on its own does not tell anyone what they are undoing.
		'newChatConfirm'     => __( 'Start a new chat?', 'n8n-chatbot' ),
		'newChatConfirmBody' => __( 'This clears the conversation and the assistant will forget what you have discussed. It cannot be undone.', 'n8n-chatbot' ),
		'newChatConfirmYes'  => __( 'Start new chat', 'n8n-chatbot' ),
		'needName'     => __( 'Please enter your name.', 'n8n-chatbot' ),
		'needEmail'    => __( 'Please enter a valid email address.', 'n8n-chatbot' ),
		'sendFailed'   => __( 'That did not send. Please try again.', 'n8n-chatbot' ),
		'tooMany'      => __( 'Too many messages have been sent from this connection. Please try again later.', 'n8n-chatbot' ),
		'transcriptOk' => __( 'Sent. Check your inbox.', 'n8n-chatbot' ),
		'sending'      => __( 'Sending…', 'n8n-chatbot' ),
	];
}

/**
 * The whole configuration the widget boots from.
 *
 * One JSON blob rather than a scattering of data attributes, because the boot stub reads it once
 * and hands the relevant half to the widget module it imports.
 */
function n8nchat_boot_config( $s ) {
	$config = [
		'webhook'     => $s['webhook_url'],
		'metadata'    => [],
		'sessionKey'  => n8nchat_session_key(),
		'scope'       => n8nchat_site_scope( $s ),
		'scopeStrict' => n8nchat_scope_is_strict(),
		'locale'      => n8nchat_locale_key(),
		'rtl'         => function_exists( 'is_rtl' ) ? is_rtl() : false,
		/*
		 * The version matters here as much as it does on the stylesheet below, and it was missing.
		 *
		 * boot.js import()s this URL, and the plugin's assets are served with
		 * `Cache-Control: max-age=31536000`. Without a cache-busting query the URL never changes, so
		 * a browser — and Cloudflare in front of it — keeps serving last year's widget.js for a
		 * year after an update. Caught the hard way: 2.0.1 and 2.0.2 both shipped JavaScript fixes
		 * that were verified in the repo, deployed, and then had no effect whatsoever on the live
		 * site, because the file being executed was the cached copy from before the release. The
		 * stylesheet on the next line always carried its version, which is why CSS-only fixes in
		 * the same releases appeared to work and made the JS look fine too.
		 *
		 * widget.js appends this same query to its own sibling imports — see the top of that file —
		 * so markdown.js, stream.js and handoff.js are busted with it rather than being left a
		 * release behind their caller.
		 */
		'widgetUrl'   => N8NCHAT_URL . 'assets/widget/widget.js?ver=' . rawurlencode( N8NCHAT_VERSION ),
		'styleUrl'    => N8NCHAT_URL . 'assets/widget/widget.css?ver=' . rawurlencode( N8NCHAT_VERSION ),
		// No nonce here, deliberately. The lead-capture and transcript endpoints are reachable by
		// anonymous visitors by definition, so a nonce authenticates nothing — and printing one into
		// a page that a full-page cache then serves for hours would hand every later visitor an
		// expired token and break the form for them. Those endpoints defend themselves with an
		// origin check, rate limiting and a honeypot instead. See inc/rest.php.
		'restUrl'     => esc_url_raw( rest_url( 'n8n-chatbot/v1' ) ),
		'strings'     => n8nchat_strings( $s ),
		'ui'          => [
			'preset'        => $s['preset'],
			'position'      => $s['position'],
			'scheme'        => $s['color_scheme'],
			'launcherIcon'  => $s['launcher_icon'],
			'launcherLabel' => $s['launcher_label'],
			'avatar'        => $s['bot_avatar'],
			'starters'      => array_values( (array) $s['starter_prompts'] ),
			'sound'         => (bool) $s['sound_enabled'],
			'handoff'       => (bool) $s['handoff_enabled'],
			'transcript'    => (bool) $s['transcript_email'],
		],
		'teaser'      => [
			'enabled' => (bool) $s['teaser_enabled'],
			'text'    => '' !== trim( (string) $s['teaser_text'] ) ? $s['teaser_text'] : $s['greeting'],
			'delay'   => (int) $s['teaser_delay'],
			'scroll'  => (int) $s['teaser_scroll'],
			'max'     => (int) $s['teaser_max'],
		],
		'storage'     => [
			// Hours in the settings screen, milliseconds in the widget: the admin thinks in hours
			// and setTimeout does not.
			'ttl'         => (int) $s['history_ttl'] * 3600 * 1000,
			'consentMode' => $s['consent_mode'],
			'consentKey'  => $s['consent_key'],
		],
		// Injected INSIDE the shadow root by the boot stub, which is the only place it can do
		// anything: a shadow boundary is opaque to selectors from the document, so custom CSS
		// printed into <head> — however carefully scoped — cannot reach a single element of the
		// widget. Already stripped of angle brackets by the sanitiser.
		'customCss'   => (string) $s['custom_css'],
	];

	// On the multi-tenant platform a single shared webhook serves every site; the Bot ID travels as
	// chat metadata so the workflow can route to the right bot (system prompt + knowledge). Only
	// sent when set — standalone installs with their own dedicated webhook send no metadata at all.
	if ( ! empty( $s['bot_id'] ) ) {
		$config['metadata']['bot_id'] = $s['bot_id'];
	}

	/**
	 * Filter the whole widget configuration before it is printed.
	 *
	 * The escape hatch for anything a site needs to change without patching the plugin. Replaces
	 * 1.x's `n8nchat_chat_config`, which described a third-party package's option object and has
	 * no meaning now that the widget is our own.
	 *
	 * @param array $config The widget's boot configuration.
	 * @param array $s      Resolved plugin settings.
	 */
	return (array) apply_filters( 'n8nchat_boot_config', $config, $s );
}

/**
 * The i18n bucket key for this site.
 *
 * WordPress locales are underscored (en_GB); the widget only ever uses the value as an HTML `lang`
 * attribute and a hint for Intl formatting, so the BCP-47 spelling is the correct one to hand it.
 */
function n8nchat_locale_key() {
	$locale = preg_replace( '/[^A-Za-z0-9-]/', '', str_replace( '_', '-', (string) get_locale() ) );
	return '' !== $locale ? $locale : 'en';
}

/**
 * Enqueue the boot stub and print the theme.
 *
 * The stub is deferred and tiny; the widget module and its stylesheet are fetched by the stub on
 * first interaction and are not referenced in the document at all, so they cost nothing until then.
 */
add_action( 'wp_enqueue_scripts', function () {
	if ( ! n8nchat_active() ) { return; }

	$s = n8nchat_settings_cached();

	wp_enqueue_script( 'n8n-chatbot', N8NCHAT_URL . 'assets/boot.js', [], N8NCHAT_VERSION, [ 'strategy' => 'defer', 'in_footer' => true ] );
	wp_add_inline_script(
		'n8n-chatbot',
		'window.N8NCHAT=' . wp_json_encode( n8nchat_boot_config( $s ) ) . ';',
		'before'
	);
}, 20 );

/**
 * Print the widget's theme into the document.
 *
 * It goes in the document rather than being injected by JavaScript for one reason: the launcher is
 * painted by the boot stub the moment it runs, and a theme that arrived a tick later would show a
 * flash of an unstyled button in the corner of every page. It is a few hundred bytes.
 *
 * Both custom properties and the site's own custom CSS are scoped to the widget's host element.
 * Inside the shadow root the widget re-declares them against `:host`; here they hang off the host's
 * id, so nothing leaks into the page and nothing in the page reaches in.
 */
add_action( 'wp_head', function () {
	if ( ! n8nchat_active() ) { return; }

	$s = n8nchat_settings_cached();

	// Custom properties only. They inherit THROUGH the shadow boundary, which is exactly why the
	// widget is themed with them and not with rules: this handful of declarations on the host is
	// enough to repaint everything inside, while the widget's own stylesheet stays static and
	// cacheable. The site's custom CSS is not here — it travels in the config and is injected
	// inside the shadow root, where it can actually select something.
	printf( "<style id=\"n8nchat-theme\">%s</style>\n", n8nchat_theme_css( $s, '#n8nchat-host' ) );
}, 8 );
