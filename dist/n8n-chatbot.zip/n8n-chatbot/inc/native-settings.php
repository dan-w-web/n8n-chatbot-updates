<?php
/**
 * Native (non-ACF) settings STORE: the reader, the registration and the shared sanitiser.
 *
 * Used whenever `n8nchat_uses_acf()` is false — i.e. no ACF, ACF-free, or ACF-Pro without our
 * options page. Everything lives in a single wp_options row (N8NCHAT_OPTION).
 *
 * The screen that edits it is inc/admin/page.php. It used to be here, as a flat Settings-API form,
 * and was moved out when it grew tabs and a live preview: this file is the part that both admin
 * paths depend on, and it should be readable without wading through markup.
 *
 * The read function mirrors the ACF reader's fallback semantics exactly — both defer to the same
 * n8nchat_blankable() list and both treat an explicit `enabled` 0 as real — so `n8nchat_settings()`
 * returns an identical array on either path and the front end (inc/render.php) is unaffected.
 * n8nchat_sanitize_options() below is likewise shared: the native path runs it on SAVE (as the
 * setting's sanitize_callback) and the ACF path runs it on READ, since ACF sanitises nothing.
 *
 * The registration below is gated on `! n8nchat_uses_acf()` so exactly one admin UI exists per
 * site; the reader and sanitiser are NOT gated, because both paths use them.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Read resolved settings from the native option.
 *
 * The whole of the work is in n8nchat_resolve_settings() below; this is the one-line binding of
 * that to the store.
 */
function n8nchat_native_get() {
	return n8nchat_resolve_settings( get_option( N8NCHAT_OPTION, [] ) );
}

/**
 * Turn a stored native settings array into a resolved one, applying exactly the same rules as the
 * ACF reader in n8nchat_settings(): unset→default, explicit `enabled` 0 respected, and the
 * n8nchat_blankable() fields allowed to stay deliberately empty.
 *
 * "Unset" is `array_key_exists()` here and `null`/`false` from get_field() there — those are the
 * two stores' respective ways of saying "no value was ever recorded". Keep the three branches
 * below in lockstep with their counterparts in n8nchat_settings(); the previous divergence is
 * what silently made a blank bot_label impossible on both paths.
 *
 * Taking the array as an argument rather than reading the option itself is what lets the admin
 * screen's live preview (inc/admin/preview.php) resolve a form that has not been saved yet through
 * the very same rules a save would apply. A second, preview-only copy of these three branches is
 * precisely the drift this plugin has already been bitten by once.
 */
function n8nchat_resolve_settings( $stored ) {
	$defaults  = n8nchat_defaults();
	$blankable = n8nchat_blankable();
	if ( ! is_array( $stored ) ) { $stored = []; }

	$out = [];
	foreach ( $defaults as $name => $default ) {
		$has   = array_key_exists( $name, $stored );
		$value = $has ? $stored[ $name ] : null;
		if ( 'enabled' === $name ) {
			$out[ $name ] = $has ? (int) (bool) $value : $default;
			continue;
		}
		if ( in_array( $name, $blankable, true ) ) {
			// Saved-and-empty is a real choice; only never-saved falls back.
			$out[ $name ] = ( ! $has || null === $value ) ? $default : $value;
			continue;
		}
		// n8nchat_value_is_empty() rather than a bare '' test: a `list` field stores an array, and
		// an empty array is its equivalent of an empty string. Compared as '' it is never equal, so
		// a cleared starter-prompt list would be returned as [] instead of falling back to default.
		$out[ $name ] = ( ! $has || null === $value || n8nchat_value_is_empty( $name, $value ) )
			? $default
			: $value;
	}
	return $out;
}

/**
 * Register the setting itself (native path only).
 *
 * This is the store contract — which option row, and which sanitiser guards it — so it stays here
 * beside the reader and the sanitiser rather than moving to the screen that happens to submit it.
 * The screen is inc/admin/page.php; it renders the fields and posts to options.php, which is what
 * makes this registration the thing that actually authorises the save.
 */
add_action( 'admin_init', function () {
	if ( n8nchat_uses_acf() ) { return; }

	register_setting( 'n8nchat_settings_group', N8NCHAT_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'n8nchat_sanitize_options',
		'default'           => n8nchat_defaults(),
	] );
} );

/**
 * Sanitize a settings array, driven entirely by inc/schema.php.
 *
 * Rebuilds from the defaults so unknown keys are dropped, and keeps empty strings as empty strings:
 * the empty->default fallback belongs to the READERS (n8nchat_native_get() and the ACF branch of
 * n8nchat_settings()), which also decide which fields may legitimately stay blank. This function
 * never substitutes a default for an empty value, so it is safe to run over an already-resolved
 * array without undoing a deliberate blank.
 *
 * Used on BOTH paths: as the native setting's sanitize_callback (save time) and as the ACF path's
 * read-time filter, because ACF's own field types apply no escaping whatsoever. Everything here is
 * therefore IDEMPOTENT — it is applied twice to any value that round-trips native -> ACF via the
 * store migration in inc/settings.php, and a rule that is not stable under a second application
 * would corrupt configuration on a flip rather than merely being untidy.
 *
 * The `is_scalar()` guards are not paranoia: on the ACF path this array comes straight out of the
 * options store, and a field group edited by hand, a repurposed field key, or a restored backup
 * from a different schema version can all hand us an array where a string is expected.
 */
function n8nchat_sanitize_options( $input ) {
	$schema = n8nchat_schema();
	$input  = is_array( $input ) ? $input : [];
	$out    = [];

	foreach ( $schema as $name => $field ) {
		$raw = array_key_exists( $name, $input ) ? $input[ $name ] : null;
		$out[ $name ] = n8nchat_sanitize_value( $name, $field, $raw );
	}

	/**
	 * Filter the sanitised settings array.
	 *
	 * Runs after every field has been through its type's rule, so a filter here is the last word.
	 * Anything added must be idempotent for the reason given above.
	 *
	 * @param array $out   Sanitised settings.
	 * @param array $input The raw array as submitted or stored.
	 */
	return (array) apply_filters( 'n8nchat_sanitize_options', $out, $input );
}

/**
 * Sanitise one value according to its schema type.
 *
 * Split out from the loop above so the admin screen can validate a single field for live feedback
 * without round-tripping the whole array, and so each rule can be read on its own.
 */
function n8nchat_sanitize_value( $name, $field, $raw ) {
	$type    = $field['type'];
	$default = $field['default'];

	// A never-submitted checkbox is absent rather than falsy, so `bool` has to treat null as 0 —
	// which is exactly what an unticked box means on a POSTed form.
	if ( 'bool' === $type ) {
		return empty( $raw ) ? 0 : 1;
	}

	if ( 'list' === $type ) {
		// Accepts either the array the store holds or the newline-separated block the admin
		// textarea submits, so the form needs no marshalling of its own.
		if ( is_string( $raw ) ) {
			$raw = preg_split( '/\r\n|\r|\n/', $raw );
		}
		if ( ! is_array( $raw ) ) { return []; }
		$item_type = isset( $field['items'] ) ? $field['items'] : 'text';
		$max       = isset( $field['max_items'] ) ? (int) $field['max_items'] : 50;
		$out       = [];
		foreach ( $raw as $item ) {
			if ( ! is_scalar( $item ) ) { continue; }
			$item = ( 'url' === $item_type )
				? esc_url_raw( trim( (string) $item ), [ 'http', 'https' ] )
				: sanitize_text_field( (string) $item );
			// Blank lines are how a person deletes an entry; keeping them would leave empty chips.
			if ( '' === $item ) { continue; }
			$out[] = $item;
			if ( count( $out ) >= $max ) { break; }
		}
		// Reindexed on purpose: the value is JSON-encoded for the front end, and a sparse PHP array
		// encodes as an object rather than an array, which the widget would not iterate.
		return array_values( $out );
	}

	if ( ! is_scalar( $raw ) ) {
		// Not a value at all — an absent key, or an array where a string belongs.
		//
		// The type decides what that means, and getting it wrong breaks IDEMPOTENCE rather than
		// anything visible. These three have no empty representation: '' is not a colour, not one of
		// a select's options, and not a number. Returning '' for them made the FIRST pass produce ''
		// and the SECOND pass — which sees a genuine string and applies the real rule — produce the
		// default, so the same input sanitised twice gave two different answers. On a site that
		// round-trips its settings between the ACF and native stores, that is a configuration that
		// changes on its own during a migration.
		//
		// Every other type stores strings, so '' is a real value there: it means "never set" to the
		// readers, which substitute the default on the way out, except for the n8nchat_blankable()
		// fields where a blank is the admin's actual choice and must survive.
		if ( in_array( $type, [ 'color', 'select', 'number' ], true ) ) { return $default; }
		return '';
	}

	$raw = (string) $raw;

	switch ( $type ) {
		case 'url':
			// Explicit protocol whitelist. esc_url_raw()'s default list also permits feed:, telnet:,
			// sms: and friends; the widget only ever POSTs over HTTP(S), and webhook_url decides
			// where every visitor's conversation is sent, so nothing else has any business here.
			return esc_url_raw( trim( $raw ), [ 'http', 'https' ] );

		case 'image':
			return esc_url_raw( trim( $raw ), [ 'http', 'https' ] );

		case 'email':
			$email = sanitize_email( trim( $raw ) );
			return $email ? $email : '';

		case 'textarea':
			return sanitize_textarea_field( $raw );

		case 'color':
			$color = sanitize_hex_color( trim( $raw ) );
			return $color ? $color : $default;

		case 'select':
			$options = isset( $field['options'] ) ? $field['options'] : [];
			return array_key_exists( $raw, $options ) ? $raw : $default;

		case 'number':
			if ( '' === trim( $raw ) || ! is_numeric( $raw ) ) { return $default; }
			$n = (int) round( (float) $raw );
			if ( isset( $field['min'] ) ) { $n = max( (int) $field['min'], $n ); }
			if ( isset( $field['max'] ) ) { $n = min( (int) $field['max'], $n ); }
			return $n;

		case 'css':
			// This lands inside a <style> element. The HTML tokenizer ends <style> RAWTEXT at the
			// first "</style" regardless of CSS quoting, so angle brackets are removed outright
			// rather than escaped — there is no escaping that survives that parse. Control
			// characters go too, since a raw newline inside a CSS string is a parse error that
			// takes the rest of the block with it. Comments are left alone; they are legitimate.
			$css = str_replace( [ '<', '>' ], '', $raw );
			$css = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $css );
			return (string) n8nchat_mb_substr( $css, 0, 20000 );

		default: // text
			return sanitize_text_field( $raw );
	}
}

/**
 * mb_substr() where it exists, substr() where it does not.
 *
 * The plugin declares no "Requires PHP" header, and WordPress only polyfills mb_substr() in more
 * recent builds, so a host without mbstring would fatal on a direct call. A cut multibyte character
 * at a 20,000-byte boundary in a CSS blob is a cosmetic problem; a fatal on every settings save is
 * not.
 */
function n8nchat_mb_substr( $string, $start, $length ) {
	return function_exists( 'mb_substr' )
		? mb_substr( $string, $start, $length )
		: substr( $string, $start, $length );
}
