<?php
/**
 * The settings resolver, and the ACF-vs-native path detection it depends on.
 *
 * These five functions lived in n8n-chatbot.php until they were found to defeat the duplicate-copy
 * guard there. PHP EARLY-BINDS unconditional top-level function declarations when a file is
 * COMPILED, which happens before any statement in that file runs — so the guard's `return`, however
 * early it sits, cannot stop a second copy's function declarations colliding with the first's. The
 * process fatals at compile time with "Cannot redeclare n8nchat_defaults()", and the guard never
 * executes at all.
 *
 * Moving them into a file that is `require_once`d AFTER the guard is what makes the guard real: a
 * second copy returns before the require, so nothing here is ever compiled twice.
 *
 * Verified on a site that genuinely had two copies on disk. See the guard's own comment in
 * n8n-chatbot.php.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Default field values, key => default.
 *
 * Derived from inc/schema.php, which is the single source of truth: the same array drives the ACF
 * field group's default_value, the native form, the sanitiser, the store fingerprint and the
 * runtime fallback when a field is empty. Adding a setting means editing the schema and nothing
 * else. This wrapper stays because it is the name five other files and both test suites already
 * call, and because the shape (a flat key => value map) is the contract they rely on.
 *
 * Note `webhook_url` defaults to '' on purpose: the widget refuses to render without a webhook
 * (see `n8nchat_active()` in inc/render.php), so a freshly-installed, unconfigured site shows
 * nothing rather than pointing visitors at someone else's bot.
 */
function n8nchat_defaults() {
	return n8nchat_schema_defaults();
}

/**
 * Settings whose value is allowed to be a deliberate empty string.
 *
 * For every other field "empty" means "never configured" and the reader substitutes the default.
 * For these, blank is a real choice both admin UIs explicitly offer in their own words — an empty
 * `bot_label` hides the sender names above every message, an empty `subtitle` drops the header
 * subtitle — so the readers must let '' through untouched instead of coercing it back.
 *
 * Shared by BOTH readers (the ACF branch of n8nchat_settings() and n8nchat_native_get()) on
 * purpose: the two paths previously coerced independently and drifted, which is what made the
 * documented "leave blank to hide sender labels entirely" behaviour literally unreachable. It is
 * now derived from the schema's own `blankable` flag, so the two can no longer disagree and a new
 * field declares its own answer next to its default.
 */
function n8nchat_blankable() {
	return n8nchat_schema_blankable();
}

/**
 * The ACF field key for a given setting (read by KEY on the options page so each field's
 * default_value resolves before Site Options is first saved — same convention the theme uses).
 */
function n8nchat_field_key( $name ) {
	return 'field_n8nchat_' . $name;
}

/**
 * Whether to use the ACF path (read settings via an ACF options page) rather than the native
 * settings page. True only when ACF Pro is active AND an options page with our target slug is
 * actually registered — so ACF-free sites, and ACF-Pro sites that don't register our page, use
 * the native path (and never get an orphan ACF tab pointing at a missing page).
 *
 * NB: `acf_get_options_page()` reads ACF's store, which is populated on `acf/init`. Do not call
 * this before `acf/init` has fired. All callers (front-end enqueue/footer, admin_menu/admin_init,
 * and inc/settings.php at acf/init priority 20) run late enough.
 *
 * The `n8nchat_uses_acf` filter can only ever narrow the answer, never widen it: the capability
 * check below is a HARD gate that no filter can override. Previously the filter was applied on
 * both sides of that check, so `add_filter( 'n8nchat_uses_acf', '__return_true' )` on a site
 * without ACF sent n8nchat_settings() straight into an undefined get_field() from
 * wp_enqueue_scripts — a fatal on every single front-end request. Forcing the ACF path on is
 * therefore only honoured when ACF is genuinely loadable; forcing it OFF still works everywhere.
 */
function n8nchat_uses_acf() {
	if ( ! function_exists( 'acf_get_options_page' ) || ! function_exists( 'get_field' ) ) {
		return false;
	}
	$slug = apply_filters( 'n8nchat_options_page', 'fsc-site-options' );
	$page = acf_get_options_page( $slug );
	return (bool) apply_filters( 'n8nchat_uses_acf', ! empty( $page ) );
}

/**
 * Resolved settings, read from whichever store is active (ACF options tab or the native option).
 * Both branches apply the same three rules — an unset field falls back to its default, an explicit
 * `0` is respected for the `enabled` toggle, and the n8nchat_blankable() fields keep a deliberate
 * empty string — and both return values that have been through n8nchat_sanitize_options(). So the
 * array is identical whichever store produced it and `inc/render.php` is agnostic to the source.
 * This is the single read seam, and the single sanitisation seam.
 */
function n8nchat_settings() {
	$defaults = n8nchat_defaults();

	if ( ! n8nchat_uses_acf() ) {
		// Already sanitised on save by n8nchat_sanitize_options() (registered as the setting's
		// sanitize_callback), so the native reader hands back trusted values.
		return n8nchat_native_get();
	}

	$blankable = n8nchat_blankable();

	$out = [];
	foreach ( $defaults as $name => $default ) {
		$value = get_field( n8nchat_field_key( $name ), 'option' );
		if ( 'enabled' === $name ) {
			// true_false: respect an explicit 0; only fall back when truly unset (null).
			$out[ $name ] = ( null === $value ) ? $default : (int) (bool) $value;
			continue;
		}
		if ( in_array( $name, $blankable, true ) ) {
			// A saved empty string here is an intentional blank and must survive; only a field
			// that was never given a value at all (null/false) falls back to the default.
			$out[ $name ] = ( null === $value || false === $value ) ? $default : $value;
			continue;
		}
		// n8nchat_value_is_empty() rather than a bare '' test: a `list` field stores an array, and
		// an empty array is its equivalent of an empty string. Compared as '' it is never equal, so
		// a cleared starter-prompt list would have been returned as [] instead of falling back.
		$out[ $name ] = ( null === $value || false === $value || n8nchat_value_is_empty( $name, $value ) )
			? $default
			: $value;
	}

	/*
	 * Sanitise on READ, because the ACF path has no save-time hook of its own: ACF's text/url
	 * fields ship no update_value filter and apply no kses, so whatever an editor typed on Site
	 * Options → Chatbot was previously returned completely raw. That mattered a great deal —
	 * bot_label
	 * and user_label are interpolated into an inline <style> block, and webhook_url is where every
	 * visitor's conversation is POSTed. ACF options pages default to 'capability' => 'edit_posts',
	 * so that is Editor-level reach.
	 *
	 * Running the resolved array through the very same sanitiser the native path uses on save is
	 * what makes the two paths genuinely equivalent. It cannot double-apply the empty→default
	 * coercion (that has already happened above, and the sanitiser never substitutes defaults for
	 * empty strings) and it preserves an explicit `enabled` 0, which arrives here as int 0.
	 */
	return n8nchat_sanitize_options( $out );
}
