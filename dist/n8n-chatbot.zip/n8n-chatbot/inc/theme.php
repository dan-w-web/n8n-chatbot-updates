<?php
/**
 * Colour maths and the design-token layer.
 *
 * The contrast helpers below moved here verbatim from inc/render.php, where they were the most
 * reusable thing in the plugin and the hardest to justify leaving next to the enqueue code. They
 * exist because `primary_color` is a free-form picker with no luminance check: a client picks
 * #f5c518 and, with white ink hardcoded, gets 1.7:1 — a WCAG 1.4.3 AA failure on the most visible
 * surface the widget has. Everything that sits on the brand colour, or uses it AS text, is derived
 * rather than assumed.
 *
 * v2.0 adds the token layer on top. The widget renders inside a shadow root and reads exclusively
 * from CSS custom properties set on its host element, so this file is the ONLY place that decides
 * what anything looks like. Both themes are emitted at once — light on the host, dark inside a
 * `prefers-color-scheme` block or forced by a class — because the visitor's system setting is not
 * knowable at render time and a round trip to find out would be a flash of the wrong theme.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Normalise a hex colour to a bare 6-digit "rrggbb", or '' when it is not one.
 * Shared by every colour helper below so "is this really a colour?" is decided once.
 */
function n8nchat_hex6( $hex ) {
	$hex = ltrim( (string) $hex, '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	return preg_match( '/^[0-9a-fA-F]{6}$/', $hex ) ? $hex : '';
}

/**
 * A safe hex colour for direct CSS interpolation. Anything that is not one becomes the default.
 */
function n8nchat_safe_color( $c ) {
	$c = sanitize_hex_color( (string) $c );
	if ( $c ) { return $c; }
	$defaults = n8nchat_schema_defaults();
	return isset( $defaults['primary_color'] ) ? $defaults['primary_color'] : '#2f6fed';
}

/**
 * Darken a hex colour by $pct percent (toward black). Returns "#rrggbb".
 */
function n8nchat_shade( $hex, $pct ) {
	$hex = n8nchat_hex6( $hex );
	// Not a colour -> hand back the plugin default. The old behaviour ("#" . $hex) put unvalidated
	// input straight into a CSS declaration; unreachable today because the only callers pass
	// n8nchat_safe_color() output, but this can never become reachable.
	if ( '' === $hex ) { return n8nchat_safe_color( '' ); }
	$f   = 1 - ( max( 0, min( 100, $pct ) ) / 100 );
	$out = '#';
	for ( $i = 0; $i < 3; $i++ ) {
		$c    = hexdec( substr( $hex, $i * 2, 2 ) );
		$out .= str_pad( dechex( (int) round( $c * $f ) ), 2, '0', STR_PAD_LEFT );
	}
	return $out;
}

/**
 * Lighten a hex colour by $pct percent (toward white). The mirror of n8nchat_shade(), and what the
 * dark theme needs: on a #16171b surface a brand colour usually has to come UP to stay readable,
 * and darkening it further — the only move v1 could make — took it the wrong way.
 */
function n8nchat_tint( $hex, $pct ) {
	$hex = n8nchat_hex6( $hex );
	if ( '' === $hex ) { return n8nchat_safe_color( '' ); }
	$f   = max( 0, min( 100, $pct ) ) / 100;
	$out = '#';
	for ( $i = 0; $i < 3; $i++ ) {
		$c    = hexdec( substr( $hex, $i * 2, 2 ) );
		$out .= str_pad( dechex( (int) round( $c + ( 255 - $c ) * $f ) ), 2, '0', STR_PAD_LEFT );
	}
	return $out;
}

/**
 * "r, g, b" triplet for a hex colour, for use in rgba(var(--wwc-accent-rgb), a).
 */
function n8nchat_rgb( $hex ) {
	$hex = n8nchat_hex6( $hex );
	if ( '' === $hex ) { return '47, 111, 237'; }
	return hexdec( substr( $hex, 0, 2 ) ) . ', ' . hexdec( substr( $hex, 2, 2 ) ) . ', ' . hexdec( substr( $hex, 4, 2 ) );
}

/**
 * WCAG 2.x relative luminance (0 = black, 1 = white) for a hex colour.
 */
function n8nchat_luminance( $hex ) {
	$hex = n8nchat_hex6( $hex );
	if ( '' === $hex ) { return 0.0; }
	$weights = [ 0.2126, 0.7152, 0.0722 ];
	$lum     = 0.0;
	for ( $i = 0; $i < 3; $i++ ) {
		$c    = hexdec( substr( $hex, $i * 2, 2 ) ) / 255;
		$c    = ( 0.03928 >= $c ) ? $c / 12.92 : pow( ( $c + 0.055 ) / 1.055, 2.4 );
		$lum += $weights[ $i ] * $c;
	}
	return $lum;
}

/**
 * WCAG contrast ratio between two hex colours (1 = identical, 21 = black on white).
 */
function n8nchat_contrast( $a, $b ) {
	$la = n8nchat_luminance( $a );
	$lb = n8nchat_luminance( $b );
	return ( max( $la, $lb ) + 0.05 ) / ( min( $la, $lb ) + 0.05 );
}

/**
 * The readable "ink" to lay over a set of backgrounds — white or near-black, whichever reads better
 * across EVERY one of them.
 *
 * A single sample is not enough where the surface is a gradient or where the same ink covers both a
 * flat bubble and a darker hover state: white ink improves as the surface darkens, dark ink gets
 * worse. Each candidate is therefore scored on its WORST surface and the winner taken.
 */
function n8nchat_on_color( $backgrounds ) {
	$white = '#ffffff';
	$dark  = '#141518';
	$w_min = 21.0;
	$d_min = 21.0;
	foreach ( $backgrounds as $bg ) {
		$w_min = min( $w_min, n8nchat_contrast( $white, $bg ) );
		$d_min = min( $d_min, n8nchat_contrast( $dark, $bg ) );
	}
	return ( $d_min > $w_min ) ? $dark : $white;
}

/**
 * The brand colour adjusted until it is legible AS TEXT on a given surface.
 *
 * Links, chips, the sender name and the focus ring are all brand-coloured text, so a light brand
 * fails on a light surface for exactly the reason it fails as a background — and a dark brand fails
 * on the dark theme. Walks toward whichever end of the scale increases contrast with $surface and
 * returns the first step that clears AA (4.5:1), or the nearest end if nothing does.
 *
 * v1's equivalent only ever darkened, because it only ever had a white surface to sit on.
 */
function n8nchat_readable_on( $hex, $surface ) {
	$base = n8nchat_safe_color( $hex );
	if ( 4.5 <= n8nchat_contrast( $base, $surface ) ) { return $base; }

	// Darken against a light surface, lighten against a dark one.
	$lighten = n8nchat_luminance( $surface ) < 0.18;
	for ( $pct = 5; $pct <= 90; $pct += 5 ) {
		$try = $lighten ? n8nchat_tint( $base, $pct ) : n8nchat_shade( $base, $pct );
		if ( 4.5 <= n8nchat_contrast( $try, $surface ) ) { return $try; }
	}
	return $lighten ? '#ffffff' : '#141518';
}

/**
 * The brand colour, nudged only as far as it must be to carry readable text.
 *
 * n8nchat_on_color() picks the better of white and near-black, but "better" is not "good enough".
 * There is a narrow band of mid-tone colours — roughly 0.17 to 0.21 relative luminance, which is
 * most mid greys and several perfectly ordinary corporate blues and greens — where NEITHER ink
 * reaches 4.5:1. A brand in that band is not a colour that text can sit on, whatever ink you choose.
 *
 * Rather than ship a WCAG failure or silently ignore the client's colour, the surface itself moves,
 * in whichever direction the better ink already prefers: white ink wants a darker surface, dark ink
 * wants a lighter one. Steps are small and it stops at the first that clears AA, so a brand that is
 * already fine is returned untouched (the overwhelmingly common case, checked first) and one that
 * is not shifts by the minimum that makes it legible.
 *
 * This is the same move a tonal palette makes, and it is confined to the surfaces text sits on —
 * the launcher and the visitor's own messages. Nothing else repaints.
 */
function n8nchat_accent_surface( $hex ) {
	$base = n8nchat_safe_color( $hex );
	$ink  = n8nchat_on_color( [ $base ] );
	if ( 4.5 <= n8nchat_contrast( $ink, $base ) ) { return $base; }

	// Dark ink is winning but falling short -> lighten. White ink is winning -> darken.
	$lighten = ( '#ffffff' !== $ink );
	for ( $pct = 4; $pct <= 64; $pct += 4 ) {
		$try = $lighten ? n8nchat_tint( $base, $pct ) : n8nchat_shade( $base, $pct );
		if ( 4.5 <= n8nchat_contrast( n8nchat_on_color( [ $try ] ), $try ) ) { return $try; }
	}
	return $base;
}

/**
 * CSS string literal from a label, e.g. He said "hi" -> "He said \"hi\"".
 *
 * Backslash/quote escaping alone is NOT enough here: this lands inside a <style> element, and the
 * HTML tokenizer ends <style> RAWTEXT at the first "</style" no matter how the CSS quotes it — so a
 * label of `x</style><script ...>` would break out and execute. Angle brackets are therefore removed
 * outright, along with control characters (a raw newline inside a CSS string is a parse error and
 * would take the rest of the block down with it). Defence in depth: the sanitiser strips them too.
 */
function n8nchat_css_string( $label ) {
	$label = str_replace( [ '<', '>' ], '', (string) $label );
	$label = preg_replace( '/[\x00-\x1F\x7F]/', '', $label );
	return '"' . str_replace( [ '\\', '"' ], [ '\\\\', '\\"' ], (string) $label ) . '"';
}

/**
 * A CSS length from a numeric setting, clamped to the schema's own min/max.
 *
 * Numbers reach here already sanitised, so this is belt-and-braces against a filter or a hand-edited
 * option row putting something unbounded into a declaration.
 */
function n8nchat_css_px( $name, $value ) {
	$field = n8nchat_field( $name );
	$n     = is_numeric( $value ) ? (float) $value : (float) $field['default'];
	if ( isset( $field['min'] ) ) { $n = max( (float) $field['min'], $n ); }
	if ( isset( $field['max'] ) ) { $n = min( (float) $field['max'], $n ); }
	return ( 0 == $n - (int) $n ) ? (string) (int) $n : (string) $n;
}

/**
 * The density scale. Compact is not simply "smaller" — the type stays at a readable size and only
 * the spacing tightens, because shrinking body text is the first thing that makes a widget feel
 * cheap and the first thing that fails an accessibility review.
 */
function n8nchat_density_scale( $density ) {
	if ( 'compact' === $density ) {
		return [ 'gap' => '10px', 'pad' => '12px', 'row' => '10px', 'msg' => '14px' ];
	}
	return [ 'gap' => '14px', 'pad' => '16px', 'row' => '14px', 'msg' => '15px' ];
}

/**
 * Every design token, for both themes, derived from the resolved settings.
 *
 * Returns [ 'base' => [...], 'light' => [...], 'dark' => [...] ] where 'base' holds the tokens that
 * do not change with the colour scheme (geometry, motion, type) and the other two hold the ones
 * that do. Kept as data rather than emitted directly so the admin live preview can hand the same
 * structure to the iframe over postMessage without re-deriving anything client-side.
 */
function n8nchat_tokens( $s ) {
	// The surface text actually sits on, which is the brand colour itself for all but the narrow
	// band of mid-tones that cannot carry text at all. See n8nchat_accent_surface().
	$accent = n8nchat_accent_surface( $s['primary_color'] );
	$d      = n8nchat_density_scale( isset( $s['density'] ) ? $s['density'] : 'comfortable' );

	// Light theme surfaces.
	$l_bg      = '#ffffff';
	$l_sunken  = '#f7f8fa';
	$l_ink     = '#1a1d21';
	$l_muted   = '#6b7280';
	$l_line    = '#e7e9ee';

	// Dark theme surfaces. Deliberately not pure black: #000 with light text produces halation that
	// measurably slows reading, and every mainstream dark UI settled on a raised near-black instead.
	$d_bg      = '#16171b';
	$d_sunken  = '#1e2025';
	$d_ink     = '#e8e8f0';
	$d_muted   = '#9aa0aa';
	$d_line    = '#2b2e35';

	// The launcher and the visitor's own messages sit ON the accent in both themes, so the ink is
	// chosen once against that surface and the hover state is then derived in whichever direction
	// PRESERVES it: white ink gets better as the surface darkens, dark ink gets better as it
	// lightens. Always darkening — as v1 did, because it only ever had white ink to serve — took a
	// dark-ink accent the wrong way and quietly broke contrast on hover only, which is exactly the
	// state nobody screenshots.
	$on_accent    = n8nchat_on_color( [ $accent ] );
	$accent_hover = ( '#ffffff' === $on_accent )
		? n8nchat_shade( $accent, 12 )
		: n8nchat_tint( $accent, 12 );

	$base = [
		'--wwc-font'            => '' !== trim( (string) $s['font_family'] )
			? $s['font_family']
			: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
		'--wwc-font-mono'       => 'ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace',
		'--wwc-font-size'       => $d['msg'],
		'--wwc-line-height'     => '1.6',
		'--wwc-radius-window'   => n8nchat_css_px( 'corner_radius', $s['corner_radius'] ) . 'px',
		'--wwc-radius-bubble'   => '16px',
		'--wwc-radius-input'    => '14px',
		'--wwc-radius-chip'     => '999px',
		'--wwc-gap'             => $d['gap'],
		'--wwc-pad'             => $d['pad'],
		'--wwc-row-gap'         => $d['row'],
		'--wwc-launcher-size'   => n8nchat_css_px( 'launcher_size', $s['launcher_size'] ) . 'px',
		'--wwc-window-width'    => n8nchat_css_px( 'window_width', $s['window_width'] ) . 'px',
		'--wwc-window-height'   => n8nchat_css_px( 'window_height', $s['window_height'] ) . 'px',
		'--wwc-offset-x'        => n8nchat_css_px( 'offset_x', $s['offset_x'] ) . 'px',
		'--wwc-offset-y'        => n8nchat_css_px( 'offset_y', $s['offset_y'] ) . 'px',
		'--wwc-z'               => n8nchat_css_px( 'z_index', $s['z_index'] ),
		'--wwc-motion-fast'     => '120ms',
		'--wwc-motion-base'     => '240ms',
		'--wwc-ease'            => 'cubic-bezier(.4, 0, .2, 1)',
		'--wwc-accent'          => $accent,
		'--wwc-accent-rgb'      => n8nchat_rgb( $accent ),
		'--wwc-accent-hover'    => $accent_hover,
		'--wwc-on-accent'       => $on_accent,
		'--wwc-on-accent-rgb'   => n8nchat_rgb( $on_accent ),
	];

	$light = [
		'--wwc-bg'          => $l_bg,
		'--wwc-sunken'      => $l_sunken,
		'--wwc-ink'         => $l_ink,
		'--wwc-muted'       => $l_muted,
		'--wwc-line'        => $l_line,
		'--wwc-accent-ink'  => n8nchat_readable_on( $accent, $l_bg ),
		'--wwc-code-bg'     => '#f2f4f8',
		'--wwc-shadow'      => '0 18px 50px rgba(17, 28, 45, .22)',
		'--wwc-shadow-soft' => '0 2px 8px rgba(17, 28, 45, .10)',
	];

	$dark = [
		'--wwc-bg'          => $d_bg,
		'--wwc-sunken'      => $d_sunken,
		'--wwc-ink'         => $d_ink,
		'--wwc-muted'       => $d_muted,
		'--wwc-line'        => $d_line,
		'--wwc-accent-ink'  => n8nchat_readable_on( $accent, $d_bg ),
		'--wwc-code-bg'     => '#101216',
		'--wwc-shadow'      => '0 18px 50px rgba(0, 0, 0, .55)',
		'--wwc-shadow-soft' => '0 2px 8px rgba(0, 0, 0, .40)',
	];

	/**
	 * Filter the derived design tokens.
	 *
	 * The last word on appearance before anything is printed, and the supported way to theme the
	 * widget beyond what the settings screen exposes.
	 *
	 * @param array $tokens ['base'=>[], 'light'=>[], 'dark'=>[]] of CSS custom properties.
	 * @param array $s      Resolved plugin settings.
	 */
	return (array) apply_filters( 'n8nchat_tokens', [ 'base' => $base, 'light' => $light, 'dark' => $dark ], $s );
}

/**
 * A `--name: value;` run from a token array, with every value passed through the same guard that
 * protects the <style> element. Values reach here from sanitised settings, but font_family is
 * free text and the filter above can put anything in, so nothing is trusted at this seam.
 */
function n8nchat_tokens_declarations( $tokens ) {
	$css = '';
	foreach ( $tokens as $prop => $value ) {
		if ( ! preg_match( '/^--[a-z0-9-]+$/', $prop ) ) { continue; }
		$value = str_replace( [ '<', '>', ';', '{', '}' ], '', (string) $value );
		$value = preg_replace( '/[\x00-\x1F\x7F]/', '', $value );
		$css  .= $prop . ':' . trim( $value ) . ';';
	}
	return $css;
}

/**
 * The complete stylesheet fragment that themes one widget instance.
 *
 * `$host` is the selector the widget's own host element matches. Inside a shadow root that is
 * `:host`; on the admin preview page it is an id. The dark half is emitted twice on purpose — once
 * behind `prefers-color-scheme` for the "auto" setting and once behind an explicit attribute — so
 * that forcing a scheme wins over the system preference in BOTH directions, which a single media
 * query cannot do.
 */
function n8nchat_theme_css( $s, $host = ':host' ) {
	$t      = n8nchat_tokens( $s );
	$scheme = isset( $s['color_scheme'] ) ? $s['color_scheme'] : 'auto';

	$base  = n8nchat_tokens_declarations( $t['base'] );
	$light = n8nchat_tokens_declarations( $t['light'] );
	$dark  = n8nchat_tokens_declarations( $t['dark'] );

	// Light is the ground state, so a token that only exists there is never undefined.
	$css = $host . '{' . $base . $light . '}';

	if ( 'dark' === $scheme ) {
		$css .= $host . '{' . $dark . '}';
	} elseif ( 'auto' === $scheme ) {
		$css .= '@media (prefers-color-scheme: dark){' . $host . ':not([data-wwc-scheme="light"]){' . $dark . '}}';
		$css .= $host . '[data-wwc-scheme="dark"]{' . $dark . '}';
	}

	return $css;
}
