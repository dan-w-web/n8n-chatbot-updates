<?php
/**
 * ACF settings path: the "Chatbot" branding tab on the theme's ACF options page (Site Options),
 * the "no webhook set" admin notice, and the one-time migration between the two stores.
 *
 * The field group is registered as the plugin's own, attached to the theme's options page, so it
 * adds a tab without editing the theme. The target page defaults to the FSC theme's
 * "fsc-site-options" menu slug; override it for a different theme with:
 *
 *     add_filter( 'n8nchat_options_page', fn() => 'my-theme-options' );
 *
 * Field labels and instructions are kept word-for-word in step with n8nchat_native_fields() in
 * inc/native-settings.php, so a site owner sees the same guidance whichever UI they land on.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// Priority 20: run after the theme's acf_add_options_page() (priority 10) so n8nchat_uses_acf()
// can see whether our target options page is actually registered.
add_action( 'acf/init', function () {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) { return; }
	// Only register the ACF tab when the ACF path is active; otherwise the native settings page
	// (inc/native-settings.php) provides the UI and this tab would be an orphan.
	if ( ! n8nchat_uses_acf() ) { return; }

	$page = apply_filters( 'n8nchat_options_page', 'fsc-site-options' );

	acf_add_local_field_group( [
		'key'      => 'group_n8nchat',
		'title'    => 'Chatbot',
		'fields'   => n8nchat_acf_fields(),
		'location' => [ [ [ 'param' => 'options_page', 'operator' => '==', 'value' => $page ] ] ],
		'active'   => true,
	] );
}, 20 );

/**
 * Build the ACF field array from inc/schema.php.
 *
 * Generated rather than written out, for the same reason everything else is: the labels and help
 * text here were previously kept "word-for-word in step" with the native form by hand, which is a
 * promise no one can keep across fifty fields. Both UIs now read the same strings from the same
 * place, so they cannot describe the same setting differently.
 *
 * Each settings group becomes an ACF tab, so the Chatbot tab on the theme's options page opens onto
 * the same Connection / Appearance / Messages / Behaviour / Handoff / Advanced structure as the
 * native screen.
 */
function n8nchat_acf_fields() {
	// A field the current user may not change is omitted rather than disabled, so nobody is shown a
	// control whose value would be thrown away — and so `handoff_webhook` stays out of the page
	// source. The chat webhook is printed in every front-end page anyway and is no secret; the
	// address leads are copied to has never been public and should not start being so on a screen
	// an Editor can open.
	$editing = ! function_exists( 'is_admin' ) || is_admin();

	/*
	 * No wrapper tab.
	 *
	 * There used to be one here, labelled "Chatbot", meant to put the whole group behind a single
	 * tab on a shared options page. ACF tabs do not nest — a tab simply starts a new section and
	 * runs until the next one — and the very next element added below is itself a tab, so the
	 * wrapper was guaranteed to contain no fields at all. On a live site it rendered as a first tab
	 * that opened onto nothing, which reads as a broken settings page rather than as a heading.
	 *
	 * The metabox ACF draws around this group already carries the group title, so the wrapper was
	 * never conveying anything the screen did not already say.
	 */
	$fields = [];

	foreach ( n8nchat_groups() as $group => $meta ) {
		$in_group = n8nchat_group_fields( $group );
		if ( empty( $in_group ) ) { continue; }

		$fields[] = [
			'key'          => 'field_n8nchat_group_' . $group,
			'label'        => $meta['label'],
			'type'         => 'tab',
			'placement'    => 'left',
			'instructions' => $meta['help'],
		];

		$hidden = 0;
		foreach ( $in_group as $name => $field ) {
			// ONLY in wp-admin. `acf/init` fires on every request, including anonymous front-end
			// ones, and inc/render.php resolves settings through get_field() BY KEY — which returns
			// null for a key no registered group contains. Filtering the group unconditionally
			// therefore does not hide a control from an Editor; it unregisters the webhook for every
			// visitor on the site, and the widget disappears. The capability question belongs to the
			// screen that renders the form, not to the group that defines the data.
			if ( $editing && ! n8nchat_can_edit_field( $name ) ) { $hidden++; continue; }
			$fields[] = n8nchat_acf_field( $name, $field );
		}

		if ( $hidden ) {
			$fields[] = [
				'key'     => 'field_n8nchat_locked_' . $group,
				'label'   => '',
				'name'    => '',
				'type'    => 'message',
				'message' => sprintf(
					/* translators: %d: number of settings hidden from this user. */
					_n(
						'%d setting on this tab decides where data is sent or how long it is kept, and can only be changed by an administrator.',
						'%d settings on this tab decide where data is sent or how long it is kept, and can only be changed by an administrator.',
						$hidden,
						'n8n-chatbot'
					),
					$hidden
				),
				'new_lines' => 'wpautop',
				'esc_html'  => 1,
			];
		}
	}

	return $fields;
}

/**
 * One schema field as an ACF field definition.
 *
 * ACF is read by KEY rather than by name everywhere in this plugin (see n8nchat_field_key()), so
 * each field's default_value resolves before the options page has ever been saved — the same
 * convention the FSC theme uses.
 */
function n8nchat_acf_field( $name, $field ) {
	$out = [
		'key'           => n8nchat_field_key( $name ),
		'label'         => $field['label'],
		'name'          => 'n8nchat_' . $name,
		'default_value' => $field['default'],
	];

	if ( ! empty( $field['help'] ) ) { $out['instructions'] = $field['help']; }

	switch ( $field['type'] ) {
		case 'bool':
			$out['type'] = 'true_false';
			$out['ui']   = 1;
			break;

		case 'url':
		case 'image':
			// 'image' is a URL here rather than ACF's image field: the native path stores a plain
			// URL string and both stores have to hold the same shape or the migration between them
			// would carry an attachment ID onto a site where that ID means a different file.
			$out['type'] = 'url';
			break;

		case 'email':
			$out['type'] = 'email';
			break;

		case 'textarea':
			$out['type'] = 'textarea';
			$out['rows'] = 3;
			break;

		case 'list':
			// Deliberately a textarea, not a repeater: repeaters are ACF Pro, and they serialise to
			// a row-per-entry structure that the native store — a single option array — cannot
			// mirror. n8nchat_sanitize_value() accepts either the newline block this produces or
			// the array the native path holds, so the two stores stay interchangeable.
			$out['type'] = 'textarea';
			$out['rows'] = 4;
			if ( is_array( $field['default'] ) ) {
				$out['default_value'] = implode( "\n", $field['default'] );
			}
			break;

		case 'color':
			$out['type'] = 'color_picker';
			break;

		case 'select':
			$out['type']    = 'select';
			$out['choices'] = isset( $field['options'] ) ? $field['options'] : [];
			break;

		case 'number':
			$out['type'] = 'number';
			if ( isset( $field['min'] ) ) { $out['min'] = $field['min']; }
			if ( isset( $field['max'] ) ) { $out['max'] = $field['max']; }
			if ( ! empty( $field['unit'] ) ) { $out['append'] = $field['unit']; }
			break;

		case 'css':
			$out['type'] = 'textarea';
			$out['rows'] = 8;
			break;

		default: // text
			$out['type'] = 'text';
			break;
	}

	return $out;
}

/**
 * Refuse a write to an administrator-only setting from somebody who is not one.
 *
 * The field is already omitted from the group above, so on the ACF screen itself this never fires.
 * It exists for every other way a value reaches `acf/update_value`: a filter that re-adds the field,
 * a second field group elsewhere that happens to use our keys, `update_field()` called from theme
 * code running as an Editor, or a hand-crafted POST. The screen's job is to be honest about what a
 * person can change; this one's job is to be right regardless.
 *
 * Returning the STORED value rather than the default is the important detail. Returning a default
 * would let an Editor blank a webhook simply by submitting the form — turning a refused write into
 * a site-wide outage, which is a worse outcome than the write itself.
 *
 * @param mixed  $value   The value ACF is about to store.
 * @param mixed  $post_id The object being saved; 'option'/'options' for an options page.
 * @param array  $field   The ACF field definition.
 */
function n8nchat_acf_guard_value( $value, $post_id, $field ) {
	if ( 'option' !== $post_id && 'options' !== $post_id ) { return $value; }
	if ( empty( $field['key'] ) || 0 !== strpos( $field['key'], 'field_n8nchat_' ) ) { return $value; }

	$name = substr( $field['key'], strlen( 'field_n8nchat_' ) );
	if ( n8nchat_can_edit_field( $name ) ) { return $value; }

	// The row ACF itself would have read. Reading it directly rather than through get_field() keeps
	// this working when the field has just been omitted from the group, which is exactly the state
	// this guard runs in.
	$stored = get_option( n8nchat_acf_option_key( $name ), null );
	if ( null !== $stored ) { return $stored; }

	$defaults = n8nchat_defaults();
	return array_key_exists( $name, $defaults ) ? $defaults[ $name ] : $value;
}
add_filter( 'acf/update_value', 'n8nchat_acf_guard_value', 5, 3 );

/**
 * Flatten an array value before ACF renders it.
 *
 * `list` fields are declared as ACF textareas — deliberately; see n8nchat_acf_field(), where a
 * repeater is rejected because it is ACF Pro and serialises to a shape the native single-option
 * store cannot mirror. The reader accepts either an array or a newline block, which is exactly what
 * keeps the two stores interchangeable, and the NATIVE admin screen has always flattened an array
 * for display (inc/admin/page.php, case 'list'). The ACF screen had no equivalent.
 *
 * That asymmetry is not cosmetic, it is a page-killer. ACF hands the value straight to
 * htmlspecialchars(), which on PHP 8 throws a TypeError when given an array — and a TypeError
 * raised inside one metabox takes down every metabox rendered after it.
 *
 * Seen on a live site on 2026-08-20. Site Options showed four of the Chatbot tabs, no fields under
 * any of them, and none of the THEME's own Site Options at all: the fatal killed the page half-way
 * through rendering, and the theme's group was simply never reached. Nothing in the error log,
 * because the response had already been sent.
 *
 * Any site can arrive here — the native-to-ACF migration copies the array across verbatim, and so
 * does a programmatic update_field() with the value the rest of the plugin uses.
 *
 * `acf/prepare_field` rather than `acf/load_value`, because this is a rendering concern and nothing
 * else: n8nchat_settings() reads the same fields through get_field(), and every consumer of
 * `starter_prompts` and `page_rules` wants the array it has always been given.
 *
 * The key prefix is the safety rail. This filter is global — every field ACF renders on the site
 * passes through it — so it must be incapable of touching a field belonging to the theme or to
 * another plugin, whatever shape that field's value is in.
 */
function n8nchat_acf_display_value( $field ) {
	if ( empty( $field['key'] ) || 0 !== strpos( (string) $field['key'], 'field_n8nchat_' ) ) {
		return $field;
	}
	if ( isset( $field['value'] ) && is_array( $field['value'] ) ) {
		// is_scalar filters out anything nested; implode() on an array-of-arrays would raise the
		// very notice this function exists to prevent.
		$field['value'] = implode( "\n", array_map( 'strval', array_filter( $field['value'], 'is_scalar' ) ) );
	}
	return $field;
}
add_filter( 'acf/prepare_field', 'n8nchat_acf_display_value', 20 );

/**
 * Tell an administrator that their options page is reachable by Editors.
 *
 * Hiding the fields closes the hole, but silently: an administrator wondering why the chatbot tab
 * looks different to a colleague deserves to be told, and more to the point, the honest fix is
 * usually to raise the options page's own capability in the theme rather than to live with a split
 * screen forever.
 */
add_action( 'admin_notices', function () {
	if ( ! n8nchat_uses_acf() || ! current_user_can( 'manage_options' ) ) { return; }
	if ( ! function_exists( 'acf_get_options_page' ) ) { return; }

	$slug = apply_filters( 'n8nchat_options_page', 'fsc-site-options' );
	$page = acf_get_options_page( $slug );
	$cap  = ( is_array( $page ) && ! empty( $page['capability'] ) ) ? $page['capability'] : 'edit_posts';

	// Only worth saying on the screen it applies to.
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || false === strpos( (string) $screen->id, $slug ) ) { return; }

	// A page that already demands manage_options has nothing to warn about.
	if ( 'manage_options' === $cap ) { return; }

	printf(
		'<div class="notice notice-info"><p><strong>%s</strong> %s</p></div>',
		esc_html__( 'Chatbot:', 'n8n-chatbot' ),
		wp_kses_post( sprintf(
			/* translators: %s: the capability the options page requires, e.g. edit_posts. */
			__( 'this options page is available to anyone with <code>%s</code>, so the settings that decide where conversations and enquiries are sent are hidden from non-administrators. Raise the page&#8217;s own capability to <code>manage_options</code> in the theme if everyone who can reach it should be able to change them.', 'n8n-chatbot' ),
			esc_html( $cap )
		) )
	);
} );

/**
 * "Enabled but no webhook" warning for the ACF path.
 *
 * The native settings screen prints an inline notice to the same effect (inc/native-settings.php),
 * but the ACF tab lives on someone else's options page and had no equivalent, so a site owner who
 * left the Webhook URL blank got no feedback at all — the widget simply never appeared and there
 * was nothing to explain why. Gated to manage_options: ACF options pages default to
 * 'capability' => 'edit_posts', and this is a site-configuration problem, not an editor's.
 */
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	if ( ! n8nchat_uses_acf() ) { return; }

	$s = n8nchat_settings();
	if ( empty( $s['enabled'] ) || ! empty( $s['webhook_url'] ) ) { return; }

	$page = apply_filters( 'n8nchat_options_page', 'fsc-site-options' );

	printf(
		'<div class="notice notice-warning"><p><strong>Chatbot:</strong> %s <a href="%s">%s</a></p></div>',
		'the chat widget is enabled but has no <strong>Webhook URL</strong>, so it will not appear on the site.',
		esc_url( admin_url( 'admin.php?page=' . $page ) ),
		'Set it on the Chatbot tab.'
	);
} );

/**
 * ------------------------------------------------------------------------------------------------
 * One-time migration between the two settings stores.
 *
 * The two paths use completely disjoint storage: the native path keeps one serialised array in
 * N8NCHAT_OPTION, the ACF path keeps eleven separate `options_n8nchat_*` rows. `n8nchat_uses_acf()`
 * is re-evaluated live on every request, so which store is authoritative can flip at any moment —
 * a configured non-ACF site that later installs a theme registering an ACF options page silently
 * loses every value to the defaults, `webhook_url` becomes '', the widget vanishes sitewide, and
 * inc/native-settings.php removes the top-level menu so the admin can't even reach what they saved.
 * ACF being deactivated does exactly the same in reverse.
 *
 * Carrying the configuration across a flip is not simply "copy when the new store is empty". The
 * old store is deliberately left intact as a backup, which means that after
 *
 *     native(A) -> gains ACF -> ACF(A) -> admin edits ACF to B -> loses ACF
 *
 * the native store still holds the stale A. A guard that only asks "is the target non-empty?" bails
 * here and the site silently reverts to A — and since webhook_url and bot_id decide which n8n
 * backend and which tenant a live conversation is routed to, that is a correctness and privacy
 * failure, not a cosmetic one.
 *
 * So we distinguish "the target holds a stale copy we wrote" from "the target holds edits somebody
 * made independently" by fingerprinting each store whenever it is authoritative — on save, and on
 * migration — and recording WHEN each fingerprint was taken. At a flip:
 *
 *   - stores identical                  -> nothing to do, and emphatically not a conflict
 *   - target empty                      -> copy across (unambiguous; it can lose nothing)
 *   - target unchanged AND older        -> our own stale backup, refresh it from the source
 *   - anything else                     -> genuine divergence; change NOTHING and tell the admin
 *
 * The timestamp half of that is not decoration. A fingerprint match alone cannot mean "stale",
 * because saving a store fingerprints it too: after native(A) -> admin saves ACF as B -> flip to
 * ACF, the ACF hash matches B exactly BECAUSE B was saved, and a fingerprint-only test reads that
 * as a stale backup and overwrites the admin's B with the older A. Recency is what actually
 * separates the two: the store written last is the live one, the other is the leftover. Installs
 * predating the timestamps have none recorded, which reads as "cannot prove it is stale" and routes
 * them to the conflict notice — the safe direction.
 *
 * "Configured" likewise means the store EXISTS, not that its webhook is non-empty. An admin who
 * clears the webhook to take a site off the air has made a configuration change like any other, and
 * it has to migrate; treating it as "unconfigured" was how a flip could resurrect the very webhook
 * that had just been removed.
 *
 * Fingerprints are compared against a hash recomputed live at flip time, so an edit made outside
 * the admin UI (WP-CLI, a migration script, direct SQL) is still detected as divergence rather than
 * being silently overwritten. An outstanding conflict suppresses migration entirely until an admin
 * saves: this code having once concluded it cannot choose safely is not undone by flipping again.
 * There is deliberately no one-shot latch: a site can gain and lose ACF any number of times and
 * each flip is evaluated on its merits.
 * ------------------------------------------------------------------------------------------------
 */

// Which store was authoritative on the last request we saw, plus a fingerprint per store taken
// when that store was last written or last saved. Autoloaded, and the no-flip fast path reads
// nothing else, so the steady-state cost is one already-cached option lookup.
if ( ! defined( 'N8NCHAT_STORE_STATE' ) ) { define( 'N8NCHAT_STORE_STATE', 'n8nchat_store_state' ); }

// Set only when a flip found both stores configured and divergent. Drives the admin notice.
if ( ! defined( 'N8NCHAT_STORE_CONFLICT' ) ) { define( 'N8NCHAT_STORE_CONFLICT', 'n8nchat_store_conflict' ); }

/**
 * The wp_options row ACF uses for one of our fields on an options page. ACF stores option-page
 * values as `options_{field_name}`, and our field names are `n8nchat_{setting}` (see the group
 * above) — so this can read the ACF store even when ACF itself is no longer installed, which is
 * precisely the case the ACF→native migration has to handle.
 */
function n8nchat_acf_option_key( $name ) {
	return 'options_n8nchat_' . $name;
}

/**
 * Read one store into a plain array, containing only the keys that are actually recorded there.
 *
 * The ACF branch reads the raw `options_n8nchat_*` rows rather than going through get_field(), for
 * three reasons: it is the only option once ACF has been deactivated, it returns what is stored
 * rather than what ACF resolves (default_value would otherwise make an untouched store look
 * configured), and it makes the fingerprint mean the same thing whether or not ACF is loaded.
 */
function n8nchat_read_store( $store ) {
	$out = [];

	if ( 'acf' === $store ) {
		foreach ( n8nchat_defaults() as $name => $default ) {
			$raw = get_option( n8nchat_acf_option_key( $name ), null );
			if ( null === $raw ) { continue; }
			$out[ $name ] = $raw;
		}
		return $out;
	}

	$stored = get_option( N8NCHAT_OPTION, [] );
	if ( ! is_array( $stored ) ) { return $out; }
	foreach ( n8nchat_defaults() as $name => $default ) {
		if ( ! array_key_exists( $name, $stored ) ) { continue; }
		$out[ $name ] = $stored[ $name ];
	}
	return $out;
}

/**
 * Fingerprint of a store's contents. A change detector, not a security primitive — it only ever
 * answers "is this byte-for-byte what we last wrote here?". Key order is fixed by n8nchat_defaults()
 * so the same configuration always hashes identically.
 */
function n8nchat_store_hash( $cfg ) {
	$normal = [];
	foreach ( n8nchat_defaults() as $name => $default ) {
		if ( ! array_key_exists( $name, $cfg ) ) {
			$normal[ $name ] = null;
			continue;
		}
		$value = $cfg[ $name ];
		// Scalars normalise to a string so that "1" and 1 — which is the difference between a value
		// that has been through a form and one read straight from the option row — do not read as a
		// change. Anything else is JSON-encoded instead: `list` settings hold arrays, and casting an
		// array to string yields the literal "Array" plus a PHP notice, so every starter-prompt list
		// on earth would have fingerprinted identically and an edit to one would have looked like no
		// edit at all. That is precisely the "stale backup, safe to overwrite" verdict, so the bug
		// would have silently discarded a configuration rather than merely mis-detecting one.
		$normal[ $name ] = is_scalar( $value ) ? (string) $value : (string) wp_json_encode( $value );
	}
	return md5( (string) wp_json_encode( $normal ) );
}

/**
 * Write a configuration into a store.
 *
 * Native goes through the shared sanitiser because ACF-sourced values have never been sanitised by
 * anything. ACF is written with update_field() rather than update_option() so ACF's companion
 * `_options_*` field-key reference rows are maintained too — without them the options page renders
 * empty even though the values are present.
 */
function n8nchat_write_store( $store, $cfg ) {
	if ( 'acf' === $store ) {
		if ( ! function_exists( 'update_field' ) ) { return false; }
		foreach ( $cfg as $name => $value ) {
			$value = ( 'enabled' === $name ) ? (int) (bool) $value : $value;
			update_field( n8nchat_field_key( $name ), $value, 'option' );
		}
		return true;
	}

	$stored = get_option( N8NCHAT_OPTION, [] );
	if ( ! is_array( $stored ) ) { $stored = []; }
	return update_option( N8NCHAT_OPTION, n8nchat_sanitize_options( array_merge( n8nchat_defaults(), $stored, $cfg ) ) );
}

/**
 * Is this store configured at all?
 *
 * Store EXISTENCE, deliberately not "has a non-empty webhook". n8nchat_read_store() returns only
 * the keys actually recorded, so an empty array means nobody has ever saved here.
 *
 * Using a non-empty webhook_url as the sentinel — as this did until now — silently lost the one
 * case that matters most. An admin who CLEARS the webhook to take a site's widget off the air left
 * a store that read as "unconfigured": the next flip copied nothing, raised no conflict, and
 * stamped the stale opposite store active, putting live visitor conversations straight back onto
 * the webhook that had just been removed. An empty webhook is a configuration, and it migrates.
 */
function n8nchat_store_exists( $cfg ) {
	return is_array( $cfg ) && ! empty( $cfg );
}

/**
 * Record the currently authoritative store and (re)fingerprint it. Called after a migration and
 * from the save hooks below, so the stored hash always reflects the last legitimate write.
 *
 * It also records WHEN. A fingerprint says only "is this still what was here last time"; it cannot
 * say which of two populated stores is the current one and which is last year's leftover. The
 * timestamp can, and n8nchat_sync_stores() needs that to tell a stale backup from somebody's work.
 */
function n8nchat_stamp_store( $store, $state = null ) {
	if ( ! is_array( $state ) ) { $state = get_option( N8NCHAT_STORE_STATE, [] ); }
	if ( ! is_array( $state ) ) { $state = []; }
	if ( empty( $state['hashes'] ) || ! is_array( $state['hashes'] ) ) { $state['hashes'] = []; }
	if ( empty( $state['times'] ) || ! is_array( $state['times'] ) ) { $state['times'] = []; }

	$state['active'] = $store;
	$state['hashes'][ $store ] = n8nchat_store_hash( n8nchat_read_store( $store ) );
	$state['times'][ $store ]  = time();

	update_option( N8NCHAT_STORE_STATE, $state );
	return $state;
}

// The plugin version whose schema the recorded fingerprints were taken under. Compared on every
// request, so it is an autoloaded row and the steady-state cost is one already-cached read.
if ( ! defined( 'N8NCHAT_SCHEMA_STATE' ) ) { define( 'N8NCHAT_SCHEMA_STATE', 'n8nchat_schema_state' ); }

/**
 * Re-fingerprint both stores after a plugin upgrade that changed the schema.
 *
 * n8nchat_store_hash() folds in EVERY key of n8nchat_defaults(), recording null for the ones a
 * store has never held. So the moment the schema gains a field, every fingerprint recorded by the
 * previous version stops matching its own store — not because anything was edited, but because the
 * question being asked changed. n8nchat_sync_stores() reads that as "somebody edited this behind
 * our back", declines to migrate, and raises the conflict notice.
 *
 * v2.0 takes the schema from eleven fields to roughly fifty, so without this every configured site
 * in the estate would have shown an alarming and completely wrong "settings have diverged" warning
 * the first time it gained or lost an ACF options page.
 *
 * Only the HASHES are recomputed. `times` is deliberately left alone: it records which store was
 * genuinely written last, that is the half of the staleness test a fingerprint cannot supply, and
 * stamping both with the upgrade time would erase it — making two stores look simultaneous and
 * pushing a legitimately migratable flip into the conflict branch instead. `active` is untouched
 * for the same reason.
 *
 * Runs on `init` priority 1: late enough that the text domain (init 0) is loaded, so reading the
 * schema here cannot trigger WordPress 6.7's early-translation warning, and early enough to land
 * before n8nchat_sync_stores() (init 99) on the very same request that first loads the new code —
 * including an anonymous front-end request, which on most sites is what that will be.
 */
function n8nchat_migrate_schema() {
	$version = defined( 'N8NCHAT_VERSION' ) ? N8NCHAT_VERSION : '';
	if ( '' === $version ) { return; }

	if ( get_option( N8NCHAT_SCHEMA_STATE, '' ) === $version ) { return; }

	$state = get_option( N8NCHAT_STORE_STATE, null );

	// No recorded state means a fresh install, or one predating the fingerprints entirely. There is
	// nothing to correct, and inventing a fingerprint here would assert a store is "unchanged" that
	// this code has never actually seen.
	if ( is_array( $state ) && ! empty( $state['hashes'] ) && is_array( $state['hashes'] ) ) {
		foreach ( [ 'native', 'acf' ] as $store ) {
			if ( ! array_key_exists( $store, $state['hashes'] ) ) { continue; }
			$state['hashes'][ $store ] = n8nchat_store_hash( n8nchat_read_store( $store ) );
		}
		update_option( N8NCHAT_STORE_STATE, $state );
	}

	update_option( N8NCHAT_SCHEMA_STATE, $version );
}
add_action( 'init', 'n8nchat_migrate_schema', 1 );

/**
 * Decide what a change of active store means and act on it. See the block comment above.
 *
 * Hooked on `init` priority 99. That is late enough for both directions: ACF, when present, fires
 * `acf/init` from its own `init` callback at priority 5 (so our field group at `acf/init` 20 and
 * the theme's options page have both registered, making n8nchat_uses_acf() answerable and
 * update_field() usable), and when ACF is absent `acf/init` never fires at all so this is the only
 * hook that could carry the values back. It runs on front-end requests too, deliberately — a flip
 * whose first request is an anonymous page view must not leave the widget dark until an admin
 * happens to log in.
 */
function n8nchat_sync_stores() {
	$active   = n8nchat_uses_acf() ? 'acf' : 'native';
	$inactive = ( 'acf' === $active ) ? 'native' : 'acf';

	$state = get_option( N8NCHAT_STORE_STATE, null );
	$known = is_array( $state ) && ! empty( $state['active'] );

	// Fast path: nothing has flipped. Edits are fingerprinted by the save hooks below rather than
	// by polling here, so the steady state costs a single autoloaded option read.
	if ( $known && $state['active'] === $active ) { return; }

	$state       = is_array( $state ) ? $state : [];
	$source_cfg  = n8nchat_read_store( $inactive );
	$target_cfg  = n8nchat_read_store( $active );
	$has_source  = n8nchat_store_exists( $source_cfg );
	$target_blank = ! n8nchat_store_exists( $target_cfg );
	$flipped     = $known; // reaching here with a recorded state means the active store changed

	// Byte-identical stores are neither a migration nor a conflict: there is nothing to carry
	// across and nothing that could be lost. Settle it before any of the reasoning below, so a
	// site whose two stores agree never has a conflict notice raised at it.
	if ( $has_source && ! $target_blank
		&& n8nchat_store_hash( $source_cfg ) === n8nchat_store_hash( $target_cfg ) ) {
		n8nchat_stamp_store( $active, $state );
		delete_option( N8NCHAT_STORE_CONFLICT );
		return;
	}

	// An unresolved conflict is this code having already concluded it cannot tell these two stores
	// apart safely. A later flip supplies no new information, so it must not be allowed to quietly
	// make the call that the earlier one refused to. Only an explicit admin save retires it.
	$conflict_open = (bool) get_option( N8NCHAT_STORE_CONFLICT );

	// Is the target a stale backup we may overwrite? Two independent things both have to hold.
	//
	// 1. UNCHANGED — its contents still match the fingerprint we recorded, so nothing has been
	//    edited behind our back (WP-CLI, a migration script, direct SQL, another plugin).
	//
	// 2. NOT NEWER than the source. This is the half a fingerprint cannot supply, and its absence
	//    was the bug: a matching hash does NOT mean "stale", because saving a store fingerprints it
	//    too. With native=A and an admin who saved the ACF side as B, a flip to ACF found
	//    hashes['acf'] matching B exactly — precisely BECAUSE B had just been saved — read that as
	//    "our own stale backup", and destroyed B with the older A. Comparing recorded times settles
	//    it properly: whichever store was written last is the live one, and the other is the
	//    leftover. That still migrates the case this whole mechanism exists for — native(A) ->
	//    ACF(A) -> admin edits ACF to B -> ACF removed — because there the source is genuinely the
	//    more recent write.
	//
	// A missing hash or missing timestamp (every install predating this) means "cannot prove it is
	// stale", which leaves a populated target alone and routes the flip to the conflict notice.
	$target_untouched = $flipped
		&& ! $conflict_open
		&& isset( $state['hashes'][ $active ], $state['times'][ $active ], $state['times'][ $inactive ] )
		&& $state['hashes'][ $active ] === n8nchat_store_hash( $target_cfg )
		&& (int) $state['times'][ $active ] <= (int) $state['times'][ $inactive ];

	// A blank target can lose nothing, so it is always safe to fill — even mid-conflict.
	if ( $has_source && ( $target_blank || $target_untouched ) ) {
		n8nchat_write_store( $active, $source_cfg );
		n8nchat_stamp_store( $active, $state );
		delete_option( N8NCHAT_STORE_CONFLICT );
		return;
	}

	if ( $flipped && $has_source && ! $target_blank ) {
		// Both stores hold real, different configuration. Guessing here is how a site ends up
		// pointing live conversations at last quarter's webhook, so we change nothing and say so.
		update_option( N8NCHAT_STORE_CONFLICT, [
			'from'    => $inactive,
			'to'      => $active,
			'source'  => isset( $source_cfg['webhook_url'] ) ? (string) $source_cfg['webhook_url'] : '',
			'target'  => isset( $target_cfg['webhook_url'] ) ? (string) $target_cfg['webhook_url'] : '',
			'time'    => time(),
		] );
	}

	n8nchat_stamp_store( $active, $state );
}
add_action( 'init', 'n8nchat_sync_stores', 99 );

/**
 * Re-fingerprint on every legitimate save, so the next flip can tell an edited store from a stale
 * one. Both hooks fire after the value has been written.
 */
function n8nchat_stamp_on_save( $store ) {
	n8nchat_stamp_store( $store );
	// An explicit save is the admin resolving the ambiguity, so retire any outstanding conflict.
	delete_option( N8NCHAT_STORE_CONFLICT );
}
add_action( 'update_option_' . N8NCHAT_OPTION, function () { n8nchat_stamp_on_save( 'native' ); }, 10, 0 );
add_action( 'add_option_' . N8NCHAT_OPTION, function () { n8nchat_stamp_on_save( 'native' ); }, 10, 0 );
add_action( 'acf/save_post', function ( $post_id ) {
	if ( 'options' !== $post_id ) { return; }
	if ( ! n8nchat_uses_acf() ) { return; }
	n8nchat_stamp_on_save( 'acf' );
}, 20 );

/**
 * Tell the admin when a flip found both stores configured and divergent, since the alternative is
 * silently serving one of them. Names both webhooks so the choice is obvious, and clears itself
 * once either path is saved.
 */
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) ) { return; }

	$conflict = get_option( N8NCHAT_STORE_CONFLICT );
	if ( ! is_array( $conflict ) || empty( $conflict['to'] ) ) { return; }

	$labels = [ 'acf' => 'the ACF options tab', 'native' => 'the plugin\'s own Chatbot screen' ];
	$to     = isset( $labels[ $conflict['to'] ] ) ? $labels[ $conflict['to'] ] : $conflict['to'];
	$from   = isset( $labels[ $conflict['from'] ] ) ? $labels[ $conflict['from'] ] : $conflict['from'];

	// An empty webhook is a real, deliberate setting here ("this site is off the air"), not a
	// missing value, so it needs saying out loud rather than rendering as an empty <code></code>.
	$shown = function ( $url ) {
		$url = isset( $url ) ? (string) $url : '';
		return '' === $url ? '<em>no webhook set</em>' : '<code>' . esc_html( $url ) . '</code>';
	};

	echo '<div class="notice notice-warning"><p><strong>n8n Chatbot Widget:</strong> the settings source changed from '
		. esc_html( $from ) . ' to ' . esc_html( $to )
		. ', and both hold different configuration. Nothing has been overwritten, so the widget is currently using '
		. esc_html( $to ) . '.</p><p>Now in use: ' . $shown( isset( $conflict['target'] ) ? $conflict['target'] : '' )
		. '<br>Previously in use: ' . $shown( isset( $conflict['source'] ) ? $conflict['source'] : '' )
		. '</p><p>Open the Chatbot settings and save them to confirm the right values and dismiss this notice.</p></div>';
} );
