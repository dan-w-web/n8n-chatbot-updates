<?php
/**
 * Self-updates, with no credential on the site.
 *
 * The plugin checks a PUBLIC repository — dan-w-web/n8n-chatbot-updates — which holds no source,
 * only the zip built by CI for each release. Plugin Update Checker runs inside WordPress, talks to
 * the GitHub REST API over HTTPS, and installs the release asset through the normal WordPress update
 * flow. No SSH, no git, and nothing to configure.
 *
 * WHY IT IS NOT THE SOURCE REPOSITORY
 *
 * The source repository is private, and a private repository means the update check must
 * authenticate — which meant a GitHub personal access token on EVERY client site, in wp-config.php
 * or in the database. That was three separate problems, and none of them was theoretical:
 *
 *   - a live credential with repository read access sat in the config of every site running this
 *     plugin, surviving every backup, export and migration those sites ever made;
 *   - fine-grained tokens expire, at most a year out, so every site had a date on which its updates
 *     would stop;
 *   - and when one did expire the failure was silent. The check simply returned nothing, so the
 *     Plugins screen showed the site as perfectly up to date. Half of this file used to be
 *     machinery for noticing that and telling somebody.
 *
 * Publishing the build artifact to a public repository removes all three at once. Nothing in the
 * update channel is secret, so nothing needs authenticating. The one credential that remains is a
 * CI secret in the source repository, which never touches a client server and whose failure is a
 * red build rather than a silent non-update.
 *
 * MIGRATING FROM 2.0.x
 *
 * Sites upgrading from a token-authenticated version get the token deleted from their database on
 * the next admin request (see n8nchat_forget_update_token). A `W_WEB_CHATBOT_UPDATE_KEY` constant
 * left in wp-config.php is simply never read again; it is inert and can be removed at leisure.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * The update channel.
 *
 * NOT the source repository. This one is public and contains nothing but release artifacts, which
 * is the entire reason no token is needed. Overridable so a fork or a staging channel can point
 * somewhere else without patching the file.
 */
if ( ! defined( 'N8NCHAT_GITHUB_REPO' ) ) {
	define( 'N8NCHAT_GITHUB_REPO', 'https://github.com/dan-w-web/n8n-chatbot-updates' );
}

// Where the last GitHub API failure is parked so the admin notice can surface it. Site-transient
// (not a plain transient) to match PUC, whose state store writes via update_site_option — on
// multisite the check and its errors belong to the network, not to whichever blog happened to
// trigger it. On single-site a site transient is just an option row, so this costs nothing.
if ( ! defined( 'N8NCHAT_UPDATE_ERROR_TRANSIENT' ) ) {
	define( 'N8NCHAT_UPDATE_ERROR_TRANSIENT', 'n8nchat_update_error' );
}

/**
 * Delete the update token this plugin no longer uses.
 *
 * It is a live GitHub credential. Leaving it in the database of a site that has stopped reading it
 * is strictly worse than leaving a stale setting: nothing will ever surface it again, it survives
 * every backup and migration the site makes from here on, and no one will think to revoke it
 * because nothing refers to it any more. Removing it is the point of this function, not tidiness.
 *
 * Runs on an admin request rather than on activation, because an update installed through
 * Dashboard → Updates does not fire the activation hook — the plugin is already active. Cheap
 * enough to run every time: two get_option() calls against an autoloaded miss once the row is gone.
 *
 * The multisite copy lives in sitemeta (the token used to be network-wide, because PUC's own state
 * is), so both stores are cleared.
 */
function n8nchat_forget_update_token() {
	if ( null !== get_option( 'n8nchat_update_token', null ) ) {
		delete_option( 'n8nchat_update_token' );
	}
	if ( is_multisite() && false !== get_site_option( 'n8nchat_update_token', false ) ) {
		delete_site_option( 'n8nchat_update_token' );
	}
	// The "no token is set" warning is gone, so the per-user record of having dismissed it is dead
	// weight on every user row it was ever written to.
	delete_metadata( 'user', 0, 'n8nchat_dismiss_token_notice', '', true );
}
add_action( 'admin_init', 'n8nchat_forget_update_token' );

/**
 * Register the update checker.
 *
 * Gated to admin / cron / WP-CLI: an anonymous front-end hit has no use for the checker, and
 * building the whole PUC object graph (autoloader, factory, scheduler, state store, extra UI) on
 * every page view is pure overhead. The three contexts that DO need it:
 *
 *   - is_admin()      — the Plugins/Updates screens, and `register_deactivation_hook()`, which PUC
 *                       wires up inside its constructor (Puc/v5p6/Plugin/UpdateChecker.php:87-90,
 *                       createScheduler()) purely to clear its own cron event. Deactivation is
 *                       always an admin request (plugins.php / WP-CLI), so gating on is_admin()
 *                       does not orphan that cron event. Same for the `uninstall_<file>` hook it
 *                       registers at Plugin/UpdateChecker.php:76.
 *   - wp_doing_cron() — the scheduled background check.
 *   - WP_CLI          — `wp plugin update`, `wp plugin deactivate`, and PUC's own CLI trigger.
 *
 * Everything is wrapped defensively: a missing loader, a malformed repo URL (GitHubApi.php:43
 * throws InvalidArgumentException) or a broken build must degrade to "no updates", never to a
 * white screen on every client site.
 */
function n8nchat_register_updater() {
	$loader = N8NCHAT_DIR . 'lib/plugin-update-checker/load-v5p6.php';
	if ( ! file_exists( $loader ) ) { return; }
	require_once $loader;

	if ( ! class_exists( '\YahnisElsts\PluginUpdateChecker\v5\PucFactory' ) ) { return; }

	try {
		$checker = \YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
			N8NCHAT_GITHUB_REPO,
			N8NCHAT_FILE,
			'n8n-chatbot' // plugin slug — keep stable; it's the target install folder name.
		);
	} catch ( \Exception $e ) {
		return;
	}

	if ( ! is_object( $checker ) ) { return; }

	// No setAuthentication() call, and there must not be one: the channel is public, and a checker
	// that authenticates against it would reintroduce the per-site credential this release removed.

	// Update from published GitHub *releases* and download the attached n8n-chatbot.zip asset
	// (built by .github/workflows/release.yml) rather than GitHub's auto source zip — that zip
	// has the correct top-level folder, excludes dev files, and is the same artifact used for
	// manual first-install on sites without SSH. It is also the only thing in the update channel:
	// there is no source there to fall back to.
	//
	// getVcsApi() only exists on the VCS-backed checkers (Vcs/VcsCheckerMethods.php:37), so the
	// guard has to be on $checker, not on the value it returns.
	if ( ! method_exists( $checker, 'getVcsApi' ) ) { return; }

	$api = $checker->getVcsApi();
	if ( ! is_object( $api ) || ! method_exists( $api, 'enableReleaseAssets' ) ) { return; }

	// The regex is matched against the asset's file NAME (ReleaseAssetSupport::matchesAssetFilter),
	// so anchor it at both ends — an unanchored /n8n-chatbot\.zip$/ would happily accept an asset
	// called "evil-n8n-chatbot.zip".
	//
	// Second argument is Api::REQUIRE_RELEASE_ASSETS (= 2, Puc/v5p6/Vcs/Api.php:39). The default is
	// PREFER_RELEASE_ASSETS, which falls back to GitHub's auto-generated source zipball when no
	// asset matches — and since the release is published a few seconds before CI finishes attaching
	// the zip, PREFER means a site checking in that window caches the wrong download URL for up to
	// 12 hours. On the update channel that zipball would be a repository containing only a README,
	// which WordPress would happily install over the working plugin. REQUIRE makes GitHubApi.php:137
	// return null instead: no update offered until the real asset exists. Resolved off the live
	// class so it stays correct if another plugin's copy of PUC wins the factory.
	$preference_const = get_class( $api ) . '::REQUIRE_RELEASE_ASSETS';
	$preference       = defined( $preference_const ) ? constant( $preference_const ) : 2;

	$api->enableReleaseAssets( '/^n8n-chatbot\.zip$/i', $preference );
}
if ( is_admin() || wp_doing_cron() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
	add_action( 'plugins_loaded', 'n8nchat_register_updater' );
}

/**
 * Catch API failures so a broken update check doesn't fail silently forever.
 *
 * Expired tokens are no longer a failure mode, but the check can still break: GitHub rate-limits
 * unauthenticated requests to 60 an hour per IP, and several client sites on one shared server go
 * out through one address. Outages, DNS and blocked outbound HTTPS do the rest. Every one of those
 * looks identical from the dashboard — the site simply appears up to date — which is why the error
 * is captured rather than left to the void.
 *
 * PUC fires this from several places with varying arity (Metadata.php:46 passes one argument,
 * GitHubApi.php:276 passes four), hence the defaults on $response/$url/$slug: WordPress calls the
 * listener with however many arguments do_action() was given, and a missing required parameter
 * would be a fatal.
 *
 * @param \WP_Error|mixed $error
 * @param array|null      $response
 * @param string|null     $url
 * @param string|null     $slug
 */
function n8nchat_record_update_error( $error, $response = null, $url = null, $slug = null ) {
	if ( null !== $slug && 'n8n-chatbot' !== $slug ) { return; }
	if ( ! is_wp_error( $error ) ) { return; }

	set_site_transient( N8NCHAT_UPDATE_ERROR_TRANSIENT, $error->get_error_message(), DAY_IN_SECONDS );
}
add_action( 'puc_api_error', 'n8nchat_record_update_error', 10, 4 );

/**
 * …and clear it again the moment a check succeeds. PUC has no "check succeeded" action, but
 * `puc_request_update_result-n8n-chatbot` (UpdateChecker.php:441, via filterUpdateResult) is only
 * reached when requestUpdate() got a usable answer back — a failed request returns null before it
 * (Plugin/UpdateChecker.php:164), so a non-null $update is a reliable success signal. Worst case
 * the transient's day-long expiry cleans up on its own.
 */
add_filter( 'puc_request_update_result-n8n-chatbot', function ( $update, $http_result = null ) {
	if ( null !== $update ) {
		delete_site_transient( N8NCHAT_UPDATE_ERROR_TRANSIENT );
	}
	return $update;
}, 10, 2 );

/**
 * Say so when the update check is failing.
 *
 * One case now, not two. There is no longer a "you have not configured a credential" state to warn
 * about, and with it goes the dismissible-forever notice, its AJAX handler, its nonce and its
 * per-user meta — roughly two hundred lines whose entire purpose was managing a secret that no
 * longer exists.
 *
 * Not dismissible: an update check that has been failing for a fortnight is new information every
 * time somebody looks, and there is nothing here for an administrator to "acknowledge" — either the
 * checks resume, and this disappears on its own, or the site has genuinely stopped receiving
 * security fixes.
 */
function n8nchat_update_error_notice() {
	if ( ! current_user_can( 'update_plugins' ) ) { return; }

	$error = get_site_transient( N8NCHAT_UPDATE_ERROR_TRANSIENT );
	if ( ! $error ) { return; }

	echo '<div class="notice notice-warning"><p><strong>'
		. esc_html__( 'n8n Chatbot Widget', 'n8n-chatbot' ) . ':</strong> '
		. esc_html__( 'the last check for updates failed, so this plugin may not be receiving them. It usually recovers on its own; if it does not, check that the site can reach github.com.', 'n8n-chatbot' )
		. '</p><p><code>' . esc_html( (string) $error ) . '</code></p></div>';
}
add_action( 'admin_notices', 'n8nchat_update_error_notice' );
add_action( 'network_admin_notices', 'n8nchat_update_error_notice' );
