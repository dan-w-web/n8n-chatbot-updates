<?php
/**
 * The settings schema: one declaration per setting, and the single source of truth for all of them.
 *
 * Before this file existed the same eleven fields were spelled out by hand in six places — the ACF
 * field group (inc/settings.php), the native form (inc/native-settings.php), the sanitiser, the
 * store fingerprint, the reader's fallback rules, and a literal array in uninstall.php. Adding a
 * setting meant editing all six and the failure mode for missing one was silent: a field that
 * saves but never reads, or a row left behind on uninstall. v2.0 has roughly fifty settings, so
 * that arrangement had to go before anything else could be built on top of it.
 *
 * Everything downstream is now GENERATED from n8nchat_schema():
 *
 *   n8nchat_defaults()          key => default          (n8n-chatbot.php)
 *   n8nchat_blankable()         keys allowed to be ''   (n8n-chatbot.php)
 *   n8nchat_sanitize_options()  per-type sanitisation   (inc/native-settings.php)
 *   the ACF field group                                 (inc/settings.php)
 *   the native form + the new admin screen              (inc/admin/page.php)
 *   the store fingerprint + migration                   (inc/settings.php)
 *   uninstall.php's row sweep
 *
 * Add a setting HERE and nowhere else.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Settings groups, in the order the admin screen shows them as tabs.
 */
function n8nchat_groups() {
	return [
		'connection' => [
			'label' => __( 'Connection', 'n8n-chatbot' ),
			'help'  => __( 'Where this site sends its conversations. Required before anything renders.', 'n8n-chatbot' ),
		],
		'appearance' => [
			'label' => __( 'Appearance', 'n8n-chatbot' ),
			'help'  => __( 'How the widget looks. Colours are checked for contrast automatically.', 'n8n-chatbot' ),
		],
		'messages'   => [
			'label' => __( 'Messages', 'n8n-chatbot' ),
			'help'  => __( 'Every piece of text a visitor sees.', 'n8n-chatbot' ),
		],
		'behaviour'  => [
			'label' => __( 'Behaviour', 'n8n-chatbot' ),
			'help'  => __( 'When the widget appears, what it remembers, and how it attracts attention.', 'n8n-chatbot' ),
		],
		'handoff'    => [
			'label' => __( 'Handoff', 'n8n-chatbot' ),
			'help'  => __( 'What happens when a visitor wants a person rather than the bot.', 'n8n-chatbot' ),
		],
		'advanced'   => [
			'label' => __( 'Advanced', 'n8n-chatbot' ),
			'help'  => __( 'Escape hatches. Most sites never touch this tab.', 'n8n-chatbot' ),
		],
	];
}

/**
 * What each style preset actually SETS, beyond the `preset` value itself.
 *
 * The preset cards on the settings screen are a shortcut for "make it look roughly like this", and
 * a shortcut has to know which knobs it turns. That map lives here rather than in the admin screen
 * for the same reason every other generated thing does: the screen must never contain a settings
 * name, or it becomes a fifth place to remember when the schema changes.
 *
 * Keyed by a value of the `preset` field's own options, and every inner key must be a setting that
 * exists. inc/admin/page.php drops anything that is not — a filter adding a preset for a field a
 * later version removed would otherwise write a key the sanitiser then silently discards, which
 * looks to whoever clicked the card like a preset that half worked.
 *
 * The card deliberately does NOT overwrite a value the site owner has already customised; the
 * `preset` field's own help text promises exactly that, and a "style" shortcut that silently
 * discards a hand-picked window size would be the single most annoying thing on the screen.
 */
function n8nchat_presets() {
	$presets = [
		// Tight, square-ish and small: the preset that gets out of the way on a content site.
		'minimal'  => [
			'corner_radius' => 10,
			'density'       => 'compact',
			'launcher_size' => 52,
			'window_width'  => 400,
			'window_height' => 620,
		],
		// Softer and larger, aimed at a site where the chat IS the call to action.
		'friendly' => [
			'corner_radius' => 24,
			'density'       => 'comfortable',
			'launcher_size' => 62,
			'window_width'  => 400,
			'window_height' => 640,
		],
		// Roomier still. The frosted treatment itself is the widget's business; what the preset
		// contributes here is the geometry that treatment needs to read as a panel rather than a box.
		'glass'    => [
			'corner_radius' => 20,
			'density'       => 'comfortable',
			'launcher_size' => 56,
			'window_width'  => 420,
			'window_height' => 660,
		],
	];

	/**
	 * Filter what a style preset sets.
	 *
	 * @param array $presets preset value => [ setting name => value ].
	 */
	return (array) apply_filters( 'n8nchat_presets', $presets );
}

/**
 * Every setting.
 *
 * Descriptor keys:
 *   group      one of n8nchat_groups()
 *   type       bool | url | email | text | textarea | color | select | number | list | image | css
 *   default    the value used when the field has never been given one
 *   label      admin-facing field label
 *   help       admin-facing description; a small amount of HTML is allowed (wp_kses_post)
 *   blankable  true when a saved empty string is a deliberate choice rather than "never set".
 *              The readers substitute the default for '' on every OTHER field, so anything a
 *              site owner can meaningfully switch off by clearing it must be listed here.
 *   options    select only: value => label
 *   min/max    number only: inclusive clamp
 *   unit       number only: suffix shown in the admin
 *   items      list only: how each entry is sanitised ('text' or 'url')
 *   max_items  list only: hard cap, applied on save
 *   legacy     true for the eleven settings that existed in v1.x and must migrate unchanged
 *   cap        the capability required to CHANGE this setting, when that is more than the admin
 *              screen itself demands. See n8nchat_field_cap() for the rule and why it exists.
 *
 * The eleven `legacy` fields keep their exact v1 names, defaults and semantics so a site upgrading
 * from 1.3.5 carries its configuration across untouched. Do not rename them.
 */
function n8nchat_schema() {
	static $schema = null;
	if ( null !== $schema ) { return $schema; }

	$schema = [

		// ---------------------------------------------------------------- Connection

		'enabled' => [
			'group'   => 'connection',
			'type'    => 'bool',
			'default' => 1,
			'legacy'  => true,
			'label'   => __( 'Enable chatbot', 'n8n-chatbot' ),
			'help'    => __( 'Show the chat widget on the front end of this site.', 'n8n-chatbot' ),
		],
		'webhook_url' => [
			'group'   => 'connection',
			'cap'     => 'manage_options', // where every visitor conversation is sent
			'type'    => 'url',
			'default' => '',
			'legacy'  => true,
			'label'   => __( 'Webhook URL', 'n8n-chatbot' ),
			'help'    => __( 'The n8n Chat Trigger <strong>production</strong> webhook URL (ends in <code>/chat</code>). Required — the widget will not appear until this is set.', 'n8n-chatbot' ),
		],
		'bot_id' => [
			'group'   => 'connection',
			'cap'     => 'manage_options', // which tenant on the shared platform this site routes to
			'type'    => 'text',
			'default' => '',
			'legacy'  => true,
			'label'   => __( 'Bot ID', 'n8n-chatbot' ),
			'help'    => __( 'Supplied by W Web Design when using the shared platform webhook. Identifies this site&#8217;s bot. Leave blank for a standalone (single-bot) webhook.', 'n8n-chatbot' ),
		],

		// ---------------------------------------------------------------- Appearance

		'preset' => [
			'group'   => 'appearance',
			'type'    => 'select',
			'default' => 'minimal',
			'label'   => __( 'Style preset', 'n8n-chatbot' ),
			'help'    => __( 'The starting point for every other appearance setting. Changing it does not overwrite values you have already customised.', 'n8n-chatbot' ),
			'options' => [
				'minimal'  => __( 'Modern minimal — flat replies, tight type, one accent', 'n8n-chatbot' ),
				'friendly' => __( 'Friendly — rounded bubbles both sides, avatars, warm header', 'n8n-chatbot' ),
				'glass'    => __( 'Premium glass — frosted panel, hairline borders', 'n8n-chatbot' ),
			],
		],
		'primary_color' => [
			'group'   => 'appearance',
			'type'    => 'color',
			'default' => '#2f6fed',
			'legacy'  => true,
			'label'   => __( 'Brand colour', 'n8n-chatbot' ),
			'help'    => __( 'Used for the launcher, the visitor&#8217;s own messages, links and focus rings. Readable shades for text and for ink on top of the colour are derived automatically, so a very light or very dark brand still meets WCAG AA.', 'n8n-chatbot' ),
		],
		'color_scheme' => [
			'group'   => 'appearance',
			'type'    => 'select',
			// Light, not auto. "Auto" sounds like the considerate default and is the wrong one here:
			// almost every WordPress site this runs on is light-only, so a visitor whose phone is in
			// dark mode gets a dark widget sitting on a light page — which reads as broken rather
			// than as thoughtful, and is a look the site owner never chose. Auto is the right answer
			// only for a theme that has a dark mode of its own, which is a decision per site.
			'default' => 'light',
			'label'   => __( 'Colour scheme', 'n8n-chatbot' ),
			'help'    => __( 'Most sites should stay on <strong>light</strong>. Choose <strong>auto</strong> only if the site itself has a dark mode &#8212; otherwise a visitor whose device is set to dark gets a dark widget on a light page.', 'n8n-chatbot' ),
			'options' => [
				'auto'  => __( 'Auto (follow the visitor)', 'n8n-chatbot' ),
				'light' => __( 'Always light', 'n8n-chatbot' ),
				'dark'  => __( 'Always dark', 'n8n-chatbot' ),
			],
		],
		'position' => [
			'group'   => 'appearance',
			'type'    => 'select',
			'default' => 'right',
			'label'   => __( 'Screen position', 'n8n-chatbot' ),
			'options' => [
				'right' => __( 'Bottom right', 'n8n-chatbot' ),
				'left'  => __( 'Bottom left', 'n8n-chatbot' ),
			],
		],
		'offset_x' => [
			'group'   => 'appearance',
			'type'    => 'number',
			'default' => 20,
			'min'     => 0,
			'max'     => 200,
			'unit'    => 'px',
			'label'   => __( 'Side offset', 'n8n-chatbot' ),
			'help'    => __( 'Distance from the left or right edge. Raise it to clear a cookie banner or a back-to-top button.', 'n8n-chatbot' ),
		],
		'offset_y' => [
			'group'   => 'appearance',
			'type'    => 'number',
			'default' => 20,
			'min'     => 0,
			'max'     => 200,
			'unit'    => 'px',
			'label'   => __( 'Bottom offset', 'n8n-chatbot' ),
		],
		'launcher_size' => [
			'group'   => 'appearance',
			'type'    => 'number',
			'default' => 56,
			'min'     => 44,
			'max'     => 88,
			'unit'    => 'px',
			'label'   => __( 'Launcher size', 'n8n-chatbot' ),
			'help'    => __( 'Below 44px the launcher becomes awkward to hit on a phone.', 'n8n-chatbot' ),
		],
		'launcher_icon' => [
			'group'   => 'appearance',
			'type'    => 'image',
			'default' => '',
			'label'   => __( 'Launcher icon', 'n8n-chatbot' ),
			'help'    => __( 'Optional. Replaces the default speech-bubble glyph. A square SVG or PNG of at least 96&#215;96 works best.', 'n8n-chatbot' ),
		],
		'launcher_label' => [
			'group'     => 'appearance',
			'type'      => 'text',
			'default'   => '',
			'blankable' => true,
			'label'     => __( 'Launcher label', 'n8n-chatbot' ),
			'help'      => __( 'Optional short word beside the icon — &#8220;Support&#8221;, &#8220;Order help&#8221;. Research consistently finds an unlabelled icon goes unnoticed by regular visitors, so this is worth setting.', 'n8n-chatbot' ),
		],
		'bot_avatar' => [
			'group'   => 'appearance',
			'type'    => 'image',
			'default' => '',
			'label'   => __( 'Assistant avatar', 'n8n-chatbot' ),
			'help'    => __( 'Shown in the header and beside replies. Falls back to the first letter of the header title.', 'n8n-chatbot' ),
		],
		'window_width' => [
			'group'   => 'appearance',
			'type'    => 'number',
			'default' => 400,
			'min'     => 320,
			'max'     => 560,
			'unit'    => 'px',
			'label'   => __( 'Window width', 'n8n-chatbot' ),
			'help'    => __( 'Desktop only — on phones the widget always takes the full screen.', 'n8n-chatbot' ),
		],
		'window_height' => [
			'group'   => 'appearance',
			'type'    => 'number',
			'default' => 620,
			'min'     => 400,
			'max'     => 900,
			'unit'    => 'px',
			'label'   => __( 'Window height', 'n8n-chatbot' ),
		],
		'corner_radius' => [
			'group'   => 'appearance',
			'type'    => 'number',
			'default' => 18,
			'min'     => 0,
			'max'     => 28,
			'unit'    => 'px',
			'label'   => __( 'Corner rounding', 'n8n-chatbot' ),
		],
		'density' => [
			'group'   => 'appearance',
			'type'    => 'select',
			'default' => 'comfortable',
			'label'   => __( 'Density', 'n8n-chatbot' ),
			'options' => [
				'comfortable' => __( 'Comfortable', 'n8n-chatbot' ),
				'compact'     => __( 'Compact', 'n8n-chatbot' ),
			],
		],
		'font_family' => [
			'group'     => 'appearance',
			'type'      => 'text',
			'default'   => '',
			'blankable' => true,
			'label'     => __( 'Font stack', 'n8n-chatbot' ),
			'help'      => __( 'Leave blank to use the visitor&#8217;s system font, which is the fastest and the safest. The plugin does not load web fonts — name one only if the theme already loads it.', 'n8n-chatbot' ),
		],

		// ---------------------------------------------------------------- Messages

		'title' => [
			'group'   => 'messages',
			'type'    => 'text',
			'default' => 'Chat with us',
			'legacy'  => true,
			'label'   => __( 'Header title', 'n8n-chatbot' ),
		],
		'subtitle' => [
			'group'     => 'messages',
			'type'      => 'text',
			'default'   => 'Ask a question and we’ll help.',
			'legacy'    => true,
			'blankable' => true,
			'label'     => __( 'Header subtitle', 'n8n-chatbot' ),
			'help'      => __( 'Shown under the title. Leave blank to hide it and use the status line alone.', 'n8n-chatbot' ),
		],
		'status_text' => [
			'group'     => 'messages',
			'type'      => 'text',
			'default'   => 'Typically replies instantly',
			'blankable' => true,
			'label'     => __( 'Status line', 'n8n-chatbot' ),
			'help'      => __( 'The small line beside the header avatar. Keep it honest — a promise the bot cannot keep costs more trust than it buys.', 'n8n-chatbot' ),
		],
		'offline_text' => [
			'group'     => 'messages',
			'type'      => 'text',
			'default'   => '',
			'blankable' => true,
			'label'     => __( 'Out-of-hours line', 'n8n-chatbot' ),
			'help'      => __( 'Optional. Replaces the status line when the assistant cannot be reached.', 'n8n-chatbot' ),
		],
		'greeting' => [
			'group'   => 'messages',
			'type'    => 'textarea',
			'default' => 'Hi! How can I help you today?',
			'legacy'  => true,
			'label'   => __( 'Opening message', 'n8n-chatbot' ),
			'help'    => __( 'The first message from the assistant. Markdown is supported. Avoid &#8220;How can I help?&#8221; on its own — a concrete offer (&#8220;Not sure which membership applies? I can check.&#8221;) performs measurably better.', 'n8n-chatbot' ),
		],
		'starter_prompts' => [
			'group'     => 'messages',
			'type'      => 'list',
			'items'     => 'text',
			'max_items' => 6,
			'default'   => [],
			'label'     => __( 'Starter prompts', 'n8n-chatbot' ),
			'help'      => __( 'One per line, up to six. Shown as tappable chips under the opening message. These do more than any other single setting to show a visitor what the bot is actually for.', 'n8n-chatbot' ),
		],
		'placeholder' => [
			'group'   => 'messages',
			'type'    => 'text',
			'default' => 'Type your question…',
			'legacy'  => true,
			'label'   => __( 'Input placeholder', 'n8n-chatbot' ),
		],
		'bot_label' => [
			'group'     => 'messages',
			'type'      => 'text',
			'default'   => 'Assistant',
			'legacy'    => true,
			'blankable' => true,
			'label'     => __( 'Assistant name', 'n8n-chatbot' ),
			'help'      => __( 'Shown beside replies. Leave blank to hide sender names entirely.', 'n8n-chatbot' ),
		],
		'user_label' => [
			'group'   => 'messages',
			'type'    => 'text',
			'default' => 'You',
			'legacy'  => true,
			'label'   => __( 'Visitor name', 'n8n-chatbot' ),
		],
		'error_text' => [
			'group'   => 'messages',
			'type'    => 'text',
			'default' => 'Sorry — something went wrong. Please try again.',
			'label'   => __( 'Error message', 'n8n-chatbot' ),
			'help'    => __( 'Shown when the assistant cannot be reached. The widget always offers a retry alongside it.', 'n8n-chatbot' ),
		],

		// ---------------------------------------------------------------- Behaviour

		'teaser_enabled' => [
			'group'   => 'behaviour',
			'type'    => 'bool',
			'default' => 0,
			'label'   => __( 'Show a teaser bubble', 'n8n-chatbot' ),
			'help'    => __( 'A small proactive card above the launcher. Off by default: an unwanted nudge costs more than a missed one.', 'n8n-chatbot' ),
		],
		'teaser_text' => [
			'group'     => 'behaviour',
			'type'      => 'text',
			'default'   => '',
			'blankable' => true,
			'label'     => __( 'Teaser text', 'n8n-chatbot' ),
			'help'      => __( 'One short sentence. Falls back to the opening message when blank.', 'n8n-chatbot' ),
		],
		'teaser_delay' => [
			'group'   => 'behaviour',
			'type'    => 'number',
			'default' => 45,
			'min'     => 0,
			'max'     => 600,
			'unit'    => 'seconds',
			'label'   => __( 'Teaser delay', 'n8n-chatbot' ),
			'help'    => __( 'How long a visitor must stay on a page first. Never fire on load — that is the single most resented pattern in this category.', 'n8n-chatbot' ),
		],
		'teaser_scroll' => [
			'group'   => 'behaviour',
			'type'    => 'number',
			'default' => 30,
			'min'     => 0,
			'max'     => 100,
			'unit'    => '% scrolled',
			'label'   => __( 'Teaser scroll depth', 'n8n-chatbot' ),
			'help'    => __( 'The teaser fires on whichever comes first, the delay or this depth. Set to 0 to use the delay alone.', 'n8n-chatbot' ),
		],
		'teaser_max' => [
			'group'   => 'behaviour',
			'type'    => 'number',
			'default' => 1,
			'min'     => 1,
			'max'     => 3,
			'unit'    => 'per visit',
			'label'   => __( 'Teaser cap', 'n8n-chatbot' ),
			'help'    => __( 'One nudge per session lifts engagement; four or more measurably raises bounce. Two is the sensible ceiling.', 'n8n-chatbot' ),
		],
		'sound_enabled' => [
			'group'   => 'behaviour',
			'type'    => 'bool',
			'default' => 0,
			'label'   => __( 'Play a sound on reply', 'n8n-chatbot' ),
			'help'    => __( 'Only ever plays while the chat window is closed, and never on the visitor&#8217;s first page view.', 'n8n-chatbot' ),
		],
		'page_rules_mode' => [
			'group'   => 'behaviour',
			'type'    => 'select',
			'default' => 'all',
			'label'   => __( 'Show the widget on', 'n8n-chatbot' ),
			'options' => [
				'all'     => __( 'Every page', 'n8n-chatbot' ),
				'include' => __( 'Only the paths listed below', 'n8n-chatbot' ),
				'exclude' => __( 'Every page except the paths listed below', 'n8n-chatbot' ),
			],
		],
		'page_rules' => [
			'group'     => 'behaviour',
			'type'      => 'list',
			'items'     => 'text',
			'max_items' => 50,
			'default'   => [],
			'label'     => __( 'Paths', 'n8n-chatbot' ),
			'help'      => __( 'One per line, relative to the site root, e.g. <code>/checkout</code>. A trailing <code>*</code> matches everything below it: <code>/shop/*</code>.', 'n8n-chatbot' ),
		],
		'history_ttl' => [
			'group'   => 'behaviour',
			'cap'     => 'manage_options', // how long a conversation is kept
			'type'    => 'number',
			'default' => 2,
			'min'     => 0,
			'max'     => 168,
			'unit'    => 'hours',
			'label'   => __( 'Remember a conversation for', 'n8n-chatbot' ),
			'help'    => __( 'After this long without activity the conversation is discarded and the next visitor on a shared device starts clean. 0 keeps nothing beyond the current page.', 'n8n-chatbot' ),
		],
		'consent_mode' => [
			'group'   => 'behaviour',
			'cap'     => 'manage_options', // whether anything is written to a browser before consent
			'type'    => 'select',
			'default' => 'off',
			'label'   => __( 'Consent mode', 'n8n-chatbot' ),
			'help'    => __( 'When on, the widget still works before consent — the conversation simply lives in memory for the current page and nothing is written to the visitor&#8217;s browser.', 'n8n-chatbot' ),
			'options' => [
				'off'    => __( 'Off — store the conversation as normal', 'n8n-chatbot' ),
				'send'   => __( 'Store only once the visitor sends a message', 'n8n-chatbot' ),
				'cookie' => __( 'Wait for a consent signal (named below)', 'n8n-chatbot' ),
			],
		],
		'consent_key' => [
			'group'     => 'behaviour',
			'cap'     => 'manage_options', // which signal counts as consent
			'type'      => 'text',
			'default'   => '',
			'blankable' => true,
			'label'     => __( 'Consent signal', 'n8n-chatbot' ),
			'help'      => __( 'Consent-mode &#8220;cookie&#8221; only. The name of a cookie, or a dotted path to a truthy value on <code>window</code>, that means functional consent has been given — e.g. <code>cmplz_functional</code> or <code>CookieYes.consent.functional</code>.', 'n8n-chatbot' ),
		],

		// ---------------------------------------------------------------- Handoff

		'handoff_enabled' => [
			'group'   => 'handoff',
			'cap'     => 'manage_options', // whether this site sends mail at all
			'type'    => 'bool',
			'default' => 0,
			'label'   => __( 'Offer a human', 'n8n-chatbot' ),
			'help'    => __( 'Adds a &#8220;talk to a person&#8221; action, and lets the assistant trigger the same card itself.', 'n8n-chatbot' ),
		],
		'handoff_label' => [
			'group'   => 'handoff',
			'type'    => 'text',
			'default' => 'Talk to a person',
			'label'   => __( 'Button text', 'n8n-chatbot' ),
		],
		'handoff_intro' => [
			'group'   => 'handoff',
			'type'    => 'text',
			'default' => 'Leave your details and we’ll come back to you.',
			'label'   => __( 'Form intro', 'n8n-chatbot' ),
		],
		'handoff_email' => [
			'group'     => 'handoff',
			'cap'     => 'manage_options', // where enquiries are emailed
			'type'      => 'email',
			'default'   => '',
			'blankable' => true,
			'label'     => __( 'Send enquiries to', 'n8n-chatbot' ),
			'help'      => __( 'Leave blank to use this site&#8217;s admin email address.', 'n8n-chatbot' ),
		],
		'handoff_webhook' => [
			'group'     => 'handoff',
			'cap'     => 'manage_options', // a second address every enquiry is POSTed to
			'type'      => 'url',
			'default'   => '',
			'blankable' => true,
			'label'     => __( 'Also POST to', 'n8n-chatbot' ),
			'help'      => __( 'Optional. A second copy of each enquiry is posted here as JSON — a CRM endpoint, or another n8n workflow.', 'n8n-chatbot' ),
		],
		'transcript_email' => [
			'group'   => 'handoff',
			'cap'     => 'manage_options', // whether a transcript is emailed to an address a stranger types
			'type'    => 'bool',
			'default' => 0,
			'label'   => __( 'Let visitors email themselves the conversation', 'n8n-chatbot' ),
			'help'    => __( 'Sends the transcript to an address the visitor types. Nothing is stored on this site either way.', 'n8n-chatbot' ),
		],

		// ---------------------------------------------------------------- Advanced

		/*
		 * Deliberately a modest number, and it was not always.
		 *
		 * 2.0 shipped this at 2147483000 — one thousand below INT_MAX, the value Intercom, Drift
		 * and HubSpot all use — on the reasoning that a support widget nobody can see is worse than
		 * one that covers something. In practice it is the other way round: at that height the
		 * widget wins against every overlay a customer's own site puts up, including the ones that
		 * exist precisely to be on top. The FSC site made the case on 2026-08-20, where the launcher
		 * and the open chat punched straight through the site's own slide-out navigation and hid
		 * most of the menu.
		 *
		 * 9000 is chosen against what the estate actually stacks at, measured rather than assumed:
		 *
		 *   sticky headers, skip links, floating bars   100 – 1,000   → the widget must clear these
		 *   Elementor popups, lightboxes                9,999         → deliberate, so they win
		 *   Complianz cookie banner (essexpolfed)       99,999        → must win, it is a legal notice
		 *   CookieYes banner and modal (gmppolfed, FSC) 999,999+      → same
		 *
		 * It also happens to be close to what 1.x used: that version hardcoded the widget at 9,999
		 * and both polfed sites ran there for months with no complaint, below their consent banners
		 * throughout. 9,000 rather than 9,999 only to avoid tying with that very common tier.
		 *
		 * A site whose own chrome sits unusually low still needs its own value — FSC's drawer is at
		 * 200, which no sensible default clears from below — which is what the setting is for.
		 */
		'z_index' => [
			'group'   => 'advanced',
			'type'    => 'number',
			'default' => 9000,
			'min'     => 1,
			'max'     => 2147483647,
			'label'   => __( 'Stacking order (z-index)', 'n8n-chatbot' ),
			'help'    => __( 'Where the widget sits in front of the page. The default clears sticky headers and floating bars while staying behind cookie banners and pop-ups, which should cover it. Lower it if the widget covers something it should sit behind — a slide-out menu, for instance — and raise it if something is covering the widget.', 'n8n-chatbot' ),
		],
		'custom_css' => [
			'group'     => 'advanced',
			'cap'     => 'manage_options', // CSS injected into the widget
			'type'      => 'css',
			'default'   => '',
			'blankable' => true,
			'label'     => __( 'Custom CSS', 'n8n-chatbot' ),
			'help'      => __( 'Injected inside the widget itself, so its selectors cannot leak into the rest of the page. Angle brackets are stripped.', 'n8n-chatbot' ),
		],
	];

	/**
	 * Filter the settings schema.
	 *
	 * Adding a field here is enough to have it stored, sanitised, rendered on both admin paths and
	 * cleaned up on uninstall. Removing a core field is not supported — inc/render.php reads several
	 * of them unconditionally.
	 *
	 * @param array $schema Field descriptors keyed by setting name.
	 */
	$schema = (array) apply_filters( 'n8nchat_schema', $schema );

	return $schema;
}

/**
 * Settings that existed in 1.x and no longer do.
 *
 * `version` pinned the @n8n/chat release loaded from jsDelivr; 2.0 ships its own widget and there is
 * no third-party package to pin. The key is dropped from the schema so nothing reads or writes it,
 * but uninstall.php still has to sweep the rows a 1.x install left behind, and the upgrade routine
 * has to tolerate finding it in a stored array.
 */
function n8nchat_retired_keys() {
	return [
		// The @n8n/chat release pinned from jsDelivr. 2.0 ships its own widget; there is no package
		// left to pin.
		'version',
		// Both were declared, stored, and read by nothing at all: a site owner could tick either and
		// the widget did precisely nothing. A control that does not work is worse than an absent one
		// — it generates a support call and quietly undermines every other setting on the screen. If
		// either is built later it can come back under the same name and the stored value with it.
		'file_uploads',
		'voice_input',
	];
}

/**
 * key => default, for every setting. The shape inc/render.php and both readers work in.
 */
function n8nchat_schema_defaults() {
	$out = [];
	foreach ( n8nchat_schema() as $name => $field ) {
		$out[ $name ] = $field['default'];
	}
	return $out;
}

/**
 * Settings whose value is allowed to be a deliberate empty string.
 *
 * For every other field "empty" means "never configured" and the reader substitutes the default.
 * Both readers — the ACF branch of n8nchat_settings() and n8nchat_native_get() — defer to this
 * list, which is why it has to be derived from the schema rather than maintained separately: the
 * two paths previously coerced independently and drifted, which silently made the documented
 * "leave blank to hide sender labels" behaviour unreachable on both.
 */
function n8nchat_schema_blankable() {
	$out = [];
	foreach ( n8nchat_schema() as $name => $field ) {
		if ( ! empty( $field['blankable'] ) ) { $out[] = $name; }
	}
	return $out;
}

/**
 * The capability required to CHANGE one setting, or '' when the screen's own gate is enough.
 *
 * This exists because of the ACF path, and only because of it. The plugin's own settings screen is
 * registered with `manage_options`, so on that path every field is already administrator-only. The
 * ACF path is different: the field group is attached to an options page the THEME registered, and
 * ACF's default capability for an options page is `edit_posts`. On a site whose theme took that
 * default — which is the common case, and is true of the Fire Sector Confederation site today — the
 * chatbot tab is reachable by any Editor.
 *
 * That was survivable when the tab held a webhook URL and some labels. It is not survivable now the
 * same tab decides where enquiry emails are sent and offers a second address to POST every lead to.
 * An Editor could redirect every visitor conversation to a server of their choosing, or quietly
 * copy every lead offsite, and neither change would look unusual in a settings screen they are
 * supposed to have access to.
 *
 * THE RULE: anything that decides where data goes, or how long it is kept, is administrator-only.
 * Everything else — what the widget says, what it looks like, where it sits — is editorial, and an
 * Editor trusted to write the site's copy is trusted to write the chatbot's.
 *
 * Enforced in two places on purpose. inc/settings.php omits these fields from the ACF group for a
 * user who lacks the capability, and n8nchat_acf_guard_value() refuses the write even when one is
 * submitted anyway. The second is what actually holds; the first only stops an Editor being shown
 * a control whose value would be thrown away.
 */
function n8nchat_field_cap( $name ) {
	$field = n8nchat_field( $name );
	return ( $field && ! empty( $field['cap'] ) ) ? $field['cap'] : '';
}

/**
 * Can the current user change this setting?
 *
 * Deliberately answers TRUE when there is no user at all. Front-end code resolves settings on every
 * anonymous request, and this is a question about a person editing a form — not about whether a
 * value may be read and rendered.
 */
function n8nchat_can_edit_field( $name ) {
	$cap = n8nchat_field_cap( $name );
	if ( '' === $cap ) { return true; }

	// No logged-in user means nobody is using a settings screen: this is WP-CLI, cron, or the front
	// end resolving values for an anonymous visitor. A capability test there is a category error,
	// and answering "no" would be worse than useless — see n8nchat_acf_fields(), where a field that
	// is not registered is a field get_field() returns null for.
	//
	// It is also the right threat model. This guard exists to stop a logged-in Editor changing where
	// data goes. Code already running as the site — CLI, a deploy script, cron — has the database
	// and the filesystem and has no need of a settings form.
	if ( function_exists( 'get_current_user_id' ) && ! get_current_user_id() ) { return true; }

	return function_exists( 'current_user_can' ) ? current_user_can( $cap ) : true;
}

/**
 * The names of every setting the current user may not change.
 */
function n8nchat_restricted_fields() {
	$out = [];
	foreach ( array_keys( n8nchat_schema() ) as $name ) {
		if ( ! n8nchat_can_edit_field( $name ) ) { $out[] = $name; }
	}
	return $out;
}

/**
 * The descriptor for one setting, or null when the name is unknown.
 */
function n8nchat_field( $name ) {
	$schema = n8nchat_schema();
	return isset( $schema[ $name ] ) ? $schema[ $name ] : null;
}

/**
 * Every setting in one group, in declaration order.
 */
function n8nchat_group_fields( $group ) {
	$out = [];
	foreach ( n8nchat_schema() as $name => $field ) {
		if ( $group === $field['group'] ) { $out[ $name ] = $field; }
	}
	return $out;
}

/**
 * Whether a value counts as "recorded" for this field.
 *
 * A list field stores an array, so the '' test both readers apply to scalars would never fire on
 * one; an empty array is the list equivalent of an empty string and has to fall back to the default
 * the same way. Centralised here so the two readers cannot drift again.
 */
function n8nchat_value_is_empty( $name, $value ) {
	$field = n8nchat_field( $name );

	if ( $field && 'list' === $field['type'] ) {
		// A list arrives in one of two shapes and both are legitimate. The native store holds the
		// sanitised array; the ACF store holds the raw textarea contents, because ACF has no field
		// type that round-trips a plain list of strings without ACF Pro's repeater. The readers run
		// BEFORE n8nchat_sanitize_options() normalises one into the other, so testing only for an
		// array here would have read every ACF-path list as "never configured" and quietly replaced
		// a site's starter prompts with the default empty list on every single request.
		if ( is_array( $value ) ) { return 0 === count( $value ); }
		if ( is_string( $value ) ) { return '' === trim( $value ); }
		return true;
	}

	return '' === $value;
}
