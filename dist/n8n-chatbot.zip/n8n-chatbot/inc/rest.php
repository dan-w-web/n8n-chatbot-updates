<?php
/**
 * The two endpoints the widget POSTs to: lead capture ("talk to a person") and "email me this
 * conversation".
 *
 * BOTH ARE OPEN TO THE WORLD, AND THAT IS NOT AN OVERSIGHT. A visitor who wants to leave their
 * details is by definition not logged in, so there is no capability to check and no session to
 * authenticate. `permission_callback` therefore returns true and every defence lives in the
 * callbacks below, where it can be reasoned about and tested.
 *
 * WHY THERE IS NO NONCE. The obvious answer — print a nonce into the page and verify it here — is
 * actively wrong on the sites this plugin runs on. A nonce is only valid for at most 24 hours, and
 * the page it is printed into is served by a full-page cache (WP Rocket, LiteSpeed, Cloudflare APO,
 * or a host's own varnish) for as long as that cache decides. Every visitor after the cache filled
 * receives the SAME nonce, and every one of them receives it expired once it ages out — so the form
 * works for whoever warmed the cache and silently fails for everybody else, with a 403 nobody can
 * reproduce because the developer's own logged-in view is never cached. That failure mode is well
 * known and it is exactly what this arrangement avoids. See the matching note in inc/render.php.
 *
 * What replaces it, in the order the callbacks apply it:
 *
 *   1. the feature has to be switched on in the settings at all;
 *   2. Origin (falling back to Referer) has to be a host this site actually answers on;
 *   3. a per-IP, per-hour rate limit, kept in a transient;
 *   4. a honeypot field that a human never sees and a form-filling bot always completes;
 *   5. a floor on how long the page has been open, since a bot posts within milliseconds;
 *   6. validation and sanitisation of every field, with hard length caps.
 *
 * None of those is worth much alone. Together they are the difference between an endpoint that
 * relays a handful of genuine enquiries and one that turns a client's site into somebody's outbound
 * mail server.
 *
 * NOTHING CONVERSATIONAL IS WRITTEN TO THE DATABASE HERE, and that is a product decision rather
 * than an omission. Conversations live in the customer's portal, fed by the workflow's own logging
 * node; the client's WordPress site is a relay that emails what it is handed and forgets it. There
 * is no custom table, no post type and no option holding a message. The only rows this file writes
 * are the rate-limiter's transients, which hold a count and an IP hash and expire on their own.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * The REST namespace, spelled once.
 *
 * inc/render.php hands the widget `rest_url( 'n8n-chatbot/v1' )` and the widget appends `/lead` or
 * `/transcript`. Keep the two in step: a rename here without a rename there produces a 404 that
 * looks exactly like a broken form.
 */
function n8nchat_rest_namespace() {
	return 'n8n-chatbot/v1';
}

/**
 * Every threshold in one place, so a site with an unusual shape can move them without patching.
 *
 * The per-hour figures are deliberately not as tight as they could be. REMOTE_ADDR is one address
 * for an entire office behind NAT, one for every pupil on a school's connection, and one for every
 * visitor at all on a site behind a reverse proxy that does not restore the client address — so a
 * limit tuned to "one person could not possibly need more than this" locks out a whole building the
 * moment two colleagues fill the form in the same hour. These numbers are high enough that a real
 * shared connection is not affected and low enough that an automated flood dies immediately.
 *
 * `min_elapsed_ms` is measured by the browser, not the server, so it is trivially forgeable by
 * anything that bothers to look. It is not meant to stop a determined attacker; it is meant to stop
 * the overwhelming majority of form spam, which is a script POSTing the field names it scraped with
 * no notion of how long a human takes to type a name.
 */
function n8nchat_rest_limits() {
	/**
	 * Filter the endpoint limits.
	 *
	 * @param array $limits Rate limits, timing floor and field length caps.
	 */
	return (array) apply_filters( 'n8nchat_rest_limits', [
		'lead_per_hour'       => 8,
		'transcript_per_hour' => 5,
		// Generous, because a rating is one click and a curious visitor may well rate every answer
		// in a long conversation. It exists to stop a script writing rows, not to ration feedback.
		'feedback_per_hour'   => 60,
		// A site-wide ceiling, counted across ALL addresses, applied to the transcript endpoint only.
		//
		// /transcript is the one route here where a stranger chooses both the recipient AND the text
		// — necessarily, since the visitor is emailing themselves a conversation this plugin
		// deliberately never stored. That is the shape of the old "email this page to a friend"
		// abuse: arbitrary content to arbitrary addresses, sent from, and reputationally charged to,
		// the client's own domain. A per-IP limit does not touch it, because addresses are the
		// cheapest thing an abuser has.
		//
		// Deliberately NOT applied to /lead. A global ceiling is itself a denial-of-service lever —
		// flood it and genuine visitors are turned away — and turning away a real sales enquiry is a
		// worse outcome than turning away a transcript, which is a convenience the visitor can live
		// without. The asymmetry is the point, not an oversight.
		//
		// Sized so no real site reaches it: a hundred transcripts an hour across an entire site is
		// far beyond any plausible legitimate use of a feature that ships switched off.
		'transcript_per_hour_site' => 100,
		'min_elapsed_ms'      => 3000,
		'name'                => 120,
		'email'               => 200,
		'message'             => 4000,
		'transcript_chars'    => 20000,
		'transcript_messages' => 120,
	] );
}

/**
 * The hosts a request may legitimately have come from.
 *
 * Both `home_url()` and `site_url()` are included because they differ on the very common layout
 * where WordPress itself lives in a subdirectory and the site is served from the root. The values
 * are hosts only — scheme and port are deliberately not compared, because a site reachable over
 * both http and https, or through a proxy that terminates TLS, would otherwise fail its own check.
 */
function n8nchat_rest_allowed_hosts() {
	$hosts = [];
	foreach ( [ home_url(), site_url() ] as $url ) {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		if ( '' !== $host ) { $hosts[] = $host; }
	}

	/**
	 * Filter the hosts the lead and transcript endpoints will accept a request from.
	 *
	 * The escape hatch for a site served under a domain alias, a staging hostname or a headless
	 * front end on its own domain — all of which send an Origin that is genuinely theirs and
	 * genuinely not `home_url()`.
	 *
	 * @param string[] $hosts Lower-case hostnames.
	 */
	$hosts = (array) apply_filters( 'n8nchat_allowed_origins', $hosts );

	return array_values( array_unique( array_filter( array_map( 'strtolower', array_map( 'strval', $hosts ) ) ) ) );
}

/**
 * Did this request come from a page on this site?
 *
 * Origin first, Referer only as a fallback. Every browser sends Origin on a POST — same-origin
 * included — while Referer is stripped by privacy extensions, by some corporate proxies and by a
 * `Referrer-Policy: no-referrer` header that plenty of security plugins set. Treating a missing
 * Referer as fatal would have broken the form for those visitors; treating a missing Origin AND a
 * missing Referer as fatal costs nothing a browser does, and is what turns away the plain `curl`
 * that sends neither.
 *
 * This is not authentication and does not pretend to be: a header is forgeable by anything that is
 * not a browser. What it buys is that a page on somebody else's domain cannot make a visitor's
 * browser post here, which is the attack that actually happens.
 */
function n8nchat_rest_origin_ok() {
	$origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? (string) wp_unslash( $_SERVER['HTTP_ORIGIN'] ) : '';
	if ( '' === $origin && isset( $_SERVER['HTTP_REFERER'] ) ) {
		$origin = (string) wp_unslash( $_SERVER['HTTP_REFERER'] );
	}
	if ( '' === $origin ) { return false; }

	// A sandboxed iframe posts the literal string "null" as its Origin, which parses to no host at
	// all and is refused here rather than matched against anything.
	$host = strtolower( (string) wp_parse_url( $origin, PHP_URL_HOST ) );
	if ( '' === $host ) { return false; }

	return in_array( $host, n8nchat_rest_allowed_hosts(), true );
}

/**
 * The address to count this request against.
 *
 * REMOTE_ADDR and nothing else by default. X-Forwarded-For is attacker-controlled on any site not
 * behind a proxy that overwrites it, so reading it "to be helpful" would hand every bot an
 * unlimited supply of fresh rate-limit buckets — that is, it would remove the rate limiter while
 * appearing to improve it. Sites that ARE behind a trusted proxy know which header to trust and can
 * say so through the filter; nobody else has to think about it.
 */
function n8nchat_rest_client_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '';

	/**
	 * Filter the client address used for rate limiting.
	 *
	 * @param string $ip The value of REMOTE_ADDR.
	 */
	return (string) apply_filters( 'n8nchat_client_ip', $ip );
}

/**
 * Count this request, and say whether it is over the limit.
 *
 * The window is a FIXED hour — its number is part of the transient key — rather than a rolling one,
 * and that is the whole subtlety here. `set_transient()` re-arms the expiry every time it is
 * called, so the obvious implementation (one key, TTL an hour, written on each hit) is a rolling
 * window that an office behind one NAT address can hold open indefinitely: every colleague who
 * tries pushes the unlock further away, and the honest answer to "when can I use this form again?"
 * becomes "when everybody stops trying". Keying by `floor( time() / HOUR )` means the count always
 * resets on the hour no matter how many attempts arrive, which is both kinder and easier to explain
 * to a client on the phone.
 *
 * The address is hashed rather than stored. The key is a rate-limit counter, not a visitor log, and
 * an option row naming who filled in a contact form is not something this plugin should create.
 *
 * The key is built by its own function purely so that tests/rest.php can assert the window number
 * is part of it — which is the whole fixed-versus-rolling distinction — without re-implementing the
 * hash and going stale the first time it changes.
 */
function n8nchat_rest_rate_key( $bucket, $ip, $window ) {
	return 'n8nchat_rl_' . substr( md5( $bucket . '|' . (int) $window . '|' . $ip ), 0, 24 );
}

/**
 * @param string      $bucket Which counter.
 * @param int         $max    Hits allowed in the fixed hour.
 * @param string|null $ip     Whose hits to count. Null means the caller's address; an empty string
 *                            means everybody's, which is how the site-wide ceiling is expressed
 *                            without a second near-identical function.
 */
function n8nchat_rest_rate_ok( $bucket, $max, $ip = null ) {
	$window = (int) floor( time() / HOUR_IN_SECONDS );
	$who    = ( null === $ip ) ? n8nchat_rest_client_ip() : (string) $ip;
	$key    = n8nchat_rest_rate_key( $bucket, $who, $window );

	// Two hours rather than one, so the counter is still there for the whole of its own window even
	// when the first hit lands in the last second of it. A key from a past window is never read
	// again; the expiry exists only so the row cleans itself up.
	$ttl = 2 * HOUR_IN_SECONDS;

	return wp_using_ext_object_cache()
		? n8nchat_rest_rate_hit_cache( $key, (int) $max, $ttl )
		: n8nchat_rest_rate_hit_db( $key, (int) $max, $ttl );
}

/**
 * Count one hit in an external object cache.
 *
 * `wp_cache_add()` and `wp_cache_incr()` map onto Redis's SETNX and INCR and Memcached's add and
 * increment, both of which are atomic on the server. That is the whole reason this branch exists
 * separately: it is the only implementation here that is atomic across processes with no caveat.
 *
 * Fails CLOSED. An increment that cannot be performed is not evidence that the request is within
 * its allowance, and the endpoints this protects send mail — the moment to be permissive is not the
 * moment the counter stops working, which on a site under load is precisely when it will.
 */
function n8nchat_rest_rate_hit_cache( $key, $max, $ttl ) {
	$group = 'n8nchat-rl';

	// add() only succeeds for the first caller, so concurrent creators cannot each reset the count.
	wp_cache_add( $key, 0, $group, $ttl );

	$hits = wp_cache_incr( $key, 1, $group );
	if ( false === $hits ) { return false; }

	return (int) $hits <= $max;
}

/**
 * Count one hit in the database.
 *
 * WHY THIS IS NOT `get_transient()` PLUS `set_transient()`.
 *
 * That pair is a read, then a decision, then a write, and nothing stops another request reading the
 * same value in between. Under the automated flood these limits exist for, every request in a burst
 * reads the same count, every one of them decides it is under the limit, and every one of them
 * writes the same next value back — so the counter barely advances while the mail goes out. The
 * limit is not merely exceeded, it is defeated, and it is defeated exactly when it matters. That is
 * not a theoretical race: it is the normal behaviour of parallel HTTP requests.
 *
 * Both statements below are single SQL statements, so MySQL applies them one at a time:
 *
 *   - `INSERT IGNORE` against the UNIQUE `option_name` index. Of any number of racing creators
 *     precisely one affects a row; the rest affect none and fall through to the update.
 *   - `UPDATE ... WHERE option_value + 0 < max`. The read and the write are the same statement, so
 *     a request can only increment a counter that was under the ceiling at the instant it did.
 *
 * The result is that the ceiling cannot be overrun however many requests arrive at once.
 *
 * Direct queries rather than the options API on purpose: `add_option()` is an UPSERT behind an
 * unlocked existence check, so two racing callers can both write and reset the count to one, and
 * `update_option()` has no way to express "only if still under the limit". Neither can be made
 * atomic from outside.
 */
function n8nchat_rest_rate_hit_db( $key, $max, $ttl ) {
	global $wpdb;

	// Fail closed: no database is not evidence of being within an allowance.
	if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) { return false; }

	// The rows WordPress's own transient functions use, so `get_transient()` still sees this counter
	// and its expiry still applies — this is a transient, just one incremented atomically.
	$row     = '_transient_' . $key;
	$timeout = '_transient_timeout_' . $key;

	// Under the ceiling? Increment. The WHERE clause is the check, which is what makes it safe.
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	$rows = $wpdb->query( $wpdb->prepare(
		"UPDATE {$wpdb->options} SET option_value = option_value + 1 WHERE option_name = %s AND option_value + 0 < %d",
		$row,
		$max
	) );

	if ( false === $rows ) { return false; }          // a database error, treated as a refusal
	if ( $rows > 0 ) { n8nchat_rest_rate_forget( $row ); return true; }

	// No row was updated: either the counter does not exist yet, or it has reached the ceiling.
	// Creating it is the same question asked atomically — exactly one caller inserts.
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	$created = $wpdb->query( $wpdb->prepare(
		"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, %s)",
		$row,
		'1',
		'no'
	) );

	if ( false === $created ) { return false; }

	if ( $created > 0 ) {
		// We created the counter, so we also own setting its expiry. If this second insert fails the
		// counter simply never expires by itself; the key contains the window number, so a stale row
		// is never read again and WordPress sweeps expired transients on its own schedule.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( $wpdb->prepare(
			"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, %s)",
			$timeout,
			(string) ( time() + (int) $ttl ),
			'no'
		) );
		n8nchat_rest_rate_forget( $row );
		n8nchat_rest_rate_forget( $timeout );
		return true;
	}

	// Somebody else created it in the gap. Ask again, now that there is a row to increment.
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	$rows = $wpdb->query( $wpdb->prepare(
		"UPDATE {$wpdb->options} SET option_value = option_value + 1 WHERE option_name = %s AND option_value + 0 < %d",
		$row,
		$max
	) );

	n8nchat_rest_rate_forget( $row );
	return ( false !== $rows && $rows > 0 );
}

/**
 * Drop one option from the in-request cache after writing it behind the options API's back.
 *
 * Without this, anything later in the same request that reads the counter through `get_transient()`
 * is served the value from before the update — which is how a "belt and braces" second check ends
 * up disagreeing with the one that actually counted.
 */
function n8nchat_rest_rate_forget( $name ) {
	if ( function_exists( 'wp_cache_delete' ) ) { wp_cache_delete( $name, 'options' ); }
}

/**
 * A string that is safe to put in a mail header.
 *
 * Carriage returns and newlines are how a header becomes two headers, and two headers is how a
 * visitor's "name" becomes `Bcc: everyone@somewhere.example`. Nothing user-supplied reaches a
 * header in this file at all — see n8nchat_rest_send_mail() — but the subject line interpolates the
 * site's own name, which is admin-controlled rather than trusted, so it goes through here too.
 */
function n8nchat_rest_header_safe( $value ) {
	return trim( (string) preg_replace( '/[\x00-\x1F\x7F]+/', ' ', (string) $value ) );
}

/**
 * One line of plain text, trimmed to a hard cap.
 *
 * sanitize_text_field() already strips tags and collapses control characters including newlines,
 * which is most of what is wanted; the cap is what stops a name field being used to post a
 * megabyte. n8nchat_mb_substr() rather than substr() because the plugin runs on hosts without
 * mbstring, where a direct mb_substr() call is a fatal.
 */
function n8nchat_rest_text( $raw, $max ) {
	if ( ! is_scalar( $raw ) ) { return ''; }
	return (string) n8nchat_mb_substr( sanitize_text_field( (string) $raw ), 0, (int) $max );
}

/** The same, for a field where line breaks are meaningful. */
function n8nchat_rest_multiline( $raw, $max ) {
	if ( ! is_scalar( $raw ) ) { return ''; }
	return (string) n8nchat_mb_substr( sanitize_textarea_field( (string) $raw ), 0, (int) $max );
}

/**
 * Length, counted the same way n8nchat_mb_substr() cuts.
 *
 * The pairing is the point. Measuring a budget in BYTES and then spending it with a CHARACTER-based
 * cut lets a transcript of, say, Greek or emoji overshoot its own cap by up to four times — the
 * running total believes it has spent 20,000 when it has actually emitted 80,000. Both halves ask
 * mbstring the same question, or neither does.
 */
function n8nchat_rest_len( $value ) {
	return function_exists( 'mb_strlen' ) ? mb_strlen( (string) $value ) : strlen( (string) $value );
}

/**
 * The page the visitor was on, but only if it is a page on this site.
 *
 * The value arrives from the browser and lands in an email that a member of staff will read and
 * quite possibly click. Left unchecked it is a free "your enquiry came from <attacker's link>" in a
 * message that appears to come from the client's own website — a phishing lure with the site's own
 * branding on it. An off-site URL is therefore dropped entirely rather than escaped and shown.
 */
function n8nchat_rest_page_url( $raw ) {
	if ( ! is_scalar( $raw ) ) { return ''; }
	$url = esc_url_raw( trim( (string) $raw ), [ 'http', 'https' ] );
	if ( '' === $url ) { return ''; }
	$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
	return in_array( $host, n8nchat_rest_allowed_hosts(), true ) ? $url : '';
}

/**
 * The conversation id, for correlating this enquiry with the transcript in the portal.
 *
 * Narrowed to the characters a UUID can contain rather than merely sanitised, because it is
 * repeated back into an email and there is no reason for anything else ever to appear here.
 */
function n8nchat_rest_session_id( $raw ) {
	if ( ! is_scalar( $raw ) ) { return ''; }
	return (string) substr( preg_replace( '/[^A-Za-z0-9\-]/', '', (string) $raw ), 0, 64 );
}

/**
 * Send one email, as HTML, with the content type pinned.
 *
 * The pinning is not belt and braces — it is load-bearing, and the reason is easy to miss. Core
 * applies the `wp_mail_content_type` filter UNCONDITIONALLY, after it has finished reading the
 * headers passed in, so a Content-Type header supplied here is overridden by any plugin on the site
 * that sets that filter globally (SMTP plugins and mail-template plugins routinely do). A body
 * built as plain text can therefore arrive as HTML on a site nobody involved has ever seen,
 * whereupon a stranger's typed message is parsed as markup in a colleague's inbox.
 *
 * So the body is built as escaped HTML and the filter is forced for the duration of this one call.
 * Whichever way the site is configured, the recipient gets what was intended, and nothing a visitor
 * typed can be anything other than text.
 *
 * The headers contain no user input of any kind. Reply-To is conspicuously absent, and its absence
 * is deliberate twice over: it is the classic header-injection sink, and even done safely it sets a
 * reply address that nobody has verified, so a stranger could make a reply to a colleague's genuine
 * "thanks, I'll call you" go to an address of their choosing. The visitor's address is in the body,
 * where it can be read and copied by a person who has seen the context.
 */
function n8nchat_rest_send_mail( $to, $subject, $body_html ) {
	$headers = [ 'Content-Type: text/html; charset=UTF-8' ];

	$force = function () { return 'text/html'; };
	add_filter( 'wp_mail_content_type', $force, PHP_INT_MAX );
	$sent = wp_mail( $to, n8nchat_rest_header_safe( $subject ), $body_html, $headers );
	remove_filter( 'wp_mail_content_type', $force, PHP_INT_MAX );

	return (bool) $sent;
}

/**
 * Wrap an email body in the least markup that will render sensibly everywhere.
 *
 * No stylesheet, no table layout and no images: this is an internal notification read once, and
 * every one of those adds a way for it to be filed as spam.
 */
function n8nchat_rest_mail_wrapper( $heading, $rows_html, $footer ) {
	$out  = '<div style="font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;font-size:15px;line-height:1.55;color:#1a1d21">';
	$out .= '<h2 style="margin:0 0 12px;font-size:17px">' . esc_html( $heading ) . '</h2>';
	$out .= $rows_html;
	if ( '' !== $footer ) {
		$out .= '<p style="margin:18px 0 0;font-size:12px;color:#6b7280">' . esc_html( $footer ) . '</p>';
	}
	$out .= '</div>';
	return $out;
}

/**
 * One labelled row of an email body.
 *
 * `esc_html()` on the value and nl2br() after it, never the other way round: escaping second would
 * turn the `<br>` this function just wrote into visible text.
 */
function n8nchat_rest_mail_row( $label, $value ) {
	return '<p style="margin:0 0 10px"><strong>' . esc_html( $label ) . ':</strong><br>'
		. nl2br( esc_html( $value ) ) . '</p>';
}

/**
 * The guards every callback runs before it looks at a single field.
 *
 * Ordered cheapest-and-most-decisive first. Note that the rate limiter is counted BEFORE the
 * honeypot and the timing floor: a bot that trips the honeypot on every attempt must still consume
 * its own allowance, or "fails the honeypot" becomes "may post for ever".
 *
 * @return true|WP_Error
 */
function n8nchat_rest_guard( $request, $feature_on, $bucket, $max ) {
	if ( ! $feature_on ) {
		// A site that has never switched the feature on should not have an endpoint that accepts
		// mail-shaped input, whatever else is true.
		return new WP_Error(
			'n8nchat_disabled',
			__( 'This form is not available.', 'n8n-chatbot' ),
			[ 'status' => 403 ]
		);
	}

	if ( ! n8nchat_rest_origin_ok() ) {
		return new WP_Error(
			'n8nchat_bad_origin',
			__( 'This request did not come from this website.', 'n8n-chatbot' ),
			[ 'status' => 403 ]
		);
	}

	if ( ! n8nchat_rest_rate_ok( $bucket, $max ) ) {
		return new WP_Error(
			'n8nchat_rate_limited',
			__( 'Too many messages have been sent from this connection. Please try again later.', 'n8n-chatbot' ),
			[ 'status' => 429 ]
		);
	}

	$limits = n8nchat_rest_limits();

	// The site-wide ceiling. See n8nchat_rest_limits() for why this exists and why it is confined to
	// one endpoint. Counted under a fixed key so every address shares one bucket; a rotating-address
	// abuser therefore hits it just as fast as a single one would.
	if ( 'transcript' === $bucket && ! n8nchat_rest_rate_ok( 'transcript-site', (int) $limits['transcript_per_hour_site'], '' ) ) {
		return new WP_Error(
			'n8nchat_rate_limited',
			__( 'This form is temporarily unavailable. Please try again later.', 'n8n-chatbot' ),
			[ 'status' => 429 ]
		);
	}
	if ( (int) $request->get_param( 'elapsed' ) < (int) $limits['min_elapsed_ms'] ) {
		// A real error rather than a silent discard, because the honest failure here is a human who
		// was quicker than expected, and throwing their enquiry away without telling them would be
		// the worst outcome available. Trying again a second later succeeds.
		return new WP_Error(
			'n8nchat_too_fast',
			__( 'That was sent too quickly. Please try again.', 'n8n-chatbot' ),
			[ 'status' => 400 ]
		);
	}

	return true;
}

/**
 * Was the honeypot filled in?
 *
 * The field is off-screen, has no label and is skipped by the keyboard, so a person never sees it
 * and a form-filling bot fills it because it fills everything.
 *
 * Its NAME matters more than it looks. Anything resembling `website`, `url`, `company` or `phone`
 * is a name browser autofill recognises, and an autofilled honeypot silently bins the enquiry of a
 * real customer who has done nothing wrong — the one failure mode of this technique that is worse
 * than the spam it prevents. `n8nchat_hp` matches nothing any password manager or autofill
 * heuristic looks for.
 */
function n8nchat_rest_honeypot_tripped( $request ) {
	$value = $request->get_param( 'n8nchat_hp' );
	return is_scalar( $value ) && '' !== trim( (string) $value );
}

/**
 * POST /lead — a visitor's details, on their way to a human.
 */
function n8nchat_rest_lead( $request ) {
	$s      = n8nchat_settings();
	$limits = n8nchat_rest_limits();

	$guard = n8nchat_rest_guard( $request, ! empty( $s['handoff_enabled'] ), 'lead', $limits['lead_per_hour'] );
	if ( is_wp_error( $guard ) ) { return $guard; }

	// A tripped honeypot gets a plain success. Telling a bot precisely which of its fields gave it
	// away is free tuning advice, and the only cost of the lie is that a script believes it sent
	// something. Nothing is emailed and nothing is posted onward.
	if ( n8nchat_rest_honeypot_tripped( $request ) ) {
		return [ 'ok' => true ];
	}

	$name    = n8nchat_rest_text( $request->get_param( 'name' ), $limits['name'] );
	$email   = sanitize_email( n8nchat_rest_text( $request->get_param( 'email' ), $limits['email'] ) );
	$message = n8nchat_rest_multiline( $request->get_param( 'message' ), $limits['message'] );
	$page    = n8nchat_rest_page_url( $request->get_param( 'page' ) );
	$session = n8nchat_rest_session_id( $request->get_param( 'session' ) );

	if ( '' === $name ) {
		return new WP_Error( 'n8nchat_no_name', __( 'Please enter your name.', 'n8n-chatbot' ), [ 'status' => 400 ] );
	}
	// is_email() as well as sanitize_email(), because they are not the same test: sanitize_email()
	// strips the characters an address may not contain and hands back what is left, which for a
	// thorough enough mangling is a short string that is not an address at all.
	if ( '' === $email || ! is_email( $email ) ) {
		return new WP_Error( 'n8nchat_bad_email', __( 'Please enter a valid email address.', 'n8n-chatbot' ), [ 'status' => 400 ] );
	}

	// THE RECIPIENT IS NEVER TAKEN FROM THE REQUEST. It comes from the settings, or from the site's
	// own admin address when the setting is blank or has been mangled into something that is not an
	// address — a site whose handoff email is a typo must still deliver its enquiries somewhere.
	$to = isset( $s['handoff_email'] ) ? trim( (string) $s['handoff_email'] ) : '';
	if ( '' === $to || ! is_email( $to ) ) {
		$to = (string) get_option( 'admin_email' );
	}

	/**
	 * Filter where a lead is emailed.
	 *
	 * @param string $to The resolved recipient.
	 * @param array  $s  Resolved plugin settings.
	 */
	$to = (string) apply_filters( 'n8nchat_lead_recipient', $to, $s );

	$site = n8nchat_rest_header_safe( get_bloginfo( 'name' ) );

	$rows  = n8nchat_rest_mail_row( __( 'Name', 'n8n-chatbot' ), $name );
	$rows .= n8nchat_rest_mail_row( __( 'Email', 'n8n-chatbot' ), $email );
	if ( '' !== $message ) {
		$rows .= n8nchat_rest_mail_row( __( 'Message', 'n8n-chatbot' ), $message );
	}
	if ( '' !== $page ) {
		$rows .= n8nchat_rest_mail_row( __( 'Page', 'n8n-chatbot' ), $page );
	}
	if ( '' !== $session ) {
		$rows .= n8nchat_rest_mail_row( __( 'Conversation', 'n8n-chatbot' ), $session );
	}

	$mailed = is_email( $to ) && n8nchat_rest_send_mail(
		$to,
		sprintf( '%s: %s', $site, __( 'chat enquiry', 'n8n-chatbot' ) ),
		n8nchat_rest_mail_wrapper(
			__( 'Someone asked to speak to a person', 'n8n-chatbot' ),
			$rows,
			__( 'Sent by the chat widget. Nothing from this conversation is stored on the website.', 'n8n-chatbot' )
		)
	);

	$payload = [
		'name'    => $name,
		'email'   => $email,
		'message' => $message,
		'page'    => $page,
		'session' => $session,
		'bot_id'  => isset( $s['bot_id'] ) ? (string) $s['bot_id'] : '',
		'site'    => home_url( '/' ),
		'sent_at' => gmdate( 'c' ),
	];

	/**
	 * Filter the JSON posted to the secondary handoff webhook.
	 *
	 * @param array $payload The enquiry.
	 * @param array $s       Resolved plugin settings.
	 */
	$payload = (array) apply_filters( 'n8nchat_lead_payload', $payload, $s );

	$posted  = false;
	$webhook = isset( $s['handoff_webhook'] ) ? trim( (string) $s['handoff_webhook'] ) : '';
	if ( '' !== $webhook ) {
		// Blocking, but on a short leash. Fire-and-forget would mean never knowing the CRM was down;
		// a long timeout would mean the visitor watching a spinner while somebody else's server
		// decides whether to answer. Five seconds is long enough for a healthy endpoint and short
		// enough that a dead one is not the visitor's problem.
		$response = wp_remote_post( $webhook, [
			'timeout'     => 5,
			'redirection' => 0,
			'headers'     => [ 'Content-Type' => 'application/json' ],
			'body'        => wp_json_encode( $payload ),
		] );
		if ( ! is_wp_error( $response ) ) {
			$code   = (int) wp_remote_retrieve_response_code( $response );
			$posted = $code >= 200 && $code < 300;
		}
	}

	// Either delivery counts. The two routes exist so that a site can rely on whichever suits it,
	// and telling a visitor their enquiry failed because the optional CRM copy bounced — when the
	// enquiry is already sitting in the inbox somebody reads — would be a lie in the unhelpful
	// direction.
	if ( ! $mailed && ! $posted ) {
		return new WP_Error(
			'n8nchat_not_sent',
			__( 'We could not send that just now. Please try again shortly.', 'n8n-chatbot' ),
			[ 'status' => 500 ]
		);
	}

	return [ 'ok' => true ];
}

/**
 * POST /transcript — the visitor emails themselves the conversation.
 *
 * This is the one endpoint where the visitor DOES choose the recipient, because "email me this
 * conversation" has no other meaning. That makes it, unavoidably, a way to send an email to an
 * arbitrary address with content the sender wrote — so it is treated as the more dangerous of the
 * two: a tighter rate limit, a hard cap on how much text can travel, and a body that says plainly
 * which site it came from and that the visitor asked for it, so a recipient who did not expect it
 * knows immediately what they are looking at.
 *
 * The transcript arrives from the browser and the server cannot verify a word of it. It could not
 * be otherwise: the site stores no conversation to check it against, which is the entire privacy
 * position of the product. The endpoint is a relay and is written as one.
 */
function n8nchat_rest_transcript( $request ) {
	$s      = n8nchat_settings();
	$limits = n8nchat_rest_limits();

	$guard = n8nchat_rest_guard( $request, ! empty( $s['transcript_email'] ), 'transcript', $limits['transcript_per_hour'] );
	if ( is_wp_error( $guard ) ) { return $guard; }

	if ( n8nchat_rest_honeypot_tripped( $request ) ) {
		return [ 'ok' => true ];
	}

	$to = sanitize_email( n8nchat_rest_text( $request->get_param( 'email' ), $limits['email'] ) );
	if ( '' === $to || ! is_email( $to ) ) {
		return new WP_Error( 'n8nchat_bad_email', __( 'Please enter a valid email address.', 'n8n-chatbot' ), [ 'status' => 400 ] );
	}

	$body = n8nchat_rest_transcript_html( $request->get_param( 'messages' ), $s, $limits );
	if ( '' === $body ) {
		return new WP_Error( 'n8nchat_empty', __( 'There is no conversation to send yet.', 'n8n-chatbot' ), [ 'status' => 400 ] );
	}

	$site = n8nchat_rest_header_safe( get_bloginfo( 'name' ) );
	$page = n8nchat_rest_page_url( $request->get_param( 'page' ) );

	if ( '' !== $page ) {
		$body .= '<p style="margin:18px 0 0;font-size:13px"><a href="' . esc_url( $page ) . '">' . esc_html( $page ) . '</a></p>';
	}

	$sent = n8nchat_rest_send_mail(
		$to,
		sprintf( '%s: %s', $site, __( 'your conversation', 'n8n-chatbot' ) ),
		n8nchat_rest_mail_wrapper(
			sprintf(
				/* translators: %s: site name. */
				__( 'Your conversation with %s', 'n8n-chatbot' ),
				$site
			),
			$body,
			__( 'You asked for this copy from the chat widget on this website. The website does not keep a copy.', 'n8n-chatbot' )
		)
	);

	if ( ! $sent ) {
		return new WP_Error(
			'n8nchat_not_sent',
			__( 'We could not send that just now. Please try again shortly.', 'n8n-chatbot' ),
			[ 'status' => 500 ]
		);
	}

	return [ 'ok' => true ];
}

/**
 * Turn the posted conversation into the body of an email.
 *
 * Three caps, and each is here for its own reason. The message count stops a client's mail server
 * being handed a hundred thousand rows to render. The per-message cut and the running total stop a
 * single enormous "message" doing the same thing in one field — a cap on the number of items is not
 * a cap on the size of the payload, which is the mistake that makes this sort of endpoint a denial
 * of service against the site's own mail queue.
 *
 * Every fragment is escaped. The text was typed by a stranger and read by whoever asked for the
 * copy, and by the time it is in an inbox there is no further sanitiser between it and a mail
 * client that will happily render markup.
 */
function n8nchat_rest_transcript_html( $messages, $s, $limits ) {
	if ( ! is_array( $messages ) ) { return ''; }

	$bot   = isset( $s['bot_label'] ) && '' !== trim( (string) $s['bot_label'] )
		? (string) $s['bot_label']
		: __( 'Assistant', 'n8n-chatbot' );
	$user  = isset( $s['user_label'] ) && '' !== trim( (string) $s['user_label'] )
		? (string) $s['user_label']
		: __( 'You', 'n8n-chatbot' );

	$out       = '';
	$used      = 0;
	$rendered  = 0;
	$truncated = false;

	foreach ( $messages as $entry ) {
		if ( $rendered >= (int) $limits['transcript_messages'] ) { $truncated = true; break; }
		if ( ! is_array( $entry ) ) { continue; }

		$role = isset( $entry['role'] ) && 'user' === $entry['role'] ? 'user' : 'bot';
		$text = isset( $entry['text'] ) ? n8nchat_rest_multiline( $entry['text'], $limits['message'] ) : '';
		if ( '' === $text ) { continue; }

		$remaining = (int) $limits['transcript_chars'] - $used;
		if ( $remaining <= 0 ) { $truncated = true; break; }
		if ( n8nchat_rest_len( $text ) > $remaining ) {
			$text      = (string) n8nchat_mb_substr( $text, 0, $remaining );
			$truncated = true;
		}

		$used += n8nchat_rest_len( $text );
		$rendered++;

		$out .= '<p style="margin:0 0 12px"><strong>' . esc_html( 'user' === $role ? $user : $bot ) . '</strong><br>'
			. nl2br( esc_html( $text ) ) . '</p>';

		if ( $truncated ) { break; }
	}

	if ( '' === $out ) { return ''; }

	if ( $truncated ) {
		$out .= '<p style="margin:0 0 12px;color:#6b7280">' . esc_html__( 'This conversation was too long to send in full.', 'n8n-chatbot' ) . '</p>';
	}

	return $out;
}

/**
 * Where a rating is kept.
 *
 * One bounded wp_options row. It deliberately holds NO session id, NO message id and no message
 * text: 2.0 made a considered decision not to log conversations in WordPress, and a table that can
 * tie a thumbs-down back to a specific visitor's conversation is that log by another name. What is
 * here is a tally and a page URL, which is the part an owner can actually act on — "the answers on
 * /membership are being marked wrong" is a fixable finding; "visitor 4f2a was unhappy" is not.
 *
 * Anyone who does want the full payload can have it: `n8nchat_feedback` fires with everything the
 * browser sent, before any of this is written.
 */
function n8nchat_feedback_option() {
	return 'n8nchat_feedback';
}

/** How many recent entries are kept. Old ones fall off the end. */
function n8nchat_feedback_keep() {
	/**
	 * Filter how many individual ratings are retained.
	 *
	 * @param int $keep Number of recent entries.
	 */
	return (int) apply_filters( 'n8nchat_feedback_keep', 50 );
}

/**
 * Record a rating.
 *
 * Read-modify-write on a single option, which is not atomic — two ratings landing in the same
 * millisecond can lose one. That is accepted here and would not be in the rate limiter: a limiter
 * that undercounts lets an abuser through, whereas a tally that undercounts by one is a tally that
 * is off by one. Trading a table and a migration for that is not a good trade.
 */
function n8nchat_feedback_record( $rating, $page ) {
	$store = get_option( n8nchat_feedback_option(), [] );
	if ( ! is_array( $store ) ) { $store = []; }

	$up   = isset( $store['up'] ) ? (int) $store['up'] : 0;
	$down = isset( $store['down'] ) ? (int) $store['down'] : 0;

	if ( 'up' === $rating ) { $up++; } else { $down++; }

	$recent = isset( $store['recent'] ) && is_array( $store['recent'] ) ? $store['recent'] : [];
	array_unshift( $recent, [
		'r' => $rating,
		'p' => $page,
		't' => time(),
	] );
	$recent = array_slice( $recent, 0, n8nchat_feedback_keep() );

	return update_option( n8nchat_feedback_option(), [
		'up'     => $up,
		'down'   => $down,
		'recent' => $recent,
	], false );
}

/**
 * POST /feedback — a thumbs up or down on one reply.
 *
 * Unlike /lead and /transcript this has no honeypot and no timing floor, because it is not a form:
 * there is no field for a bot to fill in, and "the visitor was too quick" is meaningless for a
 * control that appears next to an answer they have just read. Origin and rate limit are the whole
 * defence, and they are enough for an endpoint whose worst-case abuse is a wrong number in a tally.
 *
 * It is also NOT gated on a feature toggle. The buttons ship visible, so the endpoint that makes
 * them mean something has to be there too — a rating control that silently discards ratings is the
 * exact defect this route was added to fix.
 */
function n8nchat_rest_feedback( $request ) {
	if ( ! n8nchat_rest_origin_ok() ) {
		return new WP_Error(
			'n8nchat_bad_origin',
			__( 'This request did not come from this website.', 'n8n-chatbot' ),
			[ 'status' => 403 ]
		);
	}

	$limits = n8nchat_rest_limits();
	if ( ! n8nchat_rest_rate_ok( 'feedback', (int) $limits['feedback_per_hour'] ) ) {
		return new WP_Error(
			'n8nchat_rate_limited',
			__( 'Too many ratings have been sent from this connection.', 'n8n-chatbot' ),
			[ 'status' => 429 ]
		);
	}

	$rating = is_scalar( $request->get_param( 'rating' ) ) ? (string) $request->get_param( 'rating' ) : '';
	if ( 'up' !== $rating && 'down' !== $rating ) {
		return new WP_Error(
			'n8nchat_bad_rating',
			__( 'That is not a rating.', 'n8n-chatbot' ),
			[ 'status' => 400 ]
		);
	}

	$page = n8nchat_rest_page_url( $request->get_param( 'page' ) );

	/**
	 * Fires when a visitor rates a reply, before anything is stored.
	 *
	 * This is the extension point for anyone who wants the rating somewhere other than the option
	 * row — a CRM, a webhook, the n8n workflow, an email. It receives the session and message ids
	 * that the stored tally deliberately does not keep.
	 *
	 * @param array $data rating, session_id, message_id, page, ip.
	 */
	do_action( 'n8nchat_feedback', [
		'rating'     => $rating,
		'session_id' => n8nchat_rest_session_id( $request->get_param( 'sessionId' ) ),
		'message_id' => n8nchat_rest_text( $request->get_param( 'messageId' ), 64 ),
		'page'       => $page,
		'ip'         => n8nchat_rest_client_ip(),
	] );

	n8nchat_feedback_record( $rating, $page );

	return rest_ensure_response( [ 'ok' => true ] );
}

/**
 * Register the routes.
 *
 * `permission_callback` is `__return_true` on purpose and WordPress is right to warn about it in
 * general — an endpoint with no permission check is usually a mistake. This one is public by
 * definition (see the file header) and its defences are in the callbacks, which is the only place
 * they could be for a visitor with no account, no session and no nonce worth having.
 *
 * `args` deliberately declares no `validate_callback`s. Every field is sanitised in the callback
 * anyway, and a rejection there can be worded for a visitor rather than returned as the REST API's
 * own `rest_invalid_param`, which reads like a bug report.
 */
add_action( 'rest_api_init', function () {
	$common = [
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
	];

	register_rest_route( n8nchat_rest_namespace(), '/lead', array_merge( $common, [
		'callback' => 'n8nchat_rest_lead',
	] ) );

	register_rest_route( n8nchat_rest_namespace(), '/transcript', array_merge( $common, [
		'callback' => 'n8nchat_rest_transcript',
	] ) );

	register_rest_route( n8nchat_rest_namespace(), '/feedback', array_merge( $common, [
		'callback' => 'n8nchat_rest_feedback',
	] ) );
} );
