/*
 * n8n Chatbot Widget — "talk to a person", and "email me this conversation".
 *
 * Split out of widget.js rather than added to it, for two reasons that both cost money the last
 * time they were ignored. The chat is already the largest module the plugin ships and every
 * kilobyte of it is downloaded the moment a visitor touches the launcher; and widget.js is the file
 * every future feature wants to grow into, which is how a 900-line file becomes a 2,000-line one
 * nobody dares refactor. Everything here is self-contained: it is handed the nodes it may write to
 * and the handful of functions it may call, and it touches nothing else.
 *
 * WHAT THE ASSISTANT SAYS TO OPEN THE CARD
 *
 * The workflow can raise the handoff card itself by putting a Markdown link to the fragment
 * `#n8nchat-handoff` in its reply, on a line of its own:
 *
 *     I can put you through to a colleague.
 *
 *     [Talk to a person](#n8nchat-handoff)
 *
 * The label is the workflow's own words and is never read by the widget, only shown. That is the
 * entire convention, and the reasoning behind that shape is worth recording because the obvious
 * alternatives are all worse:
 *
 *   - It cannot collide with prose. A model writing about anything at all will not emit a Markdown
 *     link to that exact fragment by accident, and unlike a bare sentinel — `[[handoff]]`,
 *     `::handoff::`, an HTML comment — there is no phrasing, no quoted example and no code sample in
 *     which it could appear innocently.
 *   - IT DEGRADES INTO SOMETHING A PERSON CAN READ. This is the part that decides the choice. The
 *     workflow and the plugin are updated by different people at different times, so a bot WILL at
 *     some point emit this marker at a site still running an older widget. A sentinel degrades into
 *     visible punctuation soup in the middle of a support answer; assets/widget/markdown.js turns
 *     this into an ordinary link whose text is the sentence the workflow author wrote. The offer is
 *     still legible, and the worst a visitor can do with it is jump to the top of the page.
 *   - It needs no agreement about the response format. Structured replies — cards, quick replies,
 *     inline forms — need a real extension to what the Chat Trigger emits and a version negotiation
 *     to go with it. This needs a workflow author to type one line.
 *
 * The fragment is matched exactly, so `#n8nchat-handoff-please` is not a marker and renders as the
 * link it is.
 *
 * NOTHING TYPED INTO THESE FORMS IS EVER STORED. Not in localStorage, not in the page's own state
 * beyond the life of the form, and — see inc/rest.php — not in the WordPress database at the other
 * end either. The one thing that is remembered is a boolean saying an enquiry was sent, and only so
 * that the card does not reopen itself on every subsequent page view of a conversation whose
 * transcript still contains the marker.
 */

/** The fragment an assistant links to in order to raise the card. Also documented in README.md. */
export const HANDOFF_MARKER = '#n8nchat-handoff';

const el = (tag, cls, text) => {
  const node = document.createElement(tag);
  if (cls) { node.className = cls; }
  if (text != null) { node.textContent = text; }
  return node;
};

const ICONS = {
  person: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" ' +
    'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' +
    '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
  mail: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" ' +
    'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' +
    '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>'
};

/**
 * How long this page has been open, in milliseconds.
 *
 * The endpoints refuse a submission that arrives within a few seconds of the page loading, because
 * that is what a form-spam script does and what a human filling in a name and an email cannot. This
 * is the value they judge, so it has to mean time since the PAGE loaded rather than time since this
 * module loaded — the module is imported on first interaction, which on an impatient visitor is a
 * second or two after the page appeared.
 */
const IMPORTED_AT = Date.now();
function elapsedMs() {
  if (typeof performance !== 'undefined' && typeof performance.now === 'function') {
    return Math.round(performance.now());
  }
  return Date.now() - IMPORTED_AT;
}

/**
 * Mount the handoff and transcript features.
 *
 * @param {object} api Everything this module is allowed to touch, handed over explicitly.
 * @param {object} api.cfg          The boot configuration (restUrl, strings, storage, scope).
 * @param {object} api.strings      cfg.strings, already resolved.
 * @param {object} api.ui           cfg.ui, already resolved.
 * @param {object} api.store        boot.js's consent-aware storage.
 * @param {function} api.announce   boot.js's polite live region.
 * @param {Element} api.win         The chat window, for placing the utility row.
 * @param {Element} api.list        The transcript, where cards are inserted.
 * @param {Element} api.chips       The chip row; the utility row goes immediately above it.
 * @param {string} api.sessionId    The conversation id, for correlating an enquiry in the portal.
 * @param {function} api.getMessages Reads the live transcript. A function, not an array, because
 *        widget.js REPLACES its `messages` array on regenerate and on restore rather than mutating
 *        it, so a captured reference would quietly go stale and email an old conversation.
 * @returns {{scan: function(Element, object): void}}
 */
export function createHandoff(api) {
  const cfg = api.cfg || {};
  const S = api.strings || {};
  const UI = api.ui || {};
  const store = api.store;
  const announce = api.announce || function () {};
  const rest = String(cfg.restUrl || '');

  const canLead = !!UI.handoff && '' !== rest;
  const canTranscript = !!UI.transcript && '' !== rest;

  // Nothing enabled: return the same shape so widget.js never has to ask, and add not a single node
  // to the DOM. Both settings are off by default, so this is the common case on most sites.
  if (!canLead && !canTranscript) {
    return { scan: function () {} };
  }

  /*
   * The one flag this module persists, and the reason it is not conversational data.
   *
   * The marker lives in the reply text, and the reply text is replayed from localStorage on every
   * page of the visit — so without this, a visitor who has already left their details is shown the
   * form again on the next page, and the page after that, for as long as the conversation is
   * remembered. The flag suppresses only the AUTOMATIC reopening; the utility-row button below is
   * unaffected, so somebody who wants to send a second enquiry always can.
   *
   * Scoped by hand rather than through boot.js's key map because boot.js does not know this feature
   * exists. The rule is the one every other key follows: localStorage is scoped by the browser to
   * origin and never to path, so on a subdirectory multisite two subsites share one storage area.
   *
   * store.set() writes to localStorage only when consent allows it and keeps the value in memory
   * otherwise, so under a consent mode that has not been satisfied this still does the right thing
   * for the current page and writes nothing down.
   */
  const SENT_KEY = 'n8n-chat/handoffSent' + (cfg.scope ? ':' + cfg.scope : '');

  let seq = 0;
  const uid = () => 'wwc-h' + (++seq);

  /** The open card, if any. One at a time: two half-filled forms in one transcript help nobody. */
  let openCard = null;

  /**
   * The open card, but only if it is still on the page.
   *
   * widget.js rebuilds the whole transcript from scratch on repaint() — which runs on restore, on
   * "try again" after a failed reply, and on regenerate — so a card can be removed from the DOM
   * without this module being told. Holding the detached node and treating it as open made every
   * later click on the utility row a no-op: the button highlighted, scrollIntoView() ran on a node
   * in no document, and nothing appeared. Found in a browser; entirely invisible from Node, because
   * the object is still perfectly valid, just no longer anywhere.
   */
  function current() {
    if (openCard && openCard.isConnected) { return openCard; }
    openCard = null;
    return null;
  }

  /* ---------------------------------------------------------------- utility row */

  const util = el('div', 'wwc-util');
  api.win.insertBefore(util, api.chips);

  function utilButton(label, iconSvg, onClick) {
    const b = el('button', 'wwc-ubtn');
    b.type = 'button';
    b.innerHTML = iconSvg;
    // The icon is decoration and the words are the accessible name, which is why the label is a
    // real text node rather than an aria-label: an icon-only control here would be one more thing
    // a visitor has to hover to understand, in the corner of the screen where they are least
    // inclined to explore.
    b.appendChild(document.createTextNode(label));
    b.addEventListener('click', onClick);
    return b;
  }

  const leadBtn = canLead
    ? utilButton(S.handoff || 'Talk to a person', ICONS.person, function () { openLead({ focus: true }); })
    : null;
  if (leadBtn) { util.appendChild(leadBtn); }

  const transcriptBtn = canTranscript
    ? utilButton(S.emailIt || 'Email me this conversation', ICONS.mail, function () { openTranscript(); })
    : null;
  if (transcriptBtn) {
    transcriptBtn.hidden = true; // until there is something to send; see refresh()
    util.appendChild(transcriptBtn);
  }

  /**
   * Keep the utility row honest about what it can currently do.
   *
   * Offering "email me this conversation" before a conversation exists is an invitation to press a
   * button that can only answer with an error, and the error would have to come from the server —
   * which cannot check, because the site stores no conversation. Hiding the control until there is
   * one is the version of that check which needs no round trip.
   */
  function refresh() {
    if (transcriptBtn) {
      transcriptBtn.hidden = api.getMessages().length === 0;
    }
    util.hidden = !util.querySelector('.wwc-ubtn:not([hidden])');
  }

  /* ---------------------------------------------------------------- the card */

  /**
   * Build one inline card.
   *
   * A card in the transcript rather than a modal, deliberately. A modal over a 400px chat panel on
   * a phone is a dialog inside a dialog — two focus traps, two Escape handlers and an `aria-modal`
   * that is now lying about which of them owns the screen. Inline, the form is simply the next turn
   * in the conversation, which is also what it is.
   *
   * @param {object} spec
   * @param {string} spec.title      Heading, and the form's accessible name.
   * @param {string} spec.intro      Optional line under the heading.
   * @param {object[]} spec.fields   {name, label, type, required, autocomplete, hint}
   * @param {string} spec.submit     Submit button label.
   * @param {string} spec.done       What is shown in place of the form afterwards.
   * @param {function} spec.send     (values) => Promise, rejecting with {status, message}.
   */
  function buildCard(spec) {
    const card = el('div', 'wwc-card');
    /*
     * The transcript is role="log" with aria-live="polite", so anything inserted into it is read
     * out. For a form that is far too much: a screen reader would recite every label, every hint
     * and the submit button as one uninterrupted announcement before the visitor had any chance to
     * interact. aria-live="off" on the card stops the insertion being announced, and the two paths
     * that open it then say the RIGHT thing instead — focus moves into the first field when the
     * visitor asked for the card, and a single short announcement is made when the assistant
     * offered it unprompted.
     */
    card.setAttribute('aria-live', 'off');

    const form = el('form', 'wwc-card-form');
    form.setAttribute('novalidate', ''); // the browser's own bubbles are unstyleable and unreadable
    const titleId = uid();
    form.setAttribute('aria-labelledby', titleId);

    const heading = el('p', 'wwc-card-title', spec.title);
    heading.id = titleId;
    form.appendChild(heading);

    if (spec.intro) { form.appendChild(el('p', 'wwc-card-intro', spec.intro)); }

    // A place for a failure that belongs to the whole form rather than to one field — the server
    // refusing, the network being down. role="alert" so it is announced the moment it gains text.
    const formError = el('p', 'wwc-card-error');
    formError.setAttribute('role', 'alert');
    formError.hidden = true;
    form.appendChild(formError);

    const inputs = {};

    spec.fields.forEach(function (f) {
      const row = el('div', 'wwc-card-field');
      const id = uid();
      const errId = id + '-e';

      const label = el('label', 'wwc-card-label', f.label);
      label.setAttribute('for', id);
      if (f.hint) {
        const hint = el('span', 'wwc-card-hint', ' (' + f.hint + ')');
        label.appendChild(hint);
      }
      row.appendChild(label);

      const input = el(f.type === 'textarea' ? 'textarea' : 'input', 'wwc-card-input');
      input.id = id;
      input.name = f.name;
      if (f.type !== 'textarea') { input.type = f.type || 'text'; }
      if (f.type === 'textarea') { input.rows = 3; }
      if (f.autocomplete) { input.setAttribute('autocomplete', f.autocomplete); }
      if (f.required) { input.setAttribute('aria-required', 'true'); }
      row.appendChild(input);

      // Present from the start and empty, rather than created on failure. An aria-describedby that
      // points at an element which does not exist yet is ignored by several screen readers even
      // after the element appears, which is how an error message ends up visible on screen and
      // announced to nobody.
      const err = el('p', 'wwc-card-error');
      err.id = errId;
      err.hidden = true;
      row.appendChild(err);

      inputs[f.name] = { input: input, error: err, spec: f };
      form.appendChild(row);
    });

    /*
     * The honeypot.
     *
     * Off-screen, unlabelled and out of the tab order, so no person meets it and every form-filling
     * bot completes it. Its NAME is the part that took thought: anything resembling `website`,
     * `url`, `company` or `phone` is a name browser autofill recognises, and an autofilled honeypot
     * silently discards the enquiry of a customer who did nothing wrong — which is a worse outcome
     * than the spam it exists to stop. `n8nchat_hp` matches no autofill heuristic and no password
     * manager's field detection.
     */
    const hp = el('input', 'wwc-hp');
    hp.type = 'text';
    hp.name = 'n8nchat_hp';
    hp.id = uid();
    hp.tabIndex = -1;
    hp.setAttribute('autocomplete', 'off');
    hp.setAttribute('aria-hidden', 'true');
    form.appendChild(hp);

    const actions = el('div', 'wwc-card-actions');
    const submit = el('button', 'wwc-card-submit', spec.submit);
    submit.type = 'submit';
    actions.appendChild(submit);

    const cancel = el('button', 'wwc-card-cancel', S.cancel || 'Cancel');
    cancel.type = 'button';
    cancel.addEventListener('click', function () { closeCard(card); });
    actions.appendChild(cancel);
    form.appendChild(actions);

    card.appendChild(form);

    function setFieldError(name, message) {
      const f = inputs[name];
      if (!f) { return; }
      if (message) {
        f.error.textContent = message;
        f.error.hidden = false;
        f.input.setAttribute('aria-invalid', 'true');
        f.input.setAttribute('aria-describedby', f.error.id);
      } else {
        f.error.textContent = '';
        f.error.hidden = true;
        f.input.removeAttribute('aria-invalid');
        f.input.removeAttribute('aria-describedby');
      }
    }

    function validate() {
      let firstBad = null;
      let firstMessage = '';
      spec.fields.forEach(function (f) {
        const value = inputs[f.name].input.value.trim();
        let message = '';
        if (f.required && !value) {
          message = f.type === 'email' ? (S.needEmail || 'Enter your email') : (S.needName || 'This is required');
        } else if (f.type === 'email' && value && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)) {
          // Deliberately loose. The server runs is_email(), which is the answer that matters; a
          // clever regex here only ever succeeds at rejecting somebody's perfectly valid address.
          message = S.needEmail || 'Enter a valid email address';
        }
        setFieldError(f.name, message);
        if (message && !firstBad) { firstBad = inputs[f.name].input; firstMessage = message; }
      });
      if (firstBad) {
        firstBad.focus();
        // The field's own error is announced through aria-describedby when focus lands on it, but
        // only once the screen reader gets there. Announcing as well means a visitor who is not
        // listening to focus changes still hears that something is wrong.
        announce(firstMessage);
        return false;
      }
      return true;
    }

    let sending = false;

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (sending) { return; }

      formError.hidden = true;
      formError.textContent = '';
      if (!validate()) { return; }

      const values = {};
      spec.fields.forEach(function (f) { values[f.name] = inputs[f.name].input.value.trim(); });
      values.n8nchat_hp = hp.value;

      sending = true;
      submit.disabled = true;
      cancel.disabled = true;
      const label = submit.textContent;
      submit.textContent = S.sending || 'Sending…';

      spec.send(values).then(function () {
        succeed(card, spec.done);
      }, function (failure) {
        sending = false;
        submit.disabled = false;
        cancel.disabled = false;
        submit.textContent = label;
        const message = (failure && failure.status === 429)
          ? (S.tooMany || S.sendFailed || 'Please try again later')
          : ((failure && failure.message) || S.sendFailed || 'That did not send');
        formError.textContent = message;
        formError.hidden = false;
        announce(message);
      });
    });

    return { node: card, focus: function () { (spec.fields.length ? inputs[spec.fields[0].name].input : submit).focus(); } };
  }

  /**
   * Replace a submitted form with its confirmation.
   *
   * Focus moves to the confirmation rather than staying on a submit button that no longer exists,
   * and it is announced as well: role="status" alone is unreliable when the element it lives in was
   * inserted in the same tick, and this is the one message in the whole interaction that the
   * visitor must not miss.
   */
  function succeed(card, message) {
    card.textContent = '';
    const done = el('p', 'wwc-card-done', message);
    done.setAttribute('role', 'status');
    done.tabIndex = -1;
    card.appendChild(done);
    done.focus({ preventScroll: true });
    announce(message);
    openCard = null;
    refresh();
  }

  function closeCard(card) {
    card.remove();
    if (openCard === card) { openCard = null; }
  }

  /* ---------------------------------------------------------------- transport */

  /**
   * POST to one of the plugin's own endpoints.
   *
   * `credentials: 'omit'` because nothing here needs a session and sending one would mean sending
   * the visitor's WordPress cookies to an endpoint that has no use for them. It also sidesteps the
   * REST API's cookie-authentication path entirely, which without a nonce treats the request as
   * anonymous anyway — and a nonce is exactly what cannot be used here, since the page it would be
   * printed into is served from a full-page cache for hours. See the note in inc/render.php.
   *
   * cfg.restUrl is whatever rest_url() produced, which on a site with plain permalinks is
   * `/?rest_route=/n8n-chatbot/v1` rather than a path. Appending `/lead` is correct either way: it
   * extends the path in one case and the query parameter's value in the other.
   */
  function post(path, payload) {
    return fetch(rest + path, {
      method: 'POST',
      credentials: 'omit',
      cache: 'no-store',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).then(function (res) {
      return res.json().catch(function () { return null; }).then(function (data) {
        if (res.ok) { return data || {}; }
        // WordPress puts a human, translated sentence in `message` on a WP_Error, and it is our own
        // copy, so showing it is better than inventing a generic failure that hides which of the
        // guards refused.
        return Promise.reject({ status: res.status, message: data && data.message ? String(data.message) : '' });
      });
    }, function () {
      // A rejected fetch is the network, not the server: no status to report.
      return Promise.reject({ status: 0, message: '' });
    });
  }

  function context() {
    return {
      page: location.href,
      elapsed: elapsedMs(),
      session: api.sessionId || ''
    };
  }

  /* ---------------------------------------------------------------- lead capture */

  function openLead(opts) {
    if (!canLead) { return; }
    const already = current();
    if (already) {
      // Already asking. Take the visitor to it rather than stacking a second copy underneath.
      already.scrollIntoView({ block: 'nearest' });
      const first = already.querySelector('.wwc-card-input');
      if (first && opts && opts.focus) { first.focus(); }
      return;
    }

    const built = buildCard({
      title: S.handoff || 'Talk to a person',
      intro: S.handoffIntro || '',
      submit: S.submit || 'Send',
      done: S.sentThanks || 'Thank you.',
      fields: [
        { name: 'name', label: S.name || 'Your name', type: 'text', required: true, autocomplete: 'name' },
        { name: 'email', label: S.email || 'Your email', type: 'email', required: true, autocomplete: 'email' },
        { name: 'message', label: S.message || 'How can we help?', type: 'textarea', required: false, hint: S.optional || '' }
      ],
      send: function (values) {
        const ctx = context();
        return post('/lead', {
          name: values.name,
          email: values.email,
          message: values.message,
          n8nchat_hp: values.n8nchat_hp,
          page: ctx.page,
          elapsed: ctx.elapsed,
          session: ctx.session
        }).then(function (data) {
          /*
           * Consent, at the one moment it is unambiguous.
           *
           * Under the "store only once the visitor sends a message" mode, boot.js keeps everything
           * in memory and writes nothing down until the widget says an unmistakable act has
           * happened. Volunteering a name and an email address to be contacted is at least as clear
           * an act as sending a chat message — arguably a great deal clearer — so it unlocks
           * storage on the same reasoning, and for the same reason it must not do so under any
           * other mode, where consent is somebody else's to grant.
           */
          if ((cfg.storage || {}).consentMode === 'send') { store.unlock(); }
          store.set(SENT_KEY, '1');
          return data;
        });
      }
    });

    place(built, opts);
  }

  /* ---------------------------------------------------------------- transcript */

  function openTranscript() {
    if (!canTranscript) { return; }
    const already = current();
    if (already) {
      already.scrollIntoView({ block: 'nearest' });
      return;
    }

    const built = buildCard({
      title: S.emailIt || 'Email me this conversation',
      intro: '',
      submit: S.submit || 'Send',
      done: S.transcriptOk || 'Sent.',
      fields: [
        { name: 'email', label: S.email || 'Your email', type: 'email', required: true, autocomplete: 'email' }
      ],
      send: function (values) {
        const ctx = context();
        return post('/transcript', {
          email: values.email,
          n8nchat_hp: values.n8nchat_hp,
          messages: snapshot(),
          page: ctx.page,
          elapsed: ctx.elapsed
        });
      }
    });

    place(built, { focus: true });
  }

  /**
   * The conversation, as the endpoint wants it.
   *
   * Error bubbles are dropped: they are the widget's own copy about a request that failed, not
   * something either party said, and a visitor emailing themselves a record of a conversation does
   * not want "The assistant took too long to reply" in it. The cut here mirrors the server's caps
   * rather than trusting them — the server truncates regardless, but there is no reason to put a
   * megabyte on the wire first and have it thrown away at the other end.
   */
  function snapshot() {
    const out = [];
    let used = 0;
    api.getMessages().forEach(function (m) {
      if (!m || m.error || typeof m.text !== 'string') { return; }
      const text = m.text.trim();
      if (!text || out.length >= 120 || used >= 20000) { return; }
      used += text.length;
      out.push({ role: m.role === 'user' ? 'user' : 'bot', text: text });
    });
    return out;
  }

  /* ---------------------------------------------------------------- placement */

  /**
   * Drop a card into the transcript and put the visitor where they need to be.
   *
   * Focus moves into the form only when the visitor asked for it. When the ASSISTANT offered the
   * card, the reply it belongs to is still being read, and pulling focus out of the transcript
   * mid-sentence is the same discourtesy as an auto-focused newsletter box — worse here, because a
   * screen-reader user loses their place in an answer they asked for. They get one short
   * announcement instead, and reach the form by continuing to read.
   */
  function place(built, opts) {
    // A sibling of the reply it belongs to, never a child of it. Inside the message row the card
    // would land either side of the copy/retry action bar depending on which of paintBody() and
    // actionBar() ran last, which is a rendering order nobody should have to reason about.
    const after = opts && opts.after;
    if (after && after.parentNode) {
      after.parentNode.insertBefore(built.node, after.nextSibling);
    } else {
      api.list.appendChild(built.node);
    }
    openCard = built.node;

    if (opts && opts.focus) {
      built.focus();
    } else {
      built.node.scrollIntoView({ block: 'nearest' });
      announce((S.handoff || 'Talk to a person') + '. ' + (S.handoffIntro || ''));
    }
  }

  /* ---------------------------------------------------------------- the marker */

  /**
   * Turn any handoff markers in a finished reply into the card.
   *
   * Called by widget.js from paintBody() for every non-streaming paint of a bot message, which is
   * both the end of a live reply and every message of a transcript replayed from storage — so the
   * marker behaves identically whether the reply just arrived or is being restored on the next
   * page.
   *
   * The anchor is replaced by its own label text rather than simply deleted, so a marker written
   * mid-sentence leaves the sentence intact. A paragraph that contained nothing else is then
   * dropped altogether, because the card immediately below carries the same words as its heading
   * and two identical calls to action stacked on top of each other read as a rendering bug.
   */
  function scan(row, msg) {
    refresh();
    if (!canLead || !row) { return; }

    const bubble = row.querySelector('.wwc-bubble');
    if (!bubble) { return; }

    const links = bubble.querySelectorAll('a[href="' + HANDOFF_MARKER + '"]');
    if (!links.length) { return; }

    Array.prototype.forEach.call(links, function (a) {
      const label = a.textContent || '';
      const parent = a.parentNode;
      a.replaceWith(document.createTextNode(label));
      // The paragraph held the marker and nothing else — an empty label leaves it blank, and the
      // usual "on a line of its own" case leaves it holding only the label the card is about to
      // repeat as its heading. Either way it is now a stray line above the card, so it goes.
      const spare = parent && parent !== bubble && parent.parentNode === bubble &&
        parent.textContent.trim() === label.trim();
      if (spare) { parent.remove(); }
    });

    if (current()) { return; }
    // Already handled once in this visit. The utility row still offers the form; what is suppressed
    // is the card raising itself again on every page view for as long as the reply is remembered.
    if (store.get(SENT_KEY) === '1') { return; }

    openLead({ focus: false, after: row });
  }

  refresh();

  return { scan: scan, openLead: openLead, openTranscript: openTranscript };
}
