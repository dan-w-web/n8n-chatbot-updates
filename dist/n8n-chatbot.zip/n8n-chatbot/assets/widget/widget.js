/*
 * n8n Chatbot Widget — the chat itself.
 *
 * Imported by assets/boot.js the first time a visitor interacts with the launcher, and never
 * before, so none of this is on the critical path of a page view where nobody opens the chat.
 *
 * It talks to the n8n Chat Trigger webhook directly from the browser. That is not an oversight —
 * the Chat Trigger's Allowed Origins is locked per bot to the customer's own domain, so proxying
 * through WordPress would fail CORS on every bot already in production.
 *
 * THE WIRE FORMAT, because it is not what anyone expects:
 *
 *   POST <webhook>  {"action":"sendMessage","sessionId":…,"chatInput":…,"metadata":{…}}
 *   Accept: text/plain
 *
 * n8n answers with Transfer-Encoding: chunked and Content-Type: application/json for BOTH the
 * streaming and the non-streaming case, so the header cannot tell you which you got. The body is
 * newline-delimited JSON:
 *
 *   {"type":"begin","metadata":{"nodeId":…,"nodeName":…,"runIndex":…}}
 *   {"type":"item","content":"Hel","metadata":{…}}
 *   {"type":"end","metadata":{…}}
 *
 * …or, from a "Last Node" workflow, a single {"output":"…"}. Reading line-by-line handles both,
 * which is why there is no setting for streaming: the widget works out what it was given. That
 * removes 1.x's worst support call, where a workflow in the wrong response mode rendered nothing
 * at all and looked exactly like a broken plugin.
 */

/*
 * The siblings are imported dynamically so the cache-busting query can be carried across.
 *
 * inc/render.php appends `?ver=<plugin version>` to this module's own URL. A static
 * `import './markdown.js'` resolves against that URL but DROPS the query, so the three modules
 * below would keep their bare, unversioned URLs — and the plugin's assets are served with
 * `Cache-Control: max-age=31536000`. The result is a widget.js one release ahead of the markdown
 * renderer it calls, for up to a year, which is a far nastier failure than simply being stale:
 * both files are individually valid and they disagree.
 *
 * `import.meta.url` keeps the query, so re-attaching it is the whole fix. Top-level await is fine
 * here — this module is only ever reached through boot.js's own `import()`, which is already async,
 * and it is well inside the Safari 15.4 floor the README documents.
 */
const ASSET_QUERY = (() => {
  const q = String(import.meta.url).split('?')[1];
  return q ? '?' + q : '';
})();

const [{ render }, { parseLine, createLineSplitter, looksLikeErrorPage, isToolResidue }, { createHandoff }] =
  await Promise.all([
    import('./markdown.js' + ASSET_QUERY),
    import('./stream.js' + ASSET_QUERY),
    import('./handoff.js' + ASSET_QUERY)
  ]);

/* ------------------------------------------------------------------ small helpers */

const uuid = () => (crypto.randomUUID
  ? crypto.randomUUID()
  // randomUUID needs Safari 15.4 and a secure context. The fallback is not cryptographically
  // interesting and does not need to be: this is a conversation id, not a credential.
  : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : ((r & 0x3) | 0x8)).toString(16);
  }));

const el = (tag, cls, text) => {
  const node = document.createElement(tag);
  if (cls) { node.className = cls; }
  if (text != null) { node.textContent = text; }
  return node;
};

const icon = (paths, size) =>
  '<svg viewBox="0 0 24 24" width="' + (size || 18) + '" height="' + (size || 18) + '" fill="none" ' +
  'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ' +
  'aria-hidden="true" focusable="false">' + paths + '</svg>';

const ICONS = {
  send:     icon('<path d="M4 12h15M13 6l6 6-6 6"/>'),
  stop:     icon('<rect x="6" y="6" width="12" height="12" rx="2"/>'),
  close:    icon('<path d="M6 6l12 12M18 6L6 18"/>'),
  expand:   icon('<path d="M4 14v6h6M20 10V4h-6M20 4l-7 7M4 20l7-7"/>'),
  collapse: icon('<path d="M10 4v6H4M14 20v-6h6M14 14l7 7M10 10L3 3"/>'),
  copy:     icon('<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>', 14),
  retry:    icon('<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>', 14),
  up:       icon('<path d="M7 10v11M18 10l-3.5-7A2 2 0 0 0 11 4v4H5a2 2 0 0 0-2 2.3l1.2 8A2 2 0 0 0 6 20h11"/>', 14),
  down:     icon('<path d="M17 14V3M6 14l3.5 7a2 2 0 0 0 3.5-1v-4h6a2 2 0 0 0 2-2.3l-1.2-8A2 2 0 0 0 18 4H7"/>', 14),
  check:    icon('<path d="M20 6L9 17l-5-5"/>', 14),
  down2:    icon('<path d="M12 5v14M19 12l-7 7-7-7"/>', 16),
  refresh:  icon('<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>', 16)
};

/* ------------------------------------------------------------------ mount */

export function mount(ctx) {
  const { cfg, K, store, shadow, dock, host, launcher, announce, setUnread } = ctx;
  const S = cfg.strings || {};
  const UI = cfg.ui || {};

  /* ---------------------------------------------------------------- state */

  /** @type {{id:string, role:'user'|'bot', text:string, error?:boolean, done?:boolean}[]} */
  let messages = [];
  let busy = false;
  let controller = null;
  let expanded = false;
  let isOpen = false;
  const dismissedPrompts = new Set();

  // `let`, not `const`, and that is load-bearing: newChat() mints a new id, and n8n keys its
  // conversation memory on it. While this was a const the only way to make the widget send the
  // new id was to reload the page — which is exactly what newChat() used to do.
  let sessionId = (() => {
    let id = store.get(K.session);
    if (!id) { id = uuid(); store.set(K.session, id); }
    return id;
  })();

  /* ---------------------------------------------------------------- chrome */

  const win = el('div', 'wwc-window');
  win.id = 'wwc-window';
  win.setAttribute('role', 'dialog');
  win.setAttribute('aria-label', S.title || S.dialog || 'Chat');
  win.hidden = true;

  // ---- header
  const header = el('header', 'wwc-header');
  const identity = el('div', 'wwc-identity');

  if (UI.avatar) {
    const img = el('img', 'wwc-avatar');
    img.src = UI.avatar;
    img.alt = '';
    img.setAttribute('aria-hidden', 'true');
    identity.appendChild(img);
  } else {
    // A monogram beats a generic robot glyph: it reads as "this company" rather than "some bot",
    // and it cannot 404.
    const mono = el('span', 'wwc-avatar wwc-mono', (S.title || '?').trim().charAt(0).toUpperCase());
    mono.setAttribute('aria-hidden', 'true');
    identity.appendChild(mono);
  }

  const names = el('div', 'wwc-names');
  const h2 = el('h2', 'wwc-title', S.title || '');
  names.appendChild(h2);
  if (S.subtitle) { names.appendChild(el('p', 'wwc-subtitle', S.subtitle)); }
  if (S.status) {
    const status = el('p', 'wwc-status');
    status.appendChild(el('span', 'wwc-dot'));
    status.appendChild(document.createTextNode(S.status));
    names.appendChild(status);
  }
  identity.appendChild(names);
  header.appendChild(identity);

  const actions = el('div', 'wwc-header-actions');

  const btnNew = iconButton('wwc-hbtn', ICONS.refresh, S.newChat || 'Start a new chat');
  btnNew.addEventListener('click', askNewChat);
  actions.appendChild(btnNew);

  const btnExpand = iconButton('wwc-hbtn wwc-only-wide', ICONS.expand, S.expand || 'Expand');
  btnExpand.addEventListener('click', toggleExpand);
  actions.appendChild(btnExpand);

  const btnClose = iconButton('wwc-hbtn', ICONS.close, S.close || 'Close chat');
  btnClose.addEventListener('click', close);
  actions.appendChild(btnClose);

  header.appendChild(actions);
  win.appendChild(header);

  // ---- transcript
  const scroller = el('div', 'wwc-scroll');
  const list = el('div', 'wwc-list');
  // role=log rather than role=feed: this is an append-only running record, which is exactly what
  // log describes, and aria-atomic=false stops the whole transcript being re-read on every
  // addition — the single most common way a chat widget becomes unusable with a screen reader.
  list.setAttribute('role', 'log');
  list.setAttribute('aria-live', 'polite');
  list.setAttribute('aria-atomic', 'false');
  list.setAttribute('aria-relevant', 'additions');
  scroller.appendChild(list);
  win.appendChild(scroller);

  const jump = el('button', 'wwc-jump');
  jump.type = 'button';
  jump.innerHTML = ICONS.down2;
  jump.setAttribute('aria-label', S.jumpToLatest || 'Jump to latest');
  jump.hidden = true;
  jump.addEventListener('click', () => { stick = true; scrollToEnd(true); jump.hidden = true; });
  win.appendChild(jump);

  // ---- chips (starter prompts, then follow-ups)
  const chips = el('div', 'wwc-chips');
  win.appendChild(chips);

  // ---- composer
  const footer = el('form', 'wwc-footer');
  footer.setAttribute('novalidate', '');
  const field = el('div', 'wwc-field');

  const input = el('textarea', 'wwc-input');
  input.rows = 1;
  input.placeholder = S.placeholder || '';
  input.setAttribute('aria-label', S.placeholder || S.dialog || 'Message');
  field.appendChild(input);

  // One control with two states, not two controls. While a reply is streaming the only thing a
  // visitor wants from this corner of the screen is "stop", and a stop button hidden in a menu is
  // the same as no stop button.
  const btnSend = el('button', 'wwc-send');
  btnSend.type = 'submit';
  btnSend.innerHTML = ICONS.send;
  btnSend.setAttribute('aria-label', S.send || 'Send');
  btnSend.disabled = true;
  field.appendChild(btnSend);

  footer.appendChild(field);
  win.appendChild(footer);

  /*
   * ---- the "start a new chat?" confirmation
   *
   * New chat is destructive and cannot be undone. It does not merely clear the screen: it mints a
   * new session id, which is what actually makes n8n forget the conversation, so the visitor loses
   * both the transcript in front of them and everything the assistant knew about their problem.
   * That sat behind a 28px unlabelled icon in the header, one click from the close button.
   *
   * Built here, once, rather than on demand. A dialog assembled per click has to re-bind its own
   * listeners every time, and the failure mode of getting that wrong is a button that silently
   * stops working on the second use.
   */
  const confirmBox = el('div', 'wwc-confirm');
  confirmBox.hidden = true;

  const confirmCard = el('div', 'wwc-confirm-card');
  // alertdialog rather than dialog: this interrupts to ask about something irreversible, which is
  // the distinction the role exists to draw.
  confirmCard.setAttribute('role', 'alertdialog');
  confirmCard.setAttribute('aria-modal', 'true');

  const confirmTitle = el('h3', 'wwc-confirm-title', S.newChatConfirm || 'Start a new chat?');
  confirmTitle.id = 'wwc-confirm-title';
  const confirmBody = el('p', 'wwc-confirm-body', S.newChatConfirmBody
    || 'This clears the conversation and the assistant will forget what you have discussed.');
  confirmBody.id = 'wwc-confirm-body';
  confirmCard.setAttribute('aria-labelledby', confirmTitle.id);
  confirmCard.setAttribute('aria-describedby', confirmBody.id);
  confirmCard.appendChild(confirmTitle);
  confirmCard.appendChild(confirmBody);

  const confirmActions = el('div', 'wwc-confirm-actions');
  const btnConfirmCancel = el('button', 'wwc-card-cancel', S.cancel || 'Cancel');
  btnConfirmCancel.type = 'button';
  const btnConfirmYes = el('button', 'wwc-card-submit', S.newChatConfirmYes || 'Start new chat');
  btnConfirmYes.type = 'button';
  // Cancel first in the DOM so it is what Shift+Tab reaches, and the destructive one last so it is
  // never what a stray Enter lands on first.
  confirmActions.appendChild(btnConfirmCancel);
  confirmActions.appendChild(btnConfirmYes);
  confirmCard.appendChild(confirmActions);
  confirmBox.appendChild(confirmCard);

  btnConfirmCancel.addEventListener('click', () => dismissNewChat(true));
  btnConfirmYes.addEventListener('click', () => newChat());
  // The scrim cancels, but only when the scrim itself was clicked — a drag that starts inside the
  // card and finishes outside it must not count as "no".
  confirmBox.addEventListener('click', (e) => { if (e.target === confirmBox) { dismissNewChat(true); } });

  win.appendChild(confirmBox);

  dock.insertBefore(win, dock.firstChild);

  function iconButton(cls, svg, label) {
    const b = el('button', cls);
    b.type = 'button';
    b.innerHTML = svg;
    b.setAttribute('aria-label', label);
    b.title = label;
    return b;
  }

  /* ---------------------------------------------------------------- scrolling
   *
   * Three rules, and the third is the one everybody gets wrong:
   *   1. follow the stream while the visitor is at the bottom;
   *   2. stop following the moment they scroll away, and offer a way back;
   *   3. when a NEW reply starts, anchor its top — do not drag the page down to the end of it.
   *
   * Rule 3 is counter-intuitive and is the difference between a reply you can read as it arrives
   * and one that scrolls its own first paragraph off the screen before you get to it.
   */

  let stick = true;
  const STICK_THRESHOLD = 100;

  scroller.addEventListener('scroll', () => {
    const distance = scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight;
    stick = distance < STICK_THRESHOLD;
    jump.hidden = stick;
  }, { passive: true });

  function scrollToEnd(smooth) {
    scroller.scrollTo({ top: scroller.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
  }

  function anchorTop(node) {
    // Put the new turn's first line just below the top of the viewport, so reading starts where
    // reading should start.
    const top = node.offsetTop - 12;
    scroller.scrollTo({ top, behavior: 'smooth' });
  }

  /* ---------------------------------------------------------------- rendering */

  function messageNode(msg, previous) {
    const row = el('div', 'wwc-row wwc-' + msg.role);
    row.dataset.id = msg.id;

    // Consecutive messages from the same sender group: one avatar, one name, tighter spacing.
    const grouped = previous && previous.role === msg.role;
    if (grouped) { row.classList.add('wwc-grouped'); }

    if (msg.role === 'bot') {
      const gutter = el('div', 'wwc-gutter');
      if (!grouped) {
        if (UI.avatar) {
          const img = el('img', 'wwc-msg-avatar');
          img.src = UI.avatar;
          img.alt = '';
          gutter.appendChild(img);
        } else {
          gutter.appendChild(el('span', 'wwc-msg-avatar wwc-mono', (S.title || '?').trim().charAt(0).toUpperCase()));
        }
      }
      gutter.setAttribute('aria-hidden', 'true');
      row.appendChild(gutter);
    }

    const body = el('div', 'wwc-body');

    if (!grouped && ((msg.role === 'bot' && S.botLabel) || (msg.role === 'user' && S.userLabel))) {
      body.appendChild(el('span', 'wwc-who', msg.role === 'bot' ? S.botLabel : S.userLabel));
    }

    const bubble = el('div', 'wwc-bubble');
    if (msg.error) { bubble.classList.add('wwc-error'); }
    body.appendChild(bubble);
    row.appendChild(body);
    return row;
  }

  function paintBody(row, msg, streaming) {
    const bubble = row.querySelector('.wwc-bubble');
    if (msg.role === 'user') {
      // A visitor's own message is never Markdown. Rendering it would let anyone type "**" at a
      // support bot and watch the page treat their input as markup — a small thing, but the
      // asymmetry is deliberate everywhere it appears.
      bubble.textContent = msg.text;
      return;
    }
    bubble.innerHTML = render(msg.text, streaming);
    if (!streaming) {
      decorateCode(bubble);
      // handoff.js reads a finished reply for the marker an assistant uses to raise the "talk to a
      // person" card, and keeps its own controls in step with the transcript. Called from here
      // rather than at the end of a turn so that a conversation REPLAYED from storage on the next
      // page is treated exactly like one that has only just arrived.
      handoff.scan(row, msg);
    }
  }

  /** A copy button on each finished code block. Never on one whose fence has not closed. */
  function decorateCode(bubble) {
    bubble.querySelectorAll('pre:not([data-open])').forEach((pre) => {
      if (pre.querySelector('.wwc-codecopy')) { return; }
      const b = iconButton('wwc-codecopy', ICONS.copy, S.copy || 'Copy');
      // A code block is copied as source and nothing else. Rich flavours would paste a styled <pre>
      // into an email, which is never what someone copying code wants.
      b.addEventListener('click', () => copyPlain(pre.textContent, b));
      pre.appendChild(b);
    });
  }

  /*
   * The per-reply action bar.
   *
   * Every button here has to be honest, and until 2.0.1 none of them were. Measured against the
   * live FSC site on 2026-08-19 rather than reasoned about:
   *
   *   - copy DID work — the clipboard really held the reply — but its entire confirmation was a
   *     14px icon shifting from grey to green for 1.6s, inside a bar measured at opacity 0.06 at
   *     the moment of the click because it was still fading in. Indistinguishable from a dead
   *     button, which is exactly how it was reported.
   *   - the thumbs sent nothing anywhere; no feedback route existed. Worse, rate() then set
   *     `disabled = true` on EVERY button in the bar, copy and retry included, dropping them to
   *     opacity .35 and dumping focus to nowhere. One rating killed the whole bar permanently on
   *     that message. That single line is why the report was "none of them do anything and they
   *     disappear" — after one thumb click, none of them did.
   *   - retry removed the reply and re-streamed, which is right, but it was offered on EVERY
   *     assistant message, and regenerate() truncates the transcript from that message onward. On
   *     an older reply it silently discarded the rest of the conversation, with no warning and no
   *     undo, from a 14px icon revealed on hover.
   */
  function actionBar(row, msg) {
    if (msg.role !== 'bot' || msg.error) { return; }
    if (row.querySelector('.wwc-actions')) { return; }

    const bar = el('div', 'wwc-actions');

    const copy = iconButton('wwc-abtn wwc-copy', ICONS.copy, S.copy || 'Copy');
    copy.addEventListener('click', () => copyReply(msg, row, copy));
    bar.appendChild(copy);

    // Retry only on the newest reply, which is what every chat product offering it does — and here
    // it is not a stylistic choice but the fix for the silent-truncation case described above.
    //
    // It cannot be decided once, here, because "newest" changes as the conversation grows: a bar
    // built when its reply was the last one would keep its retry button forever. syncRetry() below
    // is what keeps it on exactly one message.
    const retry = iconButton('wwc-abtn wwc-retry', ICONS.retry, S.retry || 'Try again');
    retry.addEventListener('click', () => regenerate(msg));
    bar.appendChild(retry);

    // Nothing is ever disabled here. Clicking the same thumb again clears the rating, so a
    // mis-click is recoverable, and copy and retry stay live for as long as the message does.
    const up = iconButton('wwc-abtn wwc-vote', ICONS.up, S.good || 'Good response');
    const down = iconButton('wwc-abtn wwc-vote', ICONS.down, S.bad || 'Needs work');
    up.addEventListener('click', () => rate(msg, 'up', bar));
    down.addEventListener('click', () => rate(msg, 'down', bar));
    bar.appendChild(up);
    bar.appendChild(down);

    paintRating(bar, msg.rating || '');
    row.querySelector('.wwc-body').appendChild(bar);
  }

  /**
   * Leave a retry button on the newest reply and nowhere else.
   *
   * Cheap, idempotent and called on every transcript change rather than tracked incrementally,
   * because the alternative is remembering to clear the previous one at four different call sites
   * and the failure mode of forgetting is a silently destructive button on an old message.
   */
  function syncRetry() {
    const bars = list.querySelectorAll('.wwc-actions');
    bars.forEach((bar, i) => {
      const btn = bar.querySelector('.wwc-retry');
      if (btn) { btn.hidden = i !== bars.length - 1; }
    });
  }

  /** Reflect a rating onto its bar. Idempotent, so repaint() and restore() can both call it. */
  function paintRating(bar, rating) {
    bar.classList.toggle('wwc-has-rating', '' !== rating);
    bar.querySelectorAll('.wwc-vote').forEach((b, i) => {
      const mine = 0 === i ? 'up' : 'down';
      b.classList.toggle('wwc-chosen', rating === mine);
      // aria-pressed, not disabled. A control that can still be changed is a toggle, and a screen
      // reader should hear "pressed" rather than "unavailable".
      b.setAttribute('aria-pressed', rating === mine ? 'true' : 'false');
    });
  }

  function rate(msg, verdict, bar) {
    const next = msg.rating === verdict ? '' : verdict;
    msg.rating = next;
    paintRating(bar, next);
    persist();
    announce(next ? (S.thanks || 'Thanks for the feedback') : (S.ratingCleared || 'Rating removed'));
    if (next) { sendFeedback(msg, next); }
  }

  /*
   * Send a rating to the site's own REST route.
   *
   * Fire and forget, and deliberately silent on failure. Someone who rates an answer has done us a
   * favour; showing them an error because the endpoint was rate-limited would be a worse experience
   * than the one they were trying to improve. The rating is already on screen and already stored
   * with the transcript, so nothing is lost from their side either way.
   *
   * It goes to WordPress rather than to n8n because n8n is not a given. The Chat Trigger webhook is
   * whatever the customer configured — essexpolfed and gmppolfed run standalone workflows with no
   * portal behind them — and posting a synthetic message to carry a rating would corrupt the very
   * transcript being rated. Every site has a REST API.
   */
  function sendFeedback(msg, verdict) {
    const rest = String(cfg.restUrl || '');
    if ('' === rest) { return; }
    try {
      fetch(rest + '/feedback', {
        method: 'POST',
        credentials: 'omit',
        cache: 'no-store',
        // The visitor may well close the tab straight after rating the last answer they read.
        keepalive: true,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rating: verdict,
          sessionId: sessionId,
          messageId: msg.id,
          page: location.href
        })
      }).catch(() => {});
    } catch (e) { /* no fetch, or blocked by a policy: a rating is never worth an exception */ }
  }

  /*
   * Copy a reply.
   *
   * Two flavours wherever the browser allows it: `text/html` so pasting into an email or a document
   * keeps the headings, the lists and — the one that actually matters — the link targets; and
   * `text/plain` carrying the original Markdown for anywhere that wants source. Writing plain text
   * only, as this did before, pasted "**To join the Fire Sector Confederation**" into a customer's
   * email with the asterisks intact. Verified on the live site.
   */
  function copyReply(msg, row, button) {
    const bubble = row.querySelector('.wwc-bubble');
    richCopy(msg.text, bubble ? bubble.innerHTML : '').then((okResult) => showCopied(button, okResult));
  }

  function copyPlain(text, button) {
    plainCopy(text).then((okResult) => showCopied(button, okResult));
  }

  function plainCopy(text) {
    return new Promise((resolve) => {
      // navigator.clipboard is undefined outside a secure context. The widget only ever talks to an
      // https webhook so that should not arise, but a staging site on plain http would otherwise
      // get a button that silently does nothing at all.
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => resolve(true), () => resolve(legacyCopy(text)));
        return;
      }
      resolve(legacyCopy(text));
    });
  }

  function richCopy(text, html) {
    // ClipboardItem wants Safari 13.1 / Chrome 66 and a secure context, and Firefox only shipped
    // text/html support in 127. Anything missing falls straight through to plain text rather than
    // failing, because a copy that loses formatting still copies.
    if (!html || !window.ClipboardItem || !navigator.clipboard || !navigator.clipboard.write) {
      return plainCopy(text);
    }
    try {
      const item = new ClipboardItem({
        'text/html': new Blob([html], { type: 'text/html' }),
        'text/plain': new Blob([text], { type: 'text/plain' })
      });
      return navigator.clipboard.write([item]).then(() => true, () => plainCopy(text));
    } catch (e) { return plainCopy(text); }
  }

  /*
   * Confirm the copy where the eye already is: the icon becomes a tick, and in the reply bar a
   * short "Copied" label appears next to it. The old version changed a 14px glyph from grey to
   * green and did nothing else — see the measurements in actionBar()'s comment for why that was
   * invisible in practice.
   */
  function showCopied(button, okResult) {
    const label = okResult ? (S.copied || 'Copied') : (S.copyFailed || 'Press Ctrl+C to copy');
    const bar = button.closest ? button.closest('.wwc-actions') : null;

    button.classList.toggle('wwc-ok', okResult);
    button.innerHTML = okResult ? ICONS.check : ICONS.copy;
    button.setAttribute('aria-label', label);
    button.title = label;
    announce(label);

    // Only the reply bar gets a text label; a code block's button has no room for one.
    if (bar) {
      let note = bar.querySelector('.wwc-copied');
      if (!note) { note = el('span', 'wwc-copied'); bar.appendChild(note); }
      note.textContent = label;
    }

    clearTimeout(button.wwcResetTimer);
    button.wwcResetTimer = setTimeout(() => {
      button.classList.remove('wwc-ok');
      button.innerHTML = ICONS.copy;
      button.setAttribute('aria-label', S.copy || 'Copy');
      button.title = S.copy || 'Copy';
      const note = bar && bar.querySelector('.wwc-copied');
      if (note) { note.remove(); }
    }, 1800);
  }

  function legacyCopy(text) {
    const ta = el('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.cssText = 'position:fixed;top:0;left:-9999px;opacity:0';
    shadow.appendChild(ta);
    let okResult = false;
    try {
      ta.select();
      if (ta.setSelectionRange) { ta.setSelectionRange(0, ta.value.length); }
      okResult = document.execCommand('copy');
    } catch (e) { okResult = false; }
    ta.remove();
    return okResult;
  }

  /* ---------------------------------------------------------------- transcript */

  function repaint() {
    list.textContent = '';
    messages.forEach((msg, i) => {
      const row = messageNode(msg, messages[i - 1]);
      list.appendChild(row);
      paintBody(row, msg, false);
      if (msg.done) { actionBar(row, msg); }
    });
    syncRetry();
    renderChips();
  }

  function appendMessage(msg) {
    messages.push(msg);
    const row = messageNode(msg, messages[messages.length - 2]);
    list.appendChild(row);
    paintBody(row, msg, false);
    return row;
  }

  function rowFor(msg) {
    return list.querySelector('[data-id="' + msg.id + '"]');
  }

  /* ---------------------------------------------------------------- chips */

  function renderChips() {
    chips.textContent = '';
    // Starter prompts belong to the empty state and nowhere else.
    //
    // This used to read `messages.length ? followUps : UI.starters`, where `followUps` was declared,
    // cleared in three places, and never once assigned — so the row was permanently empty from the
    // first message onward. Offering per-reply follow-ups needs the workflow to suggest them, which
    // is a change to what n8n emits and not something the widget can invent. Saying so plainly beats
    // leaving scaffolding that reads like a feature.
    const source = messages.length ? [] : (UI.starters || []);
    const usable = source.filter((t) => !dismissedPrompts.has(t));
    chips.hidden = usable.length === 0 || busy;
    usable.slice(0, 6).forEach((text) => {
      const chip = el('button', 'wwc-chip', text);
      chip.type = 'button';
      chip.addEventListener('click', () => {
        // A prompt the visitor has used, or visibly declined by asking something else, is not
        // offered again — repeating an ignored suggestion is the fastest way to make the whole row
        // read as noise.
        dismissedPrompts.add(text);
        submit(text);
      });
      chips.appendChild(chip);
    });
  }

  /* ---------------------------------------------------------------- persistence */

  const MAX_STORED = 60;

  function persist() {
    if (!store.allowed()) { return; }
    try {
      store.set(K.thread, JSON.stringify(messages.slice(-MAX_STORED).map((m) => ({
        i: m.id, r: m.role, t: m.text, e: m.error ? 1 : 0, g: m.rating || ''
      }))));
    } catch (e) { /* quota */ }
  }

  /**
   * Replay the transcript from the browser rather than asking n8n for it.
   *
   * 1.x restored history with a `loadPreviousSession` POST, which n8n bills as a workflow
   * execution — and, because the widget mounted on every page load whether or not anyone opened
   * it, that was one execution per page view from visitors who never touched the chat. It was the
   * plugin's largest running cost by a wide margin.
   *
   * n8n still holds the conversation memory against the same sessionId, so the next message has
   * full context either way. The only thing that changed is that we no longer pay a workflow run
   * to be told what this browser already knows — and the transcript now appears instantly instead
   * of after a spinner.
   */
  function restore() {
    const raw = store.get(K.thread);
    if (!raw) { return; }
    try {
      const saved = JSON.parse(raw);
      if (!Array.isArray(saved)) { return; }
      messages = saved
        .filter((m) => m && typeof m.t === 'string' && (m.r === 'user' || m.r === 'bot'))
        // `g` is the rating. A visitor who rated an answer and came back to the page should see
        // their own thumb still lit; re-sending it is not wanted, and paintRating() is what draws
        // it, so restoring the value is the whole job.
        .map((m) => ({
          id: m.i || uuid(),
          role: m.r,
          text: m.t,
          error: !!m.e,
          done: true,
          rating: ( 'up' === m.g || 'down' === m.g ) ? m.g : ''
        }));
    } catch (e) { messages = []; }
  }

  /* ---------------------------------------------------------------- greeting */

  function ensureGreeting() {
    if (messages.length || !S.greeting) { return; }
    // Not persisted and not part of the conversation: it is chrome that happens to look like a
    // message. Storing it would mean a "New chat" that replays a greeting the bot never said.
    const row = messageNode({ id: 'greeting', role: 'bot', text: S.greeting }, null);
    list.appendChild(row);
    paintBody(row, { role: 'bot', text: S.greeting }, false);
  }

  /* ---------------------------------------------------------------- sending */

  function submit(text) {
    text = String(text || '').trim();
    if (!text || busy) { return; }

    input.value = '';
    autogrow();
    btnSend.disabled = true;

    // Sending is an unambiguous act, which is the whole argument for treating it as consent to
    // remember the conversation under the "store once they send" mode.
    if ((cfg.storage || {}).consentMode === 'send') { store.unlock(); }

    appendMessage({ id: uuid(), role: 'user', text: text, done: true });
    renderChips();
    stick = true;
    scrollToEnd(true);
    announce(S.sent || 'Message sent');
    persist();

    stream(text);
  }

  function regenerate(msg) {
    // Find the visitor message that produced this reply, drop everything from the reply onward,
    // and ask again. Editing the transcript rather than appending keeps "try again" meaning what
    // it says instead of quietly turning into "ask the same thing twice".
    const index = messages.indexOf(msg);
    if (index < 1 || busy) { return; }
    const prompt = messages[index - 1];
    if (!prompt || prompt.role !== 'user') { return; }
    messages = messages.slice(0, index);
    repaint();
    persist();
    stream(prompt.text);
  }

  let confirmOpen = false;

  /**
   * Ask before throwing the conversation away — unless there is nothing to throw away.
   *
   * The greeting is painted straight into the transcript and never enters `messages` (see
   * ensureGreeting), so an empty `messages` genuinely means the visitor has said nothing and no
   * reply has arrived. Starting again then destroys nothing, and a confirmation would be pure
   * friction on the most common case of all: somebody pressing the button to find out what it does.
   */
  function askNewChat() {
    if (!messages.length && !busy) { newChat(); return; }
    confirmOpen = true;
    confirmBox.hidden = false;
    // Focus the safe option. The destructive one is a deliberate move away from it, not the thing
    // a reflexive Enter or Space lands on.
    btnConfirmCancel.focus({ preventScroll: true });
  }

  function dismissNewChat(refocus) {
    if (!confirmOpen) { return; }
    confirmOpen = false;
    confirmBox.hidden = true;
    // Back to the control that opened it, or focus is left on a node that has just been hidden and
    // the next Tab starts from the top of the page.
    if (refocus) { btnNew.focus({ preventScroll: true }); }
  }

  function newChat() {
    dismissNewChat(false);
    if (busy) { stop(); }
    messages = [];
    dismissedPrompts.clear();
    store.remove(K.thread);
    // A new session id is what actually resets the bot: n8n keys its memory on it, so reusing the
    // old one would give a "new" chat that still remembers everything.
    sessionId = uuid();
    store.set(K.session, sessionId);

    // Reset the widget, NOT the page. This used to end in location.reload(), which worked but took
    // the whole host site with it: a visitor part-way through a contact form lost everything they
    // had typed because they wanted a fresh chat. Verified on the FSC site — three filled Contact
    // Form 7 fields, empty after one click. Everything the reload was doing for us is above; the
    // only thing it was really buying was picking up the new session id, and `let` buys that now.
    repaint();
    ensureGreeting();
    scrollToEnd(false);
    announce(S.newChatDone || 'New chat started');
    input.focus({ preventScroll: true });
  }

  /* ---------------------------------------------------------------- streaming */

  const TIMEOUT_MS = 90000;
  const PAINT_MS = 40;

  function setBusy(state) {
    busy = state;
    btnSend.innerHTML = state ? ICONS.stop : ICONS.send;
    btnSend.setAttribute('aria-label', state ? (S.stop || 'Stop') : (S.send || 'Send'));
    btnSend.classList.toggle('wwc-stopping', state);
    btnSend.disabled = state ? false : input.value.trim() === '';
    renderChips();
  }

  function stop() {
    if (controller) { controller.abort(); }
  }

  async function stream(text) {
    setBusy(true);

    const typing = el('div', 'wwc-row wwc-bot wwc-typing');
    typing.innerHTML = '<div class="wwc-gutter"></div><div class="wwc-body"><div class="wwc-bubble">' +
      '<span class="wwc-dots"><i></i><i></i><i></i></span></div></div>';
    typing.setAttribute('aria-label', S.typing || 'Assistant is typing');
    list.appendChild(typing);
    if (stick) { scrollToEnd(true); }

    controller = new AbortController();
    const timer = setTimeout(() => controller.abort('timeout'), TIMEOUT_MS);
    // A reply that takes more than a few seconds is silent for a screen-reader user, who has no
    // animated dots to look at. One "still working" is reassurance; announcing every chunk is not.
    const slow = setTimeout(() => announce(S.typing || 'Assistant is typing'), 8000);

    /** Open segments, keyed by node and run, in the order n8n opened them. */
    const segments = new Map();
    let anchored = false;
    let painting = null;

    const schedulePaint = () => {
      // Batched into ~40ms frames rather than repainting per token. A markdown re-render on every
      // one of several hundred tokens is what makes a streaming widget feel like it is struggling,
      // and at this rate the text still appears continuous to the eye.
      if (painting) { return; }
      painting = setTimeout(() => {
        painting = null;
        segments.forEach((seg) => {
          if (!seg.row) { return; }
          paintBody(seg.row, seg.msg, true);
          if (!anchored) { anchored = true; anchorTop(seg.row); }
          else if (stick) { scrollToEnd(false); }
        });
      }, PAINT_MS);
    };

    const openSegment = (key) => {
      if (segments.has(key)) { return segments.get(key); }
      const msg = { id: uuid(), role: 'bot', text: '' };
      const row = appendMessage(msg);
      const seg = { msg: msg, row: row };
      segments.set(key, seg);
      return seg;
    };

    /**
     * A bubble appears when there is TEXT, and not a moment before.
     *
     * n8n sends `begin` as soon as the agent node starts, which against a RAG workflow is before
     * retrieval has even run — measured at 0.13s on the live FSC bot, with the first actual token
     * 14 seconds later. Opening the bubble there replaced the typing dots with an empty box and
     * left the visitor watching nothing for the whole wait, which reads as a hang rather than as
     * thinking.
     *
     * Creating the segment lazily also keeps `segments.size` meaning "we got a reply", which is
     * what the no-reply check below depends on: a turn where n8n opened a segment and then produced
     * nothing must be reported as a failure, not rendered as an empty message.
     */
    const write = (key, chunk) => {
      if (!chunk) { return; } // a 'begin' or 'end' envelope carries no text
      const seg = openSegment(key);
      typing.remove();
      seg.msg.text += chunk;
      schedulePaint();
    };

    let raw = '';
    let failed = null;

    try {
      const body = { action: 'sendMessage', sessionId: sessionId, chatInput: text };
      if (cfg.metadata && Object.keys(cfg.metadata).length) { body.metadata = cfg.metadata; }

      const res = await fetch(cfg.webhook, {
        method: 'POST',
        mode: 'cors',
        cache: 'no-store',
        // Accept: text/plain is what n8n's own client sends and what its streaming path checks for.
        headers: { 'Content-Type': 'application/json', Accept: 'text/plain' },
        body: JSON.stringify(body),
        signal: controller.signal
      });

      if (!res.ok || !res.body) { throw new Error('http ' + res.status); }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      const splitter = createLineSplitter();

      const consume = (line) => {
        const chunk = parseLine(line);
        if (!chunk) { return; }
        // 'begin' carries no text but does mean the model has started, so opening the bubble on it
        // replaces the typing dots the moment work starts rather than on the first token.
        write(chunk.key, chunk.content);
      };

      for (;;) {
        const { value, done } = await reader.read();
        if (done) { break; }
        // stream:true so a multi-byte character split across two reads is decoded once, whole.
        const text = decoder.decode(value, { stream: true });
        raw += text;
        splitter.push(text).forEach(consume);
      }
      splitter.flush().forEach(consume);

      // Order matters. parseLine() deliberately turns anything it cannot parse into literal text
      // rather than dropping it, which is right for an odd workflow response and catastrophic for a
      // proxy's HTML error page: the page becomes a "reply" and the visitor is shown
      // "<!DOCTYPE html>..." in a chat bubble. So the error-page test comes FIRST and outranks
      // whatever was built from it — an HTML document is never a legitimate answer.
      if (looksLikeErrorPage(raw)) {
        segments.forEach(function (seg) {
          if (seg.row) { seg.row.remove(); }
          messages = messages.filter(function (m) { return m !== seg.msg; });
        });
        segments.clear();
        failed = S.timeout || S.error;
      } else if (!segments.size) {
        failed = S.error;
      }
    } catch (e) {
      if (e && e.name === 'AbortError') {
        // A deliberate stop is not an error. Whatever arrived stays on screen.
        failed = controller.signal.reason === 'timeout' ? (S.timeout || S.error) : null;
      } else if (!navigator.onLine) {
        failed = S.offlineNet || S.error;
      } else {
        failed = S.error;
      }
    } finally {
      clearTimeout(timer);
      clearTimeout(slow);
      if (painting) { clearTimeout(painting); painting = null; }
      typing.remove();
      controller = null;
      setBusy(false);
    }

    // Final paint, unthrottled and with streaming off, so code fences close and copy buttons appear.
    let spoken = '';
    segments.forEach((seg) => {
      seg.msg.done = true;
      // isToolResidue() treats empty as residue, which also disposes of a segment that n8n opened
      // with `begin` and then never wrote to — an aborted turn, or a node that produced nothing.
      if (isToolResidue(seg.msg.text)) {
        // A segment whose entire body is a JSON blob is an agent's intermediate tool result that
        // leaked into the reply stream, not an answer. The test is deliberately narrow — it must
        // parse WHOLE, as an object or array — because hiding a real reply is far worse than
        // showing an ugly one, and a genuine answer that happens to contain JSON has prose around
        // it. 1.x scanned for the literal phrase "Calling X with input:" across 120 lines of
        // balanced-brace parsing; this is the same intent expressed structurally.
        seg.row.remove();
        messages = messages.filter((m) => m !== seg.msg);
        return;
      }
      paintBody(seg.row, seg.msg, false);
      actionBar(seg.row, seg.msg);
      syncRetry();
      spoken += seg.msg.text + ' ';
    });

    if (failed) {
      const msg = { id: uuid(), role: 'bot', text: failed, error: true, done: true };
      const row = appendMessage(msg);
      paintBody(row, msg, false);
      const again = el('button', 'wwc-chip wwc-retry-chip', S.retry || 'Try again');
      again.type = 'button';
      again.addEventListener('click', () => {
        messages = messages.filter((m) => m !== msg);
        repaint();
        stream(text);
      });
      row.querySelector('.wwc-body').appendChild(again);
      announce(failed);
    } else if (spoken.trim()) {
      // One announcement, at the end, of the whole reply. Announcing per chunk turns a streamed
      // answer into an unusable stutter for anyone listening to it.
      announce(spoken.trim().slice(0, 600));
    }

    if (!isOpen) { setUnread(1); playSound(); }
    persist();
    renderChips();
  }

  /* ---------------------------------------------------------------- sound */

  let audioCtx = null;
  function playSound() {
    if (!UI.sound) { return; }
    try {
      // Synthesised rather than shipped: two short sine tones cost nothing to download, cannot 404,
      // and avoid adding an audio file to a plugin whose whole point this release is weight.
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === 'suspended') { return; } // no gesture yet; a blocked beep is fine
      const now = audioCtx.currentTime;
      [880, 1174].forEach((freq, i) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.frequency.value = freq;
        osc.type = 'sine';
        gain.gain.setValueAtTime(0.0001, now + i * 0.09);
        gain.gain.exponentialRampToValueAtTime(0.06, now + i * 0.09 + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.09 + 0.12);
        osc.connect(gain).connect(audioCtx.destination);
        osc.start(now + i * 0.09);
        osc.stop(now + i * 0.09 + 0.14);
      });
    } catch (e) { /* audio is a nicety */ }
  }

  /* ---------------------------------------------------------------- composer */

  /**
   * Grow the composer to fit what has been typed, up to a limit.
   *
   * The zero check is not defensive padding — it is the whole reason this is a function. An element
   * inside a `hidden` subtree reports scrollHeight 0, and this runs from submit(), which can
   * complete after the window has been closed. Writing that 0 as an inline height collapsed the
   * composer to nothing, and because inline styles outlive the close, it stayed collapsed when the
   * visitor came back — a chat with no visible input box and no way to get it back short of a
   * reload. Clearing the property instead lets the stylesheet's min-height take over.
   */
  /*
   * How tall the composer may grow, taken from .wwc-input's own max-height rather than repeated
   * here. The number was written out twice before; a value that governs both the inline height and
   * the point at which scrolling comes back is exactly the sort of duplicate that drifts once and
   * then produces a field that either scrolls early or never scrolls at all.
   *
   * Cached after the first usable read, because the widget's stylesheet is a <link> inside the
   * shadow root and may not have applied when this first runs.
   */
  let composerMax = 0;
  function composerCeiling() {
    if (!composerMax) {
      const declared = parseFloat(getComputedStyle(input).maxHeight);
      if (declared > 0) { composerMax = declared; }
    }
    return composerMax || 140;
  }

  function autogrow() {
    input.style.height = 'auto';
    const wanted = input.scrollHeight;
    if (!wanted) {
      input.style.height = '';
      input.style.overflowY = '';
      return;
    }
    const ceiling = composerCeiling();
    input.style.height = Math.min(wanted, ceiling) + 'px';
    // The stylesheet keeps overflow hidden so a one-line field cannot show a scrollbar over a
    // hundredth of a pixel of rounding — see .wwc-input. It has to come back the moment the field
    // stops growing, or a long message becomes unreadable above the visible few lines.
    input.style.overflowY = wanted > ceiling ? 'auto' : 'hidden';
  }

  input.addEventListener('input', () => {
    autogrow();
    if (!busy) { btnSend.disabled = input.value.trim() === ''; }
  });

  input.addEventListener('keydown', (e) => {
    // Enter sends, Shift+Enter breaks the line. The inverse is a defensible choice in a full-page
    // assistant and the wrong one in a 400px support widget, where messages are one line.
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      submit(input.value);
    }
  });

  footer.addEventListener('submit', (e) => {
    e.preventDefault();
    if (busy) { stop(); return; }
    submit(input.value);
  });

  /* ---------------------------------------------------------------- open / close */

  const mql = window.matchMedia('(max-width: 600px)');

  /**
   * Is the window genuinely covering the screen?
   *
   * The viewport decides this, and nothing else. "Expanded" is a LARGER PANEL on a desktop, not a
   * takeover, and conflating the two produced a window that could not be un-expanded: expanding set
   * this true, which applied .wwc-fullscreen, which both suppressed the 760px rule and — via
   * `.wwc-fullscreen .wwc-only-wide { display: none }` — hid the very button that would collapse it
   * again. The only way out was to close the chat.
   */
  const isModal = () => mql.matches;

  /* ---------------------------------------------------------------- the phone
   *
   * Four behaviours that only exist on a touch device, and that a resized desktop browser will
   * cheerfully tell you are fine. Each is bound when the panel actually covers the screen and
   * unbound when it stops, so nothing here touches the host page while the chat is a corner panel.
   */

  /* ---- 1. the on-screen keyboard -------------------------------------------------------
   *
   * iOS does not resize the layout viewport when the keyboard opens — it shrinks the VISUAL
   * viewport and leaves the layout alone. So `height: 100dvh` on a `position: fixed` panel keeps
   * reporting the full screen, the panel keeps its height, and the keyboard is drawn over the
   * bottom of it. The composer — the only control that matters at that moment — ends up behind it.
   *
   * `interactiveWidget=resizes-content` in the viewport meta would make Android Chrome resize the
   * layout viewport instead, but it is the theme's meta to own and Safari does not honour it
   * anyway. Driving the panel from `visualViewport` works on both and asks nothing of the host.
   */
  let viewportBound = false;

  function onViewportChange() {
    const vv = window.visualViewport;
    if (!vv || !isOpen || !isModal()) { return; }
    // offsetTop is how far the visual viewport has been scrolled down inside the layout viewport,
    // which is what iOS does to bring a focused field above the keyboard. Following it keeps the
    // panel aligned with what the visitor can actually see.
    win.style.height = vv.height + 'px';
    win.style.top = vv.offsetTop + 'px';
    win.style.bottom = 'auto';
    if (stick) { scrollToEnd(false); }
  }

  function bindViewport() {
    const vv = window.visualViewport;
    if (!vv || viewportBound) { return; }
    viewportBound = true;
    vv.addEventListener('resize', onViewportChange);
    vv.addEventListener('scroll', onViewportChange);
    onViewportChange();
  }

  function unbindViewport() {
    const vv = window.visualViewport;
    if (!viewportBound) { return; }
    viewportBound = false;
    if (vv) {
      vv.removeEventListener('resize', onViewportChange);
      vv.removeEventListener('scroll', onViewportChange);
    }
    // Back to the stylesheet. Leaving inline values behind would pin a desktop panel to whatever
    // height a phone-sized window happened to have.
    win.style.height = '';
    win.style.top = '';
    win.style.bottom = '';
  }

  /* ---- 2. safe-area insets --------------------------------------------------------------
   *
   * `env(safe-area-inset-bottom)` resolves to zero unless the page's viewport meta carries
   * `viewport-fit=cover`. No WordPress theme sets it, so the composer's bottom padding — and the
   * comment above it promising the send button clears the home indicator — did nothing at all.
   *
   * The meta belongs to the theme, and a second one is undefined behaviour, so the existing tag is
   * amended rather than duplicated. It is also amended ONLY while the panel is full-screen and put
   * back on close: `viewport-fit=cover` lets the whole page lay out under the notch and the home
   * indicator, which is fine for a panel that is covering everything and rude to a theme that never
   * asked for it.
   */
  let viewportMeta = null;
  let viewportMetaWas = null;

  function setViewportFit(on) {
    if (viewportMeta === null) {
      viewportMeta = document.querySelector('meta[name="viewport"]') || false;
    }
    if (!viewportMeta) { return; }

    if (on) {
      if (viewportMetaWas !== null) { return; }
      viewportMetaWas = viewportMeta.getAttribute('content') || '';
      if (!/viewport-fit\s*=/.test(viewportMetaWas)) {
        viewportMeta.setAttribute('content', viewportMetaWas + ', viewport-fit=cover');
      }
      return;
    }

    if (viewportMetaWas === null) { return; }
    viewportMeta.setAttribute('content', viewportMetaWas);
    viewportMetaWas = null;
  }

  /* ---- 3. scroll lock -------------------------------------------------------------------
   *
   * `overscroll-behavior: contain` on the transcript stops a flick inside THAT scroller chaining
   * out to the page, and does nothing else. Dragging anywhere the transcript is not — the header,
   * the composer, the chip row — scrolled the site behind a panel that was covering it, which on a
   * phone reads as the page falling apart. iOS 15 ignores `overscroll-behavior` entirely, so even
   * the transcript was unprotected there.
   *
   * `position: fixed` on the body is the approach that actually works on iOS. It loses the scroll
   * position, hence recording and restoring it.
   */
  let scrollLocked = false;
  let lockedAt = 0;
  let bodyStyleWas = null;

  function lockScroll() {
    if (scrollLocked) { return; }
    scrollLocked = true;
    lockedAt = window.scrollY || window.pageYOffset || 0;
    const b = document.body;
    bodyStyleWas = { position: b.style.position, top: b.style.top, width: b.style.width, overflow: b.style.overflow };
    b.style.position = 'fixed';
    b.style.top = -lockedAt + 'px';
    b.style.width = '100%';
    b.style.overflow = 'hidden';
  }

  function unlockScroll() {
    if (!scrollLocked) { return; }
    scrollLocked = false;
    const b = document.body;
    if (bodyStyleWas) {
      b.style.position = bodyStyleWas.position;
      b.style.top = bodyStyleWas.top;
      b.style.width = bodyStyleWas.width;
      b.style.overflow = bodyStyleWas.overflow;
      bodyStyleWas = null;
    }
    window.scrollTo(0, lockedAt);
  }

  /* ---- 4. audio needs a gesture ---------------------------------------------------------
   *
   * An AudioContext created outside a user gesture is born `suspended`, and playSound() only ever
   * runs when a reply lands with the window closed — never during one. So it was created suspended,
   * the guard returned, nothing ever called resume(), and the notification sound was a setting that
   * did nothing on iOS for the life of the page.
   *
   * The launcher is the one thing a visitor always touches first, so the context is created and
   * resumed there. Bound to pointerdown rather than click because that is what fires inside the
   * gesture on iOS.
   */
  function unlockAudio() {
    if (!UI.sound) { return; }
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === 'suspended') { audioCtx.resume(); }
    } catch (e) { /* audio is a nicety */ }
  }
  if (ctx.launcher) { ctx.launcher.addEventListener('pointerdown', unlockAudio); }

  function toggleExpand() {
    expanded = !expanded;
    btnExpand.innerHTML = expanded ? ICONS.collapse : ICONS.expand;
    btnExpand.setAttribute('aria-label', expanded ? (S.collapse || 'Shrink') : (S.expand || 'Expand'));
    applyModality();
  }

  /**
   * A full-screen chat is modal and a corner panel is not, and the ARIA has to say so.
   *
   * Claiming aria-modal on the desktop panel would tell a screen reader the rest of the page is
   * inert while it plainly is not; omitting it on the phone, where the chat covers everything,
   * leaves the user free to tab into content they cannot see.
   */
  function applyModality() {
    const modal = isModal();
    win.classList.toggle('wwc-fullscreen', modal);
    // Expanded is only meaningful when the window is not already filling the screen. Kept in the
    // `expanded` flag rather than cleared, so shrinking the browser to phone width and back returns
    // the visitor to the size they chose.
    win.classList.toggle('wwc-expanded', expanded && !modal);
    if (modal) { win.setAttribute('aria-modal', 'true'); } else { win.removeAttribute('aria-modal'); }
    // The launcher floats above the window. Once the window covers the screen it is a second close
    // button sitting on top of the content, so it goes. Handled HERE rather than in open() because
    // the mode can change without the window opening or closing — rotating a phone, or dragging a
    // desktop window narrow — and doing it only on open left a launcher stranded over a full-screen
    // chat until the visitor closed and re-opened it.
    launcher.classList.toggle('wwc-hidden', modal && isOpen);

    // The phone behaviours live and die with "modal AND open", which is exactly what this function
    // already computes — so they hang off it rather than off open()/close(), and a rotation or a
    // window drag across the breakpoint binds and unbinds them correctly for free.
    if (modal && isOpen) {
      setViewportFit(true);
      lockScroll();
      bindViewport();
    } else {
      unbindViewport();
      unlockScroll();
      setViewportFit(false);
    }
  }
  // addListener is the pre-Safari-14 spelling. Without it mount() throws on an older engine and the
  // widget does not render at all — a hard failure where every other old-browser problem here is a
  // graceful one.
  if (mql.addEventListener) { mql.addEventListener('change', applyModality); }
  else if (mql.addListener) { mql.addListener(applyModality); }

  /**
   * Everything inside the window that the browser will actually move focus to.
   *
   * The selector alone is not enough, and the difference is what makes a focus trap either work or
   * strand somebody. `.wwc-jump` carries `hidden` whenever the transcript is already at the bottom,
   * and `.wwc-only-wide` is `display: none` in exactly the full-screen layout where the trap runs —
   * yet both match `button:not([disabled])`. If either happened to sort first or last, Tab would be
   * sent to an element the browser refuses to focus, and the visitor would be left cycling inside a
   * dialog with no way out. Today they sit in the middle by luck; a layout change is all it would
   * take. getClientRects() is empty for both `display: none` and `hidden`, and works everywhere the
   * widget runs.
   */
  function focusables() {
    // Scoped to the confirmation while it is up. Tabbing out of an alertdialog and back into the
    // transcript underneath it would leave the visitor typing at a chat they cannot see and have
    // not yet decided to keep.
    const scope = confirmOpen ? confirmCard : win;
    const all = scope.querySelectorAll('button:not([disabled]), textarea, input:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])');
    return Array.prototype.filter.call(all, (el) => el.getClientRects().length > 0);
  }

  function trap(e) {
    if (e.key !== 'Tab' || !isOpen) { return; }
    // Normally only full-screen traps, because a desktop corner panel is not modal and stealing Tab
    // from the page would be wrong. The confirmation IS modal at any size, so it traps either way.
    if (!isModal() && !confirmOpen) { return; }
    const focusable = focusables();
    if (!focusable.length) { return; }
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    // shadow roots have their own activeElement; document.activeElement would report the host.
    const active = shadow.activeElement;
    if (e.shiftKey && active === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && active === last) { e.preventDefault(); first.focus(); }
  }

  function onKeydown(e) {
    // Escape answers the innermost thing first. Without this it would close the whole window and
    // silently leave the question unanswered — and on the next open the dialog would still be up.
    if (e.key === 'Escape' && confirmOpen) {
      e.preventDefault();
      e.stopPropagation();
      dismissNewChat(true);
      return;
    }
    if (e.key === 'Escape' && isOpen) {
      // Only when focus is inside the widget, so Escape is never stolen from the host page's own
      // cookie banner, lightbox or modal.
      if (shadow.activeElement && win.contains(shadow.activeElement)) {
        e.preventDefault();
        close();
        return;
      }
    }
    trap(e);
  }
  document.addEventListener('keydown', onKeydown, true);

  function open(opts) {
    const restoring = !!(opts && opts.restoring);
    isOpen = true;
    win.hidden = false;
    applyModality();
    // Two frames: one to let the element exist with hidden removed, one for the transition to have
    // a starting state to animate from.
    requestAnimationFrame(() => requestAnimationFrame(() => win.classList.add('wwc-in')));
    store.set(K.open, '1');
    setUnread(0);
    scrollToEnd(false);
    // An auto-restore on page load is not a user action. Taking focus there would scroll every
    // navigation down to the widget and interrupt whatever a screen-reader user was doing.
    //
    // Otherwise focus SYNCHRONOUSLY. iOS raises the on-screen keyboard only for a focus() call made
    // inside the gesture's own task; a setTimeout, however short, is a different task and the
    // keyboard stays down — the visitor sees a focused-looking field and has to tap it again. The
    // 80ms delay this replaces was there to let the open transition start first, which preventScroll
    // already handles.
    if (!restoring) { input.focus({ preventScroll: true }); }
  }

  function close() {
    // An unanswered question does not survive the window being shut. Leaving it up would mean the
    // next open lands straight on a dialog about a conversation the visitor has since moved on from,
    // with the scrim covering everything else.
    dismissNewChat(false);
    isOpen = false;
    win.classList.remove('wwc-in');
    applyModality();
    store.set(K.open, '0');
    const finish = () => { win.hidden = true; };
    // Wait for the transition where there is one, and never hang if there is not (reduced motion
    // removes it entirely, and transitionend then never fires).
    let done = false;
    const once = () => { if (!done) { done = true; finish(); } };
    win.addEventListener('transitionend', once, { once: true });
    setTimeout(once, 300);
    ctx.onClosed();
  }

  /* ---------------------------------------------------------------- handoff */

  // Built here rather than beside the rest of the chrome because it inserts a row between the
  // transcript and the chips and therefore needs both to exist. paintBody() references it from
  // several hundred lines above, which is safe for exactly one reason: nothing paints until
  // repaint() runs three lines below this, by which point it is assigned.
  const handoff = createHandoff({
    cfg: cfg,
    strings: S,
    ui: UI,
    store: store,
    announce: announce,
    win: win,
    list: list,
    chips: chips,
    // A getter for the same reason getMessages is a function: newChat() REPLACES the session id,
    // so a value captured here would go stale and file a handoff against the conversation the
    // visitor just left.
    get sessionId() { return sessionId; },
    // A function rather than the array itself: regenerate() and restore() REPLACE `messages`, so a
    // captured reference would go stale and email somebody a conversation they had already left.
    getMessages: () => messages
  });

  /* ---------------------------------------------------------------- go */

  restore();
  repaint();
  ensureGreeting();
  applyModality();
  scrollToEnd(false);

  /**
   * Tear the instance down completely.
   *
   * Two of the listeners this function registers are not on elements it owns — one on `document`
   * for Escape and the focus trap, one on the `matchMedia` query for the mobile breakpoint — so
   * dropping the DOM does not dispose of them. On the front end that never mattered, because the
   * widget mounts exactly once per page and lives until the page does.
   *
   * It matters the moment anything re-mounts. The admin live preview does, on every keystroke: each
   * discarded instance would go on answering Escape, competing for Tab inside a dialog it no longer
   * renders, and re-running applyModality() against a detached window on every resize. The symptom
   * is not a crash — it is a preview that gets progressively stranger the longer somebody edits.
   */
  function destroy() {
    if (controller) { controller.abort(); }
    // Before anything else: these three altered the HOST page, and leaving any of them behind would
    // outlive the widget that did it — a permanently fixed body being the worst of the three.
    unbindViewport();
    unlockScroll();
    setViewportFit(false);
    document.removeEventListener('keydown', onKeydown, true);
    mql.removeEventListener('change', applyModality);
    win.remove();
    chips.remove();
    isOpen = false;
  }

  return { open: open, close: close, destroy: destroy };
}
