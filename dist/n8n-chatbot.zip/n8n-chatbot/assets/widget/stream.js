/*
 * Parsing the n8n Chat Trigger's response.
 *
 * Split out from widget.js so it can be tested without a browser. It is pure: strings in, small
 * plain objects out, no DOM and no network. That matters because this is where every surprising
 * thing about the wire format lives, and the surprises are only visible in a live conversation
 * against a real workflow — which is the worst possible place to discover them.
 *
 * WHAT COMES BACK, AND WHY IT IS NOT WHAT YOU EXPECT
 *
 * n8n answers a sendMessage POST with `Content-Type: application/json` and `Transfer-Encoding:
 * chunked` for BOTH response modes, so the headers cannot tell you which you got. There is no
 * negotiation and no flag to read. The body is one of:
 *
 *   Streaming (Chat Trigger typeVersion >= 1.2, responseMode "streaming"), newline-delimited:
 *     {"type":"begin","metadata":{"nodeId":"…","nodeName":"AI Agent","runIndex":0}}
 *     {"type":"item","content":"Hel","metadata":{…}}
 *     {"type":"item","content":"lo","metadata":{…}}
 *     {"type":"end","metadata":{…}}
 *
 *   Last Node, a single object:
 *     {"output":"Hello"}
 *
 * Reading line-by-line and letting the shapes fall out handles both, which is why the plugin has no
 * "enable streaming" setting: 1.x had one, hardcoded to true, and a workflow left in Last Node mode
 * therefore rendered precisely nothing while looking exactly like a broken plugin.
 *
 * Chunks are grouped by nodeId + runIndex. An agent that calls a tool part-way through an answer
 * emits a separate `begin` either side of the call, so grouping by that key is what puts the two
 * halves in two bubbles instead of splicing them into one run-on paragraph.
 */

/** The bubble a chunk belongs to. Chunks with no metadata all land in one default segment. */
export function segmentKey(meta) {
  const m = meta || {};
  const node = m.nodeId != null ? String(m.nodeId) : 'default';
  const run = m.runIndex != null ? String(m.runIndex) : '0';
  return node + '-' + run;
}

/**
 * One line of the response body.
 *
 * @returns {{key: string, content: string, kind: string}|null}
 *   null means "nothing to render" — a chunk that only opens or closes a segment, or a blank line.
 *
 * Deliberately forgiving, exactly as n8n's own client is: a line that does not parse is returned as
 * literal text rather than dropped. A workflow that emits something unexpected should show the
 * visitor something imperfect, never an empty bubble with no explanation.
 */
export function parseLine(line) {
  const s = String(line == null ? '' : line).trim();
  if (!s) { return null; }

  let obj;
  try { obj = JSON.parse(s); } catch (e) {
    return { key: 'raw-0', content: String(line), kind: 'text' };
  }

  // A bare JSON string or number on its own line is content, not a chunk envelope.
  if (obj === null || typeof obj !== 'object') {
    return { key: 'raw-0', content: String(line), kind: 'text' };
  }

  const key = segmentKey(obj.metadata);

  switch (obj.type) {
    case 'begin':
      // Opens a bubble with no text in it yet. Returned rather than ignored so the caller can drop
      // the typing indicator the instant the model starts, rather than on the first token.
      return { key: key, content: '', kind: 'begin' };
    case 'item':
      return typeof obj.content === 'string' ? { key: key, content: obj.content, kind: 'text' } : null;
    case 'end':
      return { key: key, content: '', kind: 'end' };
    case 'error':
      return { key: key, content: typeof obj.content === 'string' ? obj.content : '', kind: 'error' };
    default:
      break;
  }

  // Not a streaming chunk, so this is a Last Node workflow's single response object. These are the
  // fields n8n's own client reads, in this order.
  if (typeof obj.output === 'string') { return { key: key, content: obj.output, kind: 'text' }; }
  if (typeof obj.text === 'string') { return { key: key, content: obj.text, kind: 'text' }; }
  if (typeof obj.message === 'string') { return { key: key, content: obj.message, kind: 'text' }; }
  if (obj.message && typeof obj.message.text === 'string') { return { key: key, content: obj.message.text, kind: 'text' }; }
  if (typeof obj.content === 'string') { return { key: key, content: obj.content, kind: 'text' }; }

  // Something structured that means nothing to us. @n8n/chat JSON.stringifies it into the bubble,
  // which is the entire origin of "why is my chatbot showing raw JSON to customers". Rendering
  // nothing is the better failure: the caller reports that no reply arrived.
  return null;
}

/**
 * Split a byte stream into lines across reads.
 *
 * A chunk boundary lands wherever TCP decides, which is regularly in the middle of a JSON object
 * and occasionally in the middle of a multi-byte character. Holding the remainder until a newline
 * actually arrives is the whole job, and getting it wrong produces a parse failure roughly once
 * every long reply — often enough to be noticed and rarely enough to be blamed on the model.
 */
export function createLineSplitter() {
  let buffer = '';
  return {
    /** @returns {string[]} the complete lines this chunk finished. */
    push(chunk) {
      buffer += chunk == null ? '' : chunk;
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';
      return lines;
    },
    /** Whatever is left when the stream ends, which is the whole body in the Last Node case. */
    flush() {
      const rest = buffer;
      buffer = '';
      return rest ? [rest] : [];
    }
  };
}

/**
 * Did we get an HTML error page instead of a response body?
 *
 * A reverse proxy timing out in front of n8n — Cloudflare's 524 is the one people meet — answers
 * with a full HTML page, and often at status 200, so `res.ok` is true and the body parses as
 * nothing. Without this the visitor gets an empty bubble and no reason at all.
 */
export function looksLikeErrorPage(raw) {
  return /^\s*<(!doctype|html)/i.test(String(raw || ''));
}

/**
 * Is this segment nothing but a raw tool result that leaked into the reply stream?
 *
 * Deliberately narrow, and it has to be: hiding a real answer is far worse than showing an ugly
 * one. The whole trimmed body must parse as an object or array, so a genuine reply that merely
 * discusses or contains JSON — which always has prose around it — is never touched.
 *
 * 1.x did this by scanning for the literal phrase "Calling X with input:" with 120 lines of
 * balanced-brace parsing, and its own comments record what that cost: a real answer that happened
 * to contain the words "with input:" lost everything after them, permanently.
 */
export function isToolResidue(text) {
  const t = String(text == null ? '' : text).trim();
  if (!t) { return true; }
  const first = t.charAt(0);
  const last = t.charAt(t.length - 1);
  if (!((first === '{' && last === '}') || (first === '[' && last === ']'))) { return false; }
  try {
    const parsed = JSON.parse(t);
    return !!parsed && typeof parsed === 'object';
  } catch (e) { return false; }
}
