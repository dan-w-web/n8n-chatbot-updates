/*
 * A deliberately small Markdown renderer for chat replies.
 *
 * Why not a library: the plugin has no build step, and the two obvious choices are exactly what
 * made @n8n/chat's bundle double in nine months — markdown-it plus highlight.js account for most of
 * the difference between 266 KiB and 560 KiB gzipped. This covers what a chat reply actually
 * contains, in about six kilobytes.
 *
 * SECURITY MODEL — read this before changing anything below.
 *
 * The source is HTML-escaped ONCE, up front, before a single rule runs. Every rule after that
 * operates on already-escaped text and emits only tags this file wrote. That makes injection
 * impossible by construction rather than by sanitiser: there is no path by which a "<" from the
 * model's output reaches the DOM as a tag, because by the time any rule sees it, it is "&lt;".
 *
 * The inverse — parse first, sanitise the result — is the arrangement that produces a steady stream
 * of CVEs, because it requires the sanitiser to be right about every case forever. This requires
 * only that the escape happens first, which is one line and is tested.
 *
 * The one place a value reaches an attribute rather than a text node is a link's href, which is
 * therefore scheme-checked separately. See safeHref().
 */

/** The five characters that can change the shape of HTML. Order matters: & must go first. */
export function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * A URL safe to put in an href, or null.
 *
 * Allow-list, never deny-list: "javascript:" is the one everybody remembers and "data:",
 * "vbscript:" and "blob:" are the ones they forget. Anything not explicitly permitted is dropped
 * and the link renders as plain text, which is a far better failure than a live one.
 *
 * The input is already HTML-escaped, so a scheme cannot be smuggled through an entity — but leading
 * whitespace and control characters can still hide one from a naive prefix test, hence the strip.
 */
function safeHref(url) {
  const clean = String(url).replace(/[\x00-\x20]/g, '');
  if (/^(https?:|mailto:|tel:)/i.test(clean)) { return clean; }
  // Root-relative, fragment and same-directory links are ours by definition and are fine.
  if (/^(\/|#|\.\/)/.test(clean)) { return clean; }
  return null;
}

const LINK_REL = ' rel="noopener noreferrer nofollow"';

/**
 * The attributes for one link.
 *
 * A new tab is right for anywhere else on the web — the visitor keeps their conversation — and
 * wrong for a link that goes nowhere. `target="_blank"` on `#section` opens a second copy of the
 * page the visitor is already looking at and scrolls it to an anchor they cannot see, which is a
 * baffling thing to click. Same-page and same-site links stay in this tab; the transcript survives
 * a navigation anyway, which is the whole point of replaying it from the browser.
 */
function linkAttrs(href) {
  const external = /^(https?:|mailto:|tel:)/i.test(href);
  return (external ? ' target="_blank"' : '') + LINK_REL;
}

/*
 * Placeholder wrapper for an extracted code span.
 *
 * A NUL byte cannot survive into here — the widget strips control characters from the stream before
 * rendering, and escapeHtml() runs first regardless — so it can never collide with real content.
 * Built with fromCharCode rather than written literally so that this file stays copy-pasteable
 * through tooling that would otherwise silently eat the byte.
 */
const MARK = String.fromCharCode(0);

/**
 * Inline rules, applied to one already-escaped line.
 *
 * Code spans are extracted FIRST and stitched back afterwards, so that emphasis and link syntax
 * inside `like this` is shown literally rather than rendered — which is the whole reason somebody
 * used a code span.
 */
function inline(text) {
  const spans = [];
  let out = String(text).replace(/`([^`]+)`/g, (_, code) => {
    spans.push(code);
    return MARK + (spans.length - 1) + MARK;
  });

  // [label](url) before bare autolinks, so a labelled link is not eaten by the autolinker. The
  // optional trailing group swallows a Markdown title, which arrives here already escaped.
  out = out.replace(/\[([^\]]*)\]\(([^)\s]+)(?:\s+&quot;[^)]*&quot;)?\)/g, (whole, label, url) => {
    const href = safeHref(url);
    return href ? '<a href="' + href + '"' + linkAttrs(href) + '>' + (label || href) + '</a>' : whole;
  });

  // Bare URLs. The trailing-punctuation group stops a sentence's full stop or closing bracket being
  // swallowed into the href, which is the classic autolinker bug.
  out = out.replace(/(^|[\s(])(https?:\/\/[^\s<]+?)([.,;:!?)\]]*)(?=\s|$)/g, (whole, pre, url, tail) => {
    const href = safeHref(url);
    return href ? pre + '<a href="' + href + '"' + linkAttrs(href) + '>' + url + '</a>' + tail : whole;
  });

  out = out
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/__([^_]+)__/g, '<strong>$1</strong>')
    // Single * and _ only when not adjacent to a word character, so snake_case_names and 2*3*4
    // survive intact.
    .replace(/(^|[\s(])\*([^*\s][^*]*)\*(?=[\s.,;:!?)]|$)/g, '$1<em>$2</em>')
    .replace(/(^|[\s(])_([^_\s][^_]*)_(?=[\s.,;:!?)]|$)/g, '$1<em>$2</em>')
    .replace(/~~([^~]+)~~/g, '<del>$1</del>');

  return out.replace(new RegExp(MARK + '(\\d+)' + MARK, 'g'), (_, i) => '<code>' + spans[+i] + '</code>');
}

/** A table row's cells, trimmed. */
function cells(row) {
  return row.replace(/^\||\|$/g, '').split('|').map((c) => c.trim());
}

/** Undo escapeHtml(), for the one place a block's body is re-parsed rather than emitted. */
function unescapeHtml(s) {
  return String(s)
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, '&');
}

/**
 * Render Markdown to an HTML string.
 *
 * @param {string} src        The reply text, exactly as it arrived.
 * @param {boolean} streaming True while tokens are still arriving. An unterminated code fence is
 *        then treated as an open block and rendered as code, which is what stops a fenced snippet
 *        flashing as raw text with visible backticks on every token until it closes.
 * @returns {string} HTML containing only tags this function itself emitted.
 */
export function render(src, streaming) {
  const lines = escapeHtml(src == null ? '' : src).split('\n');
  const out = [];
  const paragraph = [];
  let i = 0;

  function flushParagraph() {
    if (!paragraph.length) { return; }
    out.push('<p>' + inline(paragraph.join('<br>')) + '</p>');
    paragraph.length = 0;
  }

  while (i < lines.length) {
    const line = lines[i];

    // ---- fenced code -------------------------------------------------------
    const fence = /^\s*```\s*([A-Za-z0-9_+#-]*)\s*$/.exec(line);
    if (fence) {
      flushParagraph();
      const lang = fence[1] ? ' class="wwc-lang-' + fence[1].toLowerCase() + '"' : '';
      const body = [];
      i++;
      while (i < lines.length && !/^\s*```\s*$/.test(lines[i])) { body.push(lines[i]); i++; }
      const closed = i < lines.length;
      i++; // consume the closing fence when there is one
      // data-open marks a block whose closing fence has not arrived. The widget uses it to hold back
      // the copy button until the snippet is actually complete — offering "copy" on half a command
      // is worse than offering nothing.
      const open = !closed && streaming ? ' data-open="1"' : '';
      out.push('<pre' + open + '><code' + lang + '>' + body.join('\n') + '</code></pre>');
      continue;
    }

    // ---- heading -----------------------------------------------------------
    const heading = /^(#{1,4})\s+(.*)$/.exec(line);
    if (heading) {
      flushParagraph();
      // Offset by two and capped at h6: a chat reply sits inside somebody else's page, and emitting
      // an h1 from a bot message wrecks that page's document outline for every screen-reader user.
      const level = Math.min(6, heading[1].length + 2);
      out.push('<h' + level + '>' + inline(heading[2]) + '</h' + level + '>');
      i++;
      continue;
    }

    // ---- horizontal rule ---------------------------------------------------
    if (/^\s*([-*_])\s*\1\s*\1[\s\-*_]*$/.test(line)) {
      flushParagraph();
      out.push('<hr>');
      i++;
      continue;
    }

    // ---- table -------------------------------------------------------------
    if (/^\s*\|.*\|\s*$/.test(line) && i + 1 < lines.length && /^\s*\|[\s:|-]+\|\s*$/.test(lines[i + 1])) {
      flushParagraph();
      const head = cells(line.trim());
      i += 2;
      const body = [];
      while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) { body.push(cells(lines[i].trim())); i++; }
      out.push(
        '<table><thead><tr>' + head.map((c) => '<th>' + inline(c) + '</th>').join('') +
        '</tr></thead><tbody>' +
        body.map((r) => '<tr>' + r.map((c) => '<td>' + inline(c) + '</td>').join('') + '</tr>').join('') +
        '</tbody></table>'
      );
      continue;
    }

    // ---- blockquote --------------------------------------------------------
    if (/^\s*&gt;\s?/.test(line)) {
      flushParagraph();
      const body = [];
      while (i < lines.length && /^\s*&gt;\s?/.test(lines[i])) {
        body.push(lines[i].replace(/^\s*&gt;\s?/, ''));
        i++;
      }
      // Recursing means re-escaping, so the collected body is unescaped exactly once first. Skipping
      // that would double-escape every quoted ampersand ("&amp;amp;") on each nesting level.
      out.push('<blockquote>' + render(unescapeHtml(body.join('\n')), streaming) + '</blockquote>');
      continue;
    }

    // ---- list --------------------------------------------------------------
    const bullet = /^(\s*)([-*+]|\d+[.)])\s+(.*)$/.exec(line);
    if (bullet) {
      flushParagraph();
      const ordered = /\d/.test(bullet[2]);
      const items = [];
      while (i < lines.length) {
        const m = /^(\s*)([-*+]|\d+[.)])\s+(.*)$/.exec(lines[i]);
        if (!m || /\d/.test(m[2]) !== ordered) { break; }
        let content = m[3];
        i++;
        // A wrapped continuation line belongs to the item above it, not to a new paragraph.
        while (i < lines.length && /^\s{2,}\S/.test(lines[i]) && !/^(\s*)([-*+]|\d+[.)])\s+/.test(lines[i])) {
          content += ' ' + lines[i].trim();
          i++;
        }
        items.push('<li>' + inline(content) + '</li>');
      }
      const tag = ordered ? 'ol' : 'ul';
      out.push('<' + tag + '>' + items.join('') + '</' + tag + '>');
      continue;
    }

    // ---- blank line / paragraph text ---------------------------------------
    if (/^\s*$/.test(line)) { flushParagraph(); } else { paragraph.push(line); }
    i++;
  }

  flushParagraph();
  return out.join('');
}

/**
 * Render into an element.
 *
 * innerHTML is safe here for exactly one reason — every character of untrusted input passed through
 * escapeHtml() before any rule ran, so the string being assigned contains no markup this file did
 * not itself produce. That is a property of render(), not of this function, and it is the property
 * tests/markdown.mjs exists to defend.
 */
export function renderInto(el, src, streaming) {
  el.innerHTML = render(src, streaming);
  return el;
}
