/*
 * n8n Chatbot Widget — boot stub.
 *
 * This is the only script the plugin puts on every page view, and it is deliberately small. It
 * paints the launcher, owns the visitor's client-side state, and imports the chat itself the first
 * time somebody actually interacts with it.
 *
 * That split is the whole point. 1.x imported ~355 KiB gzipped of third-party Vue from a CDN on
 * every page load whether or not the chat was ever opened — on most sites, on most page views,
 * paying the entire cost of a feature nobody used. Here the always-on half is a few kilobytes and
 * the chat is fetched on demand.
 *
 * Targets ES2019, which every browser that has fetch(), ReadableStream and AbortController also
 * parses natively — so there is still no build step, only a floor raised from the ES5 that 1.x
 * needed because it had to sit alongside somebody else's bundle.
 */
(function () {
  'use strict';

  var cfg = window.N8NCHAT;
  if (!cfg || !cfg.webhook) { return; }

  var HOST_ID = 'n8nchat-host';
  if (document.getElementById(HOST_ID)) { return; } // a second copy of the plugin; do nothing

  var S = cfg.strings || {};
  var UI = cfg.ui || {};

  // ---------------------------------------------------------------- state keys
  //
  // localStorage is scoped by the browser to ORIGIN, never to path. On a subdirectory multisite
  // every subsite shares one storage area while each has its own webhook and bot, so every key we
  // own carries the per-site scope the server derived from the blog id plus the tenant routing.
  var SCOPE = cfg.scope ? ':' + cfg.scope : '';
  var K = {
    session:  cfg.sessionKey || 'n8n-chat/sessionId', // owned by us now, but named as 1.x named it
    owner:    'n8n-chat/scope',                       // deliberately UNscoped — see claimSlot()
    thread:   'n8n-chat/thread' + SCOPE,
    open:     'n8n-chat/windowOpen' + SCOPE,
    seen:     'n8n-chat/lastSeen' + SCOPE,
    teaser:   'n8n-chat/teaserShown' + SCOPE,
    unread:   'n8n-chat/unread' + SCOPE,
    scheme:   'n8n-chat/scheme' + SCOPE
  };

  // ---------------------------------------------------------------- storage
  //
  // Two things make this less trivial than it looks. Merely TOUCHING localStorage throws a
  // SecurityError in Chrome when the visitor has blocked cookies for the site, so every access is
  // guarded. And consent mode can forbid persistence entirely, in which case the conversation still
  // works — it simply lives in this object for the life of the page and is never written down.
  var memory = {};
  var persistAllowed = false;
  // Set when the site has chosen not to remember conversations at all. Separate from
  // persistAllowed because consent can grant persistence later, whereas a zero TTL is a standing
  // instruction that consent has no bearing on.
  var persistForbidden = false;

  function consentGiven() {
    var mode = (cfg.storage && cfg.storage.consentMode) || 'off';
    if (mode === 'off') { return true; }
    if (mode === 'send') { return false; } // unlocked by the widget on the first message sent
    var key = (cfg.storage && cfg.storage.consentKey) || '';
    if (!key) { return false; }

    // A dotted path into window — "CookieYes.consent.functional" — or a cookie name.
    if (key.indexOf('.') !== -1 || window[key] !== undefined) {
      var node = window;
      var parts = key.split('.');
      for (var i = 0; i < parts.length; i++) {
        if (node == null || typeof node !== 'object') { return false; }
        node = node[parts[i]];
      }
      return !!node;
    }
    return document.cookie.split('; ').some(function (c) {
      var pair = c.split('=');
      return pair[0] === key && pair[1] !== '' && pair[1] !== '0' && pair[1] !== 'false';
    });
  }

  var store = {
    // Reading is not writing. Consent gates what we put IN the visitor's browser; refusing to read
    // what is already there would leave a conversation stored under an earlier consent stranded and,
    // worse, would blind claimSlot() to a session another subsite left behind — which is the exact
    // cross-tenant carry this file exists to prevent.
    get: function (key) {
      if (key in memory) { return memory[key]; }
      try { return localStorage.getItem(key); } catch (e) { return null; }
    },
    set: function (key, value) {
      memory[key] = String(value);
      if (!persistAllowed) { return; }
      try { localStorage.setItem(key, String(value)); } catch (e) { /* quota, or blocked */ }
    },
    remove: function (key) {
      delete memory[key];
      try { localStorage.removeItem(key); } catch (e) {}
    },
    /**
     * Grant persistence and flush whatever accumulated in memory beforehand.
     *
     * Called when consent arrives, and by the widget on the visitor's first sent message under the
     * "store once they send" mode — sending a message being an unambiguous act, which is the whole
     * argument for treating it as consent for keeping the conversation.
     */
    unlock: function () {
      if (persistAllowed || persistForbidden) { return; }
      persistAllowed = true;
      for (var key in memory) {
        if (Object.prototype.hasOwnProperty.call(memory, key)) {
          try { localStorage.setItem(key, memory[key]); } catch (e) {}
        }
      }
    },
    allowed: function () { return persistAllowed; }
  };

  // Order matters here and it is easy to get wrong. A zero TTL is a standing "write nothing", and it
  // has to be settled BEFORE claimSlot() below — which writes the scope-owner key. Deciding it later
  // (as this did, inside expire()) left exactly one key in localStorage on a site whose whole
  // setting was that nothing should be written to localStorage.
  var ttlMs = (cfg.storage && cfg.storage.ttl) || 0;
  persistForbidden = ttlMs <= 0;
  persistAllowed = !persistForbidden && consentGiven();

  // A consent banner is answered after the page has loaded, so one poll for the first half-minute
  // catches the visitor who accepts, without watching forever on the ones who never do.
  // Tracked so destroy() can dispose of them. Both outlive the host element, so removing the DOM is
  // not enough — see the note on destroy() at the foot of this file.
  var consentPoll = null;
  var teaserScroll = null;

  if (!persistAllowed && !persistForbidden && (cfg.storage && cfg.storage.consentMode) === 'cookie') {
    var polls = 0;
    var poll = consentPoll = setInterval(function () {
      if (consentGiven()) { store.unlock(); clearInterval(poll); }
      else if (++polls > 60) { clearInterval(poll); }
    }, 500);
  }

  /**
   * Claim the shared session slot for THIS site.
   *
   * The session id lives at a fixed key so that a conversation started under 1.x survives the
   * upgrade, which means it cannot be namespaced the way our own keys are. Instead the slot is
   * treated as claimable: whichever scope last owned it is recorded, and arriving under a different
   * one drops the conversation rather than resuming somebody else's.
   *
   * The unowned case is the upgrade case and is deliberately NOT a mismatch. A visitor mid-
   * conversation when this ships has a session but no recorded owner, and wiping it would throw
   * their transcript away — so on any topology where no other site could have written it
   * (single-site, subdomain or domain-mapped multisite) it is adopted. On subdirectory multisite
   * another subsite genuinely could have, so there it is refused and the visit starts clean.
   */
  (function claimSlot() {
    if (!cfg.scope) { return; }
    var owner = store.get(K.owner);
    if (owner === cfg.scope) { return; }
    if (owner !== null || cfg.scopeStrict) {
      store.remove(K.session);
      store.remove(K.thread);
      store.remove(K.open);
      store.remove(K.unread);
    }
    store.set(K.owner, cfg.scope);
  })();

  /**
   * Expire an idle conversation.
   *
   * Without this, a shared or kiosk machine shows the next visitor the previous one's transcript,
   * re-opened, because both the session id and the open flag persist indefinitely. The TTL is a
   * site setting; zero means "keep nothing beyond this page".
   */
  (function expire() {
    if (persistForbidden) {
      // "Remember a conversation for 0 hours" has to mean nothing is left behind, including
      // anything an earlier setting wrote. Turning retention off must PURGE, not merely stop
      // writing, or the setting reads as a privacy control while behaving as a partial one.
      [K.session, K.thread, K.open, K.unread, K.seen, K.teaser, K.owner].forEach(store.remove);
      return;
    }
    var now = Date.now();
    var last = parseInt(store.get(K.seen), 10);
    if (last && now - last > ttlMs) {
      store.remove(K.session);
      store.remove(K.thread);
      store.remove(K.open);
      store.remove(K.unread);
    }
    store.set(K.seen, now);
  })();

  // ---------------------------------------------------------------- host + shadow root
  //
  // A shadow root, because the alternative is what 1.x lived with: generic class names in the page's
  // own CSS scope, an id prefix on every selector to win specificity, a blanket of !important, and a
  // standing risk that any theme on any client site repaints the widget by accident. Inside a shadow
  // boundary none of that can happen in either direction. Custom properties still inherit through
  // it, which is why the theme is entirely custom properties.
  var host = document.createElement('div');
  host.id = HOST_ID;
  var scheme = store.get(K.scheme);
  if (scheme === 'light' || scheme === 'dark') { host.setAttribute('data-wwc-scheme', scheme); }
  else if (UI.scheme === 'light' || UI.scheme === 'dark') { host.setAttribute('data-wwc-scheme', UI.scheme); }

  var shadow = host.attachShadow({ mode: 'open' });
  document.body.appendChild(host);

  // Critical CSS for the launcher only — everything the visitor can see before the chat is opened.
  // The rest arrives with the widget. Kept inline rather than in widget.css so the launcher paints
  // on the first frame instead of after a network round trip.
  var critical = document.createElement('style');
  critical.textContent = [
    ':host{all:initial;font-family:var(--wwc-font);direction:' + (cfg.rtl ? 'rtl' : 'ltr') + '}',
    '.wwc-dock{position:fixed;bottom:var(--wwc-offset-y);z-index:var(--wwc-z);display:flex;flex-direction:column;align-items:flex-end;gap:10px;' +
      (UI.position === 'left' ? 'left:var(--wwc-offset-x);align-items:flex-start' : 'right:var(--wwc-offset-x)') + '}',
    '.wwc-launcher{display:inline-flex;align-items:center;gap:8px;min-height:var(--wwc-launcher-size);' +
      'padding:0 calc(var(--wwc-launcher-size)/2 - 12px);border:0;border-radius:999px;cursor:pointer;' +
      'background:var(--wwc-accent);color:var(--wwc-on-accent);font:600 14px/1 var(--wwc-font);' +
      'box-shadow:0 8px 22px rgba(var(--wwc-accent-rgb),.42);' +
      'transition:transform var(--wwc-motion-fast) var(--wwc-ease),box-shadow var(--wwc-motion-fast) var(--wwc-ease),background var(--wwc-motion-fast) var(--wwc-ease)}',
    '.wwc-launcher:hover{background:var(--wwc-accent-hover);transform:translateY(-2px);box-shadow:0 12px 28px rgba(var(--wwc-accent-rgb),.5)}',
    '.wwc-launcher:focus-visible{outline:3px solid var(--wwc-accent);outline-offset:3px}',
    '.wwc-launcher:active{transform:translateY(0)}',
    // No label: a perfect circle. With one: a pill. Both keep the icon box square so the touch
    // target never drops below the 24px WCAG 2.2 minimum, or 44px in practice.
    '.wwc-launcher[data-bare]{width:var(--wwc-launcher-size);padding:0;justify-content:center}',
    '.wwc-ico{width:24px;height:24px;flex:0 0 24px;display:block;object-fit:contain;border-radius:6px}',
    '.wwc-badge{position:absolute;top:-2px;' + (UI.position === 'left' ? 'left:-2px' : 'right:-2px') + ';' +
      'min-width:20px;height:20px;padding:0 6px;border-radius:999px;background:#e5484d;color:#fff;' +
      'font:700 11px/20px var(--wwc-font);text-align:center;box-shadow:0 0 0 2px var(--wwc-bg)}',
    '.wwc-launcher-wrap{position:relative;display:inline-flex}',
    '.wwc-teaser{position:relative;max-width:260px;padding:12px 34px 12px 14px;border-radius:14px;' +
      'background:var(--wwc-bg);color:var(--wwc-ink);border:1px solid var(--wwc-line);' +
      'box-shadow:var(--wwc-shadow-soft);font:400 14px/1.5 var(--wwc-font);text-align:start;' +
      'animation:wwc-rise var(--wwc-motion-base) var(--wwc-ease) both;cursor:pointer}',
    '.wwc-teaser-x{position:absolute;top:4px;' + (cfg.rtl ? 'left:4px' : 'right:4px') + ';width:26px;height:26px;' +
      'display:grid;place-items:center;border:0;background:none;color:var(--wwc-muted);cursor:pointer;border-radius:8px;font:400 16px/1 var(--wwc-font)}',
    '.wwc-teaser-x:hover{background:var(--wwc-sunken);color:var(--wwc-ink)}',
    '@keyframes wwc-rise{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}',
    '.wwc-sr{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap;border:0}',
    // Motion is decoration here; the launcher and teaser are perfectly usable without it, and for a
    // visitor with a vestibular disorder the transform is not a nicety but a symptom trigger.
    '@media (prefers-reduced-motion: reduce){.wwc-launcher,.wwc-teaser{transition:none;animation:none}',
    '.wwc-launcher:hover{transform:none}}'
  ].join('');
  shadow.appendChild(critical);

  var dock = document.createElement('div');
  dock.className = 'wwc-dock';
  shadow.appendChild(dock);

  // A single polite live region for announcements the widget makes. Created here rather than in the
  // widget so that a message arriving before the chat is opened can still be announced.
  var live = document.createElement('div');
  live.className = 'wwc-sr';
  live.setAttribute('role', 'status');
  live.setAttribute('aria-live', 'polite');
  shadow.appendChild(live);

  function announce(text) {
    live.textContent = '';
    setTimeout(function () { live.textContent = text; }, 30);
  }

  // ---------------------------------------------------------------- launcher

  var wrap = document.createElement('div');
  wrap.className = 'wwc-launcher-wrap';

  var launcher = document.createElement('button');
  launcher.type = 'button';
  launcher.className = 'wwc-launcher';
  launcher.setAttribute('aria-haspopup', 'dialog');
  launcher.setAttribute('aria-expanded', 'false');
  launcher.setAttribute('aria-controls', 'wwc-window');
  /**
   * Compose the launcher's accessible name.
   *
   * WCAG 2.5.3 Label in Name: when a control carries visible text, its accessible name must
   * CONTAIN that text. With launcher_label set to "Ask us" the button read "Open chat", so a
   * voice-control user saying the words they could see — "click Ask us" — activated nothing.
   * The visible label goes first, because voice control matches from the start of the name.
   */
  function launcherName(isOpen, count) {
    var state = isOpen ? (S.close || 'Close chat') : (S.open || 'Open chat');
    var name  = UI.launcherLabel ? UI.launcherLabel + ' — ' + state : state;
    if (count && !isOpen) { name += ' — ' + count; }
    return name;
  }

  launcher.setAttribute('aria-label', launcherName(false, 0));

  if (UI.launcherIcon) {
    var img = document.createElement('img');
    img.className = 'wwc-ico';
    img.src = UI.launcherIcon;
    img.alt = '';
    img.setAttribute('aria-hidden', 'true');
    launcher.appendChild(img);
  } else {
    launcher.insertAdjacentHTML('beforeend',
      '<svg class="wwc-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' +
      '<path d="M21 11.5a8.4 8.4 0 0 1-9 8.4 9.9 9.9 0 0 1-3.8-.7L3 21l1.9-4.6A8.3 8.3 0 0 1 3.6 11.5 8.4 8.4 0 0 1 12 3.1a8.4 8.4 0 0 1 9 8.4z"/></svg>');
  }

  if (UI.launcherLabel) {
    var label = document.createElement('span');
    label.textContent = UI.launcherLabel;
    launcher.appendChild(label);
  } else {
    launcher.setAttribute('data-bare', '');
  }

  wrap.appendChild(launcher);
  dock.appendChild(wrap);

  // ---------------------------------------------------------------- unread badge

  var badge = null;
  var unread = 0;
  // Declared here, not with the open/close block below, because syncLauncher() reads it and
  // relying on hoisting to leave it `undefined` on the first call is a trap waiting to be sprung.
  var opened = false;

  /**
   * The launcher's accessible state, in ONE place.
   *
   * It has two independent inputs — whether the window is open, and how many replies are waiting —
   * and they were previously written by two different functions. setUnread(0) claimed the label for
   * "Open chat", and the widget calls it on open, straight after boot.js had just set the label to
   * "Close chat". The button then announced itself as opening a chat that was already open, which is
   * invisible to anyone looking at the screen and the only information a screen-reader user has.
   */
  function syncLauncher() {
    launcher.setAttribute('aria-expanded', opened ? 'true' : 'false');
    // The count belongs in the accessible name rather than only in the badge, which is decorative:
    // a visual badge conveys nothing to a screen reader, and an aria-live announcement for it would
    // interrupt whatever the visitor is reading. launcherName() also carries the visible label,
    // without which the name would not contain it (WCAG 2.5.3).
    launcher.setAttribute('aria-label', launcherName(opened, unread));
  }

  function setUnread(count) {
    unread = Math.max(0, count | 0);
    store.set(K.unread, unread);
    if (!unread) {
      if (badge) { badge.remove(); badge = null; }
    } else {
      if (!badge) {
        badge = document.createElement('span');
        badge.className = 'wwc-badge';
        badge.setAttribute('aria-hidden', 'true'); // the count is in the launcher's own name instead
        wrap.appendChild(badge);
      }
      badge.textContent = unread > 9 ? '9+' : String(unread);
    }
    syncLauncher();
  }

  setUnread(parseInt(store.get(K.unread), 10) || 0);

  // ---------------------------------------------------------------- teaser
  //
  // Never on load. A nudge the instant a page appears is the single most resented pattern in this
  // category; one that waits until a visitor has actually settled on a page is the one that works.
  // Fires on whichever comes first, dwell time or scroll depth, and is capped per session.

  var teaser = null;
  function teaserShownCount() { return parseInt(store.get(K.teaser), 10) || 0; }

  function showTeaser() {
    var t = cfg.teaser || {};
    if (teaser || opened || !t.enabled) { return; }
    if (teaserShownCount() >= (t.max || 1)) { return; }

    teaser = document.createElement('div');
    teaser.className = 'wwc-teaser';
    teaser.setAttribute('role', 'button');
    teaser.setAttribute('tabindex', '0');

    var text = document.createElement('span');
    text.textContent = t.text || '';
    teaser.appendChild(text);

    var x = document.createElement('button');
    x.type = 'button';
    x.className = 'wwc-teaser-x';
    x.setAttribute('aria-label', S.close || 'Close');
    x.textContent = '×';
    x.addEventListener('click', function (e) {
      e.stopPropagation();
      dismissTeaser();
      // A dismissal is an answer. Burn the whole allowance rather than asking again this visit.
      store.set(K.teaser, (cfg.teaser && cfg.teaser.max) || 1);
    });
    teaser.appendChild(x);

    teaser.addEventListener('click', function () { open(false); });
    teaser.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(false); }
    });

    dock.insertBefore(teaser, wrap);
    store.set(K.teaser, teaserShownCount() + 1);
    announce(t.text || '');
  }

  function dismissTeaser() {
    if (!teaser) { return; }
    teaser.remove();
    teaser = null;
  }

  (function armTeaser() {
    var t = cfg.teaser || {};
    if (!t.enabled || teaserShownCount() >= (t.max || 1)) { return; }

    var fired = false;
    function fire() {
      if (fired) { return; }
      fired = true;
      window.removeEventListener('scroll', onScroll);
      showTeaser();
    }

    var timer = setTimeout(fire, Math.max(0, (t.delay || 45) * 1000));

    function onScroll() {
      var doc = document.documentElement;
      var max = doc.scrollHeight - window.innerHeight;
      if (max <= 0) { return; }
      var pct = (window.scrollY / max) * 100;
      if (pct >= (t.scroll || 0) && (t.scroll || 0) > 0) { clearTimeout(timer); fire(); }
    }
    teaserScroll = onScroll;
    window.addEventListener('scroll', onScroll, { passive: true });
  })();

  // ---------------------------------------------------------------- open / close

  var loading = null;
  var widget = null;

  /** Everything the widget module needs from the stub, handed over explicitly. */
  function context() {
    return {
      cfg: cfg, K: K, store: store, shadow: shadow, dock: dock, host: host,
      launcher: launcher, announce: announce, setUnread: setUnread,
      onClosed: function () {
        opened = false;
        syncLauncher();
        launcher.focus();
      }
    };
  }

  /**
   * Fetch the widget once, and hand back the same promise on every later call so that an impatient
   * double-click cannot start two downloads or mount two chats.
   */
  function load() {
    if (loading) { return loading; }
    // The stylesheet is fetched alongside the module rather than after it, so the two arrive
    // together and the window never paints unstyled.
    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = cfg.styleUrl;
    shadow.appendChild(link);

    loading = import(cfg.widgetUrl).then(function (mod) {
      widget = mod.mount(context());
      if (cfg.customCss) {
        // Inside the shadow root, which is the only place it can select anything the widget renders.
        var extra = document.createElement('style');
        extra.textContent = cfg.customCss;
        shadow.appendChild(extra);
      }
      return widget;
    }).catch(function (e) {
      // A failed import must not leave a dead launcher: allow a retry rather than latching.
      loading = null;
      if (window.console && console.error) { console.error('[n8n-chatbot] widget failed to load', e); }
      throw e;
    });
    return loading;
  }

  /**
   * @param {boolean} restoring True when the window is being re-opened because the visitor left it
   *        open on the previous page, rather than because they just clicked. The distinction
   *        matters entirely for focus: moving focus into the composer is right on a click and
   *        actively hostile on a page load, where it would scroll every navigation down to the
   *        widget and interrupt whatever a screen-reader user was doing.
   */
  function open(restoring) {
    dismissTeaser();
    setUnread(0);
    opened = true;
    syncLauncher();

    // SYNCHRONOUS when the widget is already here, and that is not a micro-optimisation.
    //
    // iOS raises the on-screen keyboard only for a focus() call made inside the gesture's own task.
    // A promise callback — even an already-resolved one — is a later microtask, by which point the
    // gesture is over and the keyboard stays down: the visitor gets a focused-looking composer and
    // has to tap it a second time. Going straight there when the module is loaded keeps the whole
    // path inside the tap.
    //
    // The very first open cannot be synchronous, because the module is fetched on demand. That is
    // what the pointerdown warm-up below is for: by the time `click` fires, the import has usually
    // finished and this branch is taken.
    if (widget) { widget.open({ restoring: !!restoring }); return; }

    load().then(function (w) { w.open({ restoring: !!restoring }); }).catch(function () {
      opened = false;
      syncLauncher();
    });
  }

  function toggle() {
    if (opened && widget) { widget.close(); return; }
    open(false);
  }

  launcher.addEventListener('click', toggle);

  // Start fetching the widget the moment a finger goes down, so the click that follows a few tens of
  // milliseconds later finds it already loaded and can open synchronously. Idempotent — load()
  // returns the same promise however many times it is called — and it costs nothing on a visitor who
  // presses the launcher and thinks better of it, because they were about to open the chat anyway.
  launcher.addEventListener('pointerdown', function () { load().catch(function () {}); });

  // Warm the module during idle time once a teaser is on screen: that visitor is being invited to
  // click, and the click should not then wait on a download. Never speculative otherwise.
  if ((cfg.teaser || {}).enabled && 'requestIdleCallback' in window) {
    var warmed = false;
    var warm = function () {
      if (warmed || !teaser) { return; }
      warmed = true;
      load().catch(function () {});
    };
    setTimeout(function () { requestIdleCallback(warm); }, ((cfg.teaser || {}).delay || 45) * 1000 + 500);
  }

  // Re-open on the next page if the visitor left it open, so a conversation follows them around the
  // site. Only ever auto-OPENS — a closed or unset state is left exactly as it is.
  if (store.get(K.open) === '1') { open(true); }

  /**
   * Dispose of everything this script registered.
   *
   * Removing the host element is NOT enough, and that is the whole reason this exists. The teaser's
   * scroll listener is on `window`, the consent poll is an interval, and the widget module keeps a
   * `document` keydown handler for Escape and the focus trap. All three survive the DOM they relate
   * to, so a page that re-runs boot.js — the admin live preview does, on every edit — accumulates a
   * set of them, each still answering keystrokes and scroll events on behalf of a widget that is no
   * longer on the page.
   *
   * Nothing on the front end needs this: the widget mounts once and lives as long as the document.
   * It exists for anything that re-mounts, and it is exposed rather than private so that such a
   * caller has a supported way to do it instead of guessing.
   */
  function destroy() {
    if (widget && widget.destroy) { try { widget.destroy(); } catch (e) {} }
    if (consentPoll) { clearInterval(consentPoll); consentPoll = null; }
    if (teaserScroll) { window.removeEventListener('scroll', teaserScroll); teaserScroll = null; }
    dismissTeaser();
    host.remove();
    widget = null;
    loading = null;
    opened = false;
    if (window.n8nChatbot && window.n8nChatbot.destroy === destroy) { delete window.n8nChatbot; }
  }

  // A last-resort handle for support and for site-specific integrations. Not a stable API.
  window.n8nChatbot = {
    open: function () { open(false); },
    close: function () { if (widget) { widget.close(); } },
    toggle: toggle,
    destroy: destroy
  };
})();
