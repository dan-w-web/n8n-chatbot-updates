/*
 * The chatbot settings screen: tabs, style presets, the contrast readout, and the live preview.
 *
 * No build step, no npm, no framework — the same rule the rest of this plugin lives by. It is
 * served exactly as it is written and targets ES2019, which is the floor the widget already sets.
 *
 * It knows the names of NO settings. Every control it touches is found through the
 * `data-n8nchat-field` attribute inc/admin/page.php puts on each one, and the two places the screen
 * must single a field out — the colour picker that gets the contrast readout, and the select the
 * preset cards stand in for — are named by the schema and handed over in window.N8NCHAT_ADMIN. Add
 * a setting to inc/schema.php and this file needs no edit at all.
 *
 * HOW THE PREVIEW STAYS IN STEP, and why it is two messages rather than one:
 *
 *   1. Colour is derived HERE, in the browser, and pushed straight into the frame. It is the same
 *      arithmetic as inc/theme.php and it has to be, because it is also what draws the contrast
 *      readout — there is one copy of it in this file serving both. Being local, it lands in the
 *      frame within a frame or two of the picker moving, which is the difference between a colour
 *      picker that feels live and one that feels broken.
 *   2. Everything else — every string, size, toggle and list — is rebuilt by the SERVER, by posting
 *      the form to inc/admin/preview.php and getting back the real n8nchat_boot_config(). That
 *      costs a round trip and is worth every millisecond of it: the alternative is a second copy of
 *      the config builder and the sanitiser written in JavaScript, drifting from the PHP from the
 *      day it is written. What the preview shows is therefore what a save would actually produce,
 *      not an approximation of it.
 *
 * Both are debounced together on ~150ms of quiet, so holding a key down or dragging a picker
 * produces one update rather than forty.
 */
(function () {
	'use strict';

	var N = window.N8NCHAT_ADMIN;
	if (!N) { return; }

	var form = document.getElementById('n8nchat-form');
	var frame = document.querySelector('[data-n8nchat-frame]');
	var iframe = document.querySelector('[data-n8nchat-iframe]');
	var tools = document.querySelector('[data-n8nchat-tools]');
	if (!form) { return; }

	var DEBOUNCE_MS = 150;

	/** The control standing for one setting, found by the attribute rather than by its name. */
	function byField(name) {
		return name ? form.querySelector('[data-n8nchat-field="' + name + '"]') : null;
	}

	function valueOf(el) {
		if (!el) { return ''; }
		return el.type === 'checkbox' ? (el.checked ? '1' : '') : el.value;
	}

	/* ================================================================ colour
	 *
	 * A port of the contrast helpers in inc/theme.php, and a deliberate one.
	 *
	 * `primary_color` is a free-form picker with no luminance check, so everything that sits ON the
	 * brand colour or uses it AS text is derived rather than assumed — including, for a narrow band
	 * of mid-tones around 0.17–0.21 relative luminance, moving the surface itself because NEITHER
	 * white nor near-black ink reaches 4.5:1 on it. Plenty of ordinary corporate blues and greys are
	 * in that band. Without a readout, the only symptom is that the widget is very slightly not the
	 * colour the client gave you, and nobody ever finds out why.
	 *
	 * The two ink candidates and the two theme surfaces are NOT written here — they are asked of
	 * inc/theme.php at render time and handed over in N.inks and N.surfaces, so a change to either
	 * cannot leave this readout describing a widget that no longer exists.
	 */

	function hex6(value) {
		var v = String(value == null ? '' : value).replace(/^#/, '');
		if (v.length === 3) { v = v[0] + v[0] + v[1] + v[1] + v[2] + v[2]; }
		return /^[0-9a-f]{6}$/i.test(v) ? v.toLowerCase() : '';
	}

	function channels(value) {
		var h = hex6(value);
		if (!h) { return [0, 0, 0]; }
		return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
	}

	function toHex(rgb) {
		return '#' + rgb.map(function (c) {
			return ('0' + Math.max(0, Math.min(255, Math.round(c))).toString(16)).slice(-2);
		}).join('');
	}

	function shade(value, pct) {
		var f = 1 - Math.max(0, Math.min(100, pct)) / 100;
		return toHex(channels(value).map(function (c) { return c * f; }));
	}

	function tint(value, pct) {
		var f = Math.max(0, Math.min(100, pct)) / 100;
		return toHex(channels(value).map(function (c) { return c + (255 - c) * f; }));
	}

	/** WCAG 2.x relative luminance. */
	function luminance(value) {
		var w = [0.2126, 0.7152, 0.0722];
		return channels(value).reduce(function (sum, raw, i) {
			var c = raw / 255;
			c = c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
			return sum + w[i] * c;
		}, 0);
	}

	function contrast(a, b) {
		var la = luminance(a);
		var lb = luminance(b);
		return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
	}

	/** White or near-black, whichever reads better on the worst of the given surfaces. */
	function onColor(backgrounds) {
		var light = N.inks.light;
		var dark = N.inks.dark;
		var lightWorst = 21;
		var darkWorst = 21;
		backgrounds.forEach(function (bg) {
			lightWorst = Math.min(lightWorst, contrast(light, bg));
			darkWorst = Math.min(darkWorst, contrast(dark, bg));
		});
		return darkWorst > lightWorst ? dark : light;
	}

	/** The brand colour walked toward one end of the scale until it is legible AS TEXT on a surface. */
	function readableOn(value, surface) {
		if (contrast(value, surface) >= 4.5) { return hex6(value) ? '#' + hex6(value) : value; }
		var lighten = luminance(surface) < 0.18;
		for (var pct = 5; pct <= 90; pct += 5) {
			var candidate = lighten ? tint(value, pct) : shade(value, pct);
			if (contrast(candidate, surface) >= 4.5) { return candidate; }
		}
		return lighten ? N.inks.light : N.inks.dark;
	}

	/** The brand colour nudged only as far as it must be to carry readable text. */
	function accentSurface(value) {
		var base = hex6(value) ? '#' + hex6(value) : value;
		if (contrast(onColor([base]), base) >= 4.5) { return base; }
		var lighten = onColor([base]) !== N.inks.light;
		for (var pct = 4; pct <= 64; pct += 4) {
			var candidate = lighten ? tint(base, pct) : shade(base, pct);
			if (contrast(onColor([candidate]), candidate) >= 4.5) { return candidate; }
		}
		return base;
	}

	/** Everything the preview needs to repaint the brand, in one object. */
	function accentTokens(picked) {
		var accent = accentSurface(picked);
		var ink = onColor([accent]);
		return {
			accent: accent,
			ink: ink,
			// White ink improves as the surface darkens and dark ink as it lightens, so the hover
			// state moves in whichever direction PRESERVES the ink already chosen.
			hover: ink === N.inks.light ? shade(accent, 12) : tint(accent, 12),
			inkLight: readableOn(accent, N.surfaces.light),
			inkDark: readableOn(accent, N.surfaces.dark)
		};
	}

	/* ================================================================ contrast readout */

	var colourEl = byField(N.colorField);
	var readout = colourEl ? colourEl.parentNode.querySelector('.n8nchat-contrast') : null;

	/**
	 * A contrast ratio for display, rounded DOWN.
	 *
	 * Never up. A ratio of 4.49 rounded to one decimal reads "4.5:1", which is the AA threshold
	 * exactly — so the chip claimed a pass while the marker beside it said fail, and the only
	 * possible reading of that is that the readout is broken. Truncating means the number shown is
	 * always one the colour genuinely achieves.
	 */
	function ratio(value) {
		return (Math.floor(value * 10) / 10).toFixed(1) + ':1';
	}

	/**
	 * One readout pill.
	 *
	 * The label goes in BOTH a tooltip and a visually hidden span, and the second is the one that
	 * matters. This sits in an aria-live region, and a live region announces its text content — not
	 * the `title` of the things inside it — so a screen-reader user would otherwise have heard three
	 * bare numbers with nothing to say which was which. `.screen-reader-text` is core's own class, so
	 * no styling of ours is involved in keeping it invisible.
	 */
	function chip(text, label, css, fail) {
		var span = document.createElement('span');
		span.className = 'n8nchat-chip' + (fail ? ' n8nchat-chip-fail' : '');
		span.title = label;

		var hidden = document.createElement('span');
		hidden.className = 'screen-reader-text';
		hidden.textContent = label + ' ';
		span.appendChild(hidden);
		span.appendChild(document.createTextNode(text));

		Object.keys(css).forEach(function (prop) { span.style[prop] = css[prop]; });
		return span;
	}

	function paintContrast() {
		if (!readout || !colourEl) { return; }
		var picked = colourEl.value;
		var tokens = accentTokens(picked);
		var pickedInk = onColor([picked]);
		var pickedRatio = contrast(pickedInk, picked);
		var nudged = tokens.accent.toLowerCase() !== ('#' + hex6(picked));

		readout.textContent = '';

		// What the colour you picked can carry. This is the one that can fail, and the whole reason
		// the readout is here.
		readout.appendChild(chip(
			'Aa ' + ratio(pickedRatio),
			N.i18n.onAccent + ' — ' + (pickedRatio >= 4.5 ? N.i18n.pass : N.i18n.fail),
			{ background: picked, color: pickedInk },
			pickedRatio < 4.5
		));

		// What the widget will actually paint, when that is not the same thing.
		if (nudged) {
			readout.appendChild(chip(
				'Aa ' + ratio(contrast(tokens.ink, tokens.accent)),
				N.i18n.willUse + ' ' + tokens.accent,
				{ background: tokens.accent, color: tokens.ink },
				false
			));
		}

		// The brand as TEXT — links, chips, the focus ring — which is a different question again and
		// is why a very light brand still reads on a white background.
		var textChip = chip(
			'Aa ' + ratio(contrast(tokens.inkLight, N.surfaces.light)),
			N.i18n.asText + ' — ' + tokens.inkLight,
			{ color: tokens.inkLight },
			false
		);
		textChip.className += ' n8nchat-chip-text';
		readout.appendChild(textChip);

		if (nudged) {
			var warn = document.createElement('span');
			warn.className = 'n8nchat-warn';
			warn.textContent = N.i18n.nudged.replace('%s', tokens.accent);
			readout.appendChild(warn);
		}
	}

	/* ================================================================ the preview channel */

	function postToFrame(message) {
		if (!iframe || !iframe.contentWindow) { return; }
		message.ns = 'n8nchat';
		// Never '*'. A target origin is the only thing stopping the message being delivered to
		// whatever document happens to have replaced the frame's contents.
		iframe.contentWindow.postMessage(message, N.origin || window.location.origin);
	}

	function pushTheme() {
		if (!colourEl) { return; }
		// Values only. The frame assembles the stylesheet itself, because whether a dark block should
		// be emitted at all depends on the colour scheme, and the frame is the end that knows it.
		postToFrame({ type: 'theme', tokens: accentTokens(colourEl.value) });
	}

	var inflight = null;

	function pushConfig() {
		if (!iframe || !window.fetch || !window.FormData) { return; }

		var data = new FormData(form);
		// settings_fields() has already put an `action` of its own in the form — the one options.php
		// reads — so this must SET rather than append, or admin-ajax would dispatch the wrong one.
		data.set('action', N.configAction);
		data.set('nonce', N.nonce);

		// An older request that lands after a newer one would repaint the preview with settings the
		// administrator has already moved on from, and there is no ordering guarantee between two
		// requests in flight. Cancelling the previous one removes the question.
		if (inflight) { inflight.abort(); }
		var controller = window.AbortController ? new AbortController() : null;
		inflight = controller;

		fetch(N.ajaxUrl, {
			method: 'POST',
			body: data,
			credentials: 'same-origin',
			signal: controller ? controller.signal : undefined
		}).then(function (response) {
			return response.json();
		}).then(function (payload) {
			inflight = null;
			if (!payload || !payload.success || !payload.data) { return; }
			postToFrame({ type: 'config', config: payload.data.config, css: payload.data.css });
			syncSchemeButtons(payload.data.scheme);
		}).catch(function () {
			// An aborted request, a lost connection, or a session that has expired. The preview keeps
			// showing the last configuration it was given, which is the least surprising thing it can
			// do — and the form itself is unaffected either way.
		});
	}

	/**
	 * Enable the Light/Dark preview buttons only when there is something to switch between.
	 *
	 * They exist to answer "what does a visitor in dark mode see?", which is a question only a site
	 * on the AUTO colour scheme has. On "Always light" the widget is light whatever the device says,
	 * so the buttons correctly did nothing at all — and a button that correctly does nothing is
	 * indistinguishable from a broken one. Disabled with a reason attached is the honest version.
	 *
	 * The scheme comes back from the server with the configuration rather than being read out of the
	 * form, so this needs no more idea of which setting it is than the rest of the file does.
	 */
	function syncSchemeButtons(scheme) {
		if (!tools) { return; }
		var fixed = scheme !== 'auto';
		var asSet = tools.querySelector('[data-n8nchat-scheme=""]');

		Array.prototype.forEach.call(tools.querySelectorAll('[data-n8nchat-scheme]'), function (button) {
			if (button.getAttribute('data-n8nchat-scheme') === '') { return; }
			button.disabled = fixed;
			button.title = fixed ? N.i18n.schemeFixed : '';
			// The setting has moved out from under a forced preview. Put the frame back to what the
			// site actually says rather than leaving it showing a scheme nothing can now produce.
			if (fixed && button.classList.contains('is-on') && asSet) {
				button.classList.remove('is-on');
				asSet.classList.add('is-on');
				postToFrame({ type: 'scheme', value: '' });
			}
		});
	}

	var timer = null;

	function schedule() {
		paintContrast();
		clearTimeout(timer);
		timer = setTimeout(function () {
			pushTheme();
			pushConfig();
		}, DEBOUNCE_MS);
	}

	// Delegated, so controls added by a filter later are covered without re-binding. `input` catches
	// typing and dragging a colour picker; `change` catches selects, checkboxes and the pickers that
	// only report on release.
	form.addEventListener('input', schedule);
	form.addEventListener('change', schedule);

	/* ================================================================ tabs */

	var panels = form.querySelectorAll('[data-n8nchat-panel]');
	var tabs = document.querySelectorAll('[data-n8nchat-tab]');

	function showTab(name, remember) {
		var known = false;
		Array.prototype.forEach.call(panels, function (panel) {
			var match = panel.getAttribute('data-n8nchat-panel') === name;
			panel.hidden = !match;
			if (match) { known = true; }
		});
		if (!known) { return false; }

		Array.prototype.forEach.call(tabs, function (tab) {
			var match = tab.getAttribute('data-n8nchat-tab') === name;
			tab.classList.toggle('nav-tab-active', match);
			tab.setAttribute('aria-current', match ? 'page' : 'false');
		});

		/*
		 * Keep the address bar honest without adding a history entry per tab.
		 *
		 * The tabs are links, and their href is a real URL that renders the same panel server-side —
		 * so a bookmark, a reload and the browser's Back button all have to agree with what is on
		 * screen. replaceState rather than pushState because six tabs on one settings page are one
		 * screen, not six pages, and pushState would turn "go back to where I came from" into six
		 * presses of the Back button.
		 *
		 * Focus deliberately stays on the tab that was clicked. These are links rather than ARIA
		 * tabs, the panel follows them in the document, and a keyboard user's next Tab press lands
		 * in the panel that has just appeared — which is the behaviour they already expect from
		 * every other set of links in wp-admin.
		 */
		if (remember && window.history && history.replaceState) {
			var url = new URL(window.location.href);
			url.searchParams.set('tab', name);
			history.replaceState(null, '', url.toString());
		}
		return true;
	}

	document.addEventListener('click', function (event) {
		var link = event.target.closest ? event.target.closest('[data-n8nchat-tab], [data-n8nchat-goto]') : null;
		if (!link) { return; }
		var name = link.getAttribute('data-n8nchat-tab') || link.getAttribute('data-n8nchat-goto');
		if (showTab(name, true)) { event.preventDefault(); }
	});

	/*
	 * Native validation, done by hand, for a reason worth spelling out.
	 *
	 * The form carries `novalidate` because four settings render as <input type="url"> and a browser
	 * asked to submit a form containing an invalid one tries to FOCUS it to explain — but a field on
	 * an inactive tab sits inside a `hidden` subtree and cannot be focused, so the submit is
	 * abandoned with a console message and no visible effect whatsoever. The Save button appears to
	 * do nothing at all.
	 *
	 * Reproducing it here in the right order — reveal the tab, then focus, then ask the browser to
	 * report — puts the message back in front of the person who typed the value. The server does not
	 * depend on any of this: n8nchat_sanitize_value() applies its own http/https whitelist regardless.
	 */
	form.addEventListener('submit', function (event) {
		var invalid = null;
		Array.prototype.some.call(form.querySelectorAll('input, select, textarea'), function (el) {
			if (el.willValidate && !el.checkValidity()) { invalid = el; return true; }
			return false;
		});
		if (!invalid) { return; }

		event.preventDefault();
		var panel = invalid.closest('[data-n8nchat-panel]');
		if (panel) { showTab(panel.getAttribute('data-n8nchat-panel'), true); }
		invalid.focus();
		if (invalid.reportValidity) { invalid.reportValidity(); }
	});

	/* ================================================================ style presets */

	var presetBox = document.querySelector('[data-n8nchat-presets]');
	var presetEl = byField(N.presetField);

	if (presetBox && presetEl && N.presets && Object.keys(N.presets).length) {
		// Two controls for one setting is worse than one, so the cards and the select swap places
		// the moment there is a script to make the cards work. With JavaScript off the select stays
		// and the cards are never shown — which is right, because a card cannot set five fields
		// without one.
		presetBox.hidden = false;
		var selectRow = presetEl.closest('tr');
		if (selectRow) { selectRow.hidden = true; }

		var status = presetBox.querySelector('.n8nchat-preset-status');

		presetBox.addEventListener('click', function (event) {
			var card = event.target.closest('[data-n8nchat-preset]');
			if (!card) { return; }
			applyPreset(card.getAttribute('data-n8nchat-preset'));
		});

		/*
		 * Apply a preset WITHOUT overwriting anything that has been customised.
		 *
		 * The preset field's own help text promises exactly this — "changing it does not overwrite
		 * values you have already customised" — and a shortcut that threw away a hand-picked window
		 * width would be the single most annoying control on the screen. "Customised" means the value
		 * is neither the schema default nor what some other preset would have set, which is the only
		 * way to tell "I chose 420" from "a preset put 420 there".
		 *
		 * What was left alone is then said out loud. A card that silently does nothing because every
		 * field it touches has been customised is indistinguishable from a broken button.
		 */
		function applyPreset(name) {
			var values = N.presets[name];
			if (!values) { return; }

			presetEl.value = name;

			var kept = [];
			Object.keys(values).forEach(function (field) {
				var el = byField(field);
				if (!el) { return; }
				var current = String(valueOf(el));
				if (isCustomised(field, current)) {
					kept.push(N.labels[field] || field);
					return;
				}
				if (el.type === 'checkbox') { el.checked = !!values[field] && values[field] !== '0'; }
				else { el.value = values[field]; }
			});

			Array.prototype.forEach.call(presetBox.querySelectorAll('[data-n8nchat-preset]'), function (card) {
				var on = card.getAttribute('data-n8nchat-preset') === name;
				card.classList.toggle('is-current', on);
				card.setAttribute('aria-checked', on ? 'true' : 'false');
			});

			if (status) {
				status.textContent = kept.length
					? N.i18n.applied + ' ' + N.i18n.kept.replace('%s', kept.join(', '))
					: N.i18n.applied;
			}

			schedule();
		}

		function isCustomised(field, current) {
			if (String(N.presetDefaults[field]) === current) { return false; }
			var names = Object.keys(N.presets);
			for (var i = 0; i < names.length; i++) {
				var candidate = N.presets[names[i]][field];
				if (candidate !== undefined && String(candidate) === current) { return false; }
			}
			return true;
		}
	}

	/* ================================================================ the preview pane */

	if (iframe && frame) {
		/*
		 * The src is attached here rather than printed into the markup because it carries a nonce,
		 * and a nonce in an attribute is fetched on every page load — by a prefetching browser as
		 * readily as by a person. Setting it from script keeps the request to the case where somebody
		 * is actually looking at the screen.
		 */
		iframe.src = iframe.getAttribute('data-src');
		frame.classList.add('is-live');
		if (tools) { tools.hidden = false; }

		/*
		 * Scale the frame to the column.
		 *
		 * The widget decides for itself that it is on a phone below 600 CSS pixels of viewport and
		 * goes full-screen. A preview column is rarely much wider than that, so the frame is given a
		 * genuine desktop viewport in CSS and scaled down to fit — which previews the desktop widget
		 * honestly rather than previewing the phone one by accident. The "Phone" button is the same
		 * mechanism with a narrow viewport, deliberately.
		 */
		var fit = function () {
			var style = getComputedStyle(frame);
			var wide = parseFloat(style.getPropertyValue('--n8nchat-vw')) || 780;
			var tall = parseFloat(style.getPropertyValue('--n8nchat-vh')) || 780;
			var cap = parseFloat(style.getPropertyValue('--n8nchat-vmax')) || 560;
			var available = frame.clientWidth;
			if (!available) { return; }
			// Height as well as width, so that switching between the desktop and phone viewports —
			// which have very different aspect ratios — does not resize the whole column under the
			// administrator's cursor.
			frame.style.setProperty('--n8nchat-scale', String(Math.min(1, available / wide, cap / tall)));
		};

		if (window.ResizeObserver) { new ResizeObserver(fit).observe(frame); }
		else { window.addEventListener('resize', fit); }
		fit();

		window.addEventListener('message', function (event) {
			if (N.origin && event.origin !== N.origin) { return; }
			if (!event.data || event.data.ns !== 'n8nchat') { return; }
			// The frame has just (re)loaded and is showing what is SAVED. The form may hold edits
			// that are not, so it is brought up to date the moment it says it is listening — which is
			// also what restores unsaved work after the widget's own "New chat" reloads the frame.
			if (event.data.type === 'ready') { pushTheme(); pushConfig(); }
		});

		// One segmented control per row of buttons, all handled the same way: mark the pressed one
		// and tell the frame. The attribute a button carries is the message it sends.
		tools && tools.addEventListener('click', function (event) {
			var button = event.target.closest('button');
			if (!button) { return; }

			if (button.hasAttribute('data-n8nchat-demo')) {
				postToFrame({ type: 'demo' });
				return;
			}

			var group = button.parentNode;
			var press = function () {
				Array.prototype.forEach.call(group.querySelectorAll('button'), function (sibling) {
					sibling.classList.toggle('is-on', sibling === button);
				});
			};

			if (button.hasAttribute('data-n8nchat-scheme')) {
				press();
				postToFrame({ type: 'scheme', value: button.getAttribute('data-n8nchat-scheme') });
			} else if (button.hasAttribute('data-n8nchat-size')) {
				press();
				frame.setAttribute('data-size', button.getAttribute('data-n8nchat-size'));
				fit();
			} else if (button.hasAttribute('data-n8nchat-open')) {
				press();
				postToFrame({ type: 'open', value: button.getAttribute('data-n8nchat-open') === '1' });
			}
		});
	}

	// Draw the readout once for what is already saved, so the screen is informative before anything
	// is touched.
	paintContrast();
})();
