<?php
/**
 * Runs when the plugin is DELETED from the Plugins screen (not on deactivate). WordPress loads
 * this file on its own — the main plugin file is never included — so nothing here may rely on the
 * plugin's constants or functions being defined.
 *
 * `n8nchat_update_token` is a leftover from before 2.1: it held a live GitHub personal access token
 * with read access to a private repository, because that was how updates were fetched. Updates now
 * come from a public channel and nothing writes or reads this row, but a site that has never loaded
 * wp-admin since upgrading may still have one — and a working credential sitting in the database of
 * a site nobody is looking at any more, surviving every later backup and export, is exactly what
 * this file exists to prevent. It goes here as well as in inc/updates.php.
 *
 * Also cleaned up:
 *   - `n8nchat_options`                 — the native (non-ACF) settings blob. ACF-path sites keep
 *                                         their values in the ACF options row, which belongs to the
 *                                         theme's Site Options page and is deliberately not touched.
 *   - `external_updates-n8n-chatbot`    — the Plugin Update Checker's bookkeeping. It's written
 *                                         with update_site_option()
 *                                         (lib/plugin-update-checker/Puc/v5p6/StateStore.php:147),
 *                                         so it's removed with delete_site_option().
 *   - `n8nchat_dismiss_token_notice`    — the per-user "I've seen the no-token warning" flag, for
 *                                         every user at once. The warning itself went with the
 *                                         token in 2.1.
 *   - `n8nchat_feedback`                — the thumbs up/down tally. Aggregate counts plus the last
 *                                         50 {rating, page, timestamp} entries; deliberately no
 *                                         session id, message id or message text.
 *
 * On multisite the per-blog rows exist once per site, so the whole lot is repeated inside a
 * get_sites() loop. The network-wide rows (site options, and the token itself when it was stored
 * network-wide) are deleted once, outside it.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) { exit; }

/*
 * The schema is the list of settings, and therefore the list of ACF option rows to sweep. It is
 * required explicitly because WordPress loads THIS file on its own — the main plugin file, and so
 * every constant and function it defines, is never included. inc/schema.php is safe to pull in
 * here: it declares functions and calls apply_filters(), both of which are available at uninstall
 * time, and it touches no plugin constant beyond ABSPATH.
 *
 * Reading the field names from the schema rather than repeating them is the point. The list was
 * previously a literal array of eleven names maintained by hand, so every setting added after it
 * was written left its ACF rows behind on uninstall — silently, in a code path nobody runs twice.
 */
require_once __DIR__ . '/inc/schema.php';

/** Per-blog rows. Mirrors the option names defined in n8n-chatbot.php. */
function n8nchat_uninstall_site() {
	delete_option( 'n8nchat_update_token' );
	delete_option( 'n8nchat_options' );

	// Bookkeeping for the ACF <-> native store sync (inc/settings.php): which store was last
	// authoritative, its per-store fingerprints, and any unresolved divergence notice.
	// The ratings tally. Aggregate counts and page URLs only — see inc/rest.php — but it is still
	// ours, and "uninstall leaves rows behind" is a complaint whether or not the rows are personal.
	delete_option( 'n8nchat_feedback' );
	delete_option( 'n8nchat_store_state' );
	delete_option( 'n8nchat_store_conflict' );

	// Which plugin version's schema the recorded store fingerprints were taken under.
	delete_option( 'n8nchat_schema_state' );

	// The ACF options-page rows, which ACF itself leaves behind. Written as options_n8nchat_*
	// with a companion _options_n8nchat_* field-key reference row.
	//
	// Retired keys are swept alongside the live ones: a setting this version no longer knows about
	// still has rows on any site that ran the version that did, and dropping it from the schema is
	// exactly what would otherwise strand them forever.
	$n8nchat_fields = array_merge( array_keys( n8nchat_schema() ), n8nchat_retired_keys() );

	foreach ( $n8nchat_fields as $n8nchat_field ) {
		delete_option( 'options_n8nchat_' . $n8nchat_field );
		delete_option( '_options_n8nchat_' . $n8nchat_field );
	}
	unset( $n8nchat_fields, $n8nchat_field );

	// Belt and braces: on a single-site install the PUC state store's update_site_option() writes a
	// plain wp_options row, so clear it here as well as via delete_site_option() below.
	delete_option( 'external_updates-n8n-chatbot' );

	// Any leftover site transients from the update-error notice.
	delete_option( '_site_transient_n8nchat_update_error' );
	delete_option( '_site_transient_timeout_n8nchat_update_error' );
}

if ( is_multisite() ) {

	$n8nchat_sites = get_sites( [
		'fields' => 'ids',
		'number' => 0, // No limit — get_sites() otherwise caps at 100 and would silently skip the rest.
	] );

	foreach ( $n8nchat_sites as $n8nchat_site_id ) {
		switch_to_blog( $n8nchat_site_id );
		n8nchat_uninstall_site();
		restore_current_blog();
	}
	unset( $n8nchat_sites, $n8nchat_site_id );

	// Network-wide copies: the token (multisite stores it in sitemeta — see n8nchat_get_token() in
	// inc/updates.php) and PUC's own state.
	delete_site_option( 'n8nchat_update_token' );
	delete_site_option( 'external_updates-n8n-chatbot' );
	delete_site_transient( 'n8nchat_update_error' );

} else {

	n8nchat_uninstall_site();
	delete_site_option( 'external_updates-n8n-chatbot' );
	delete_site_transient( 'n8nchat_update_error' );

}

/**
 * User meta is global on multisite (one wp_usermeta table for the whole network), so this is a
 * single pass either way. $object_id 0 with $delete_all = true is the documented way to drop a meta
 * key for every user without enumerating them — an important detail on a network with 100k accounts.
 */
delete_metadata( 'user', 0, 'n8nchat_dismiss_token_notice', '', true );
