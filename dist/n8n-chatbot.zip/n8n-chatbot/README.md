# n8n Chatbot Widget

A theme-independent WordPress plugin that puts a modern chat widget on a site and talks to an
[n8n](https://n8n.io/) Chat Trigger workflow. It is the visitor-facing half of the
`platform.wwebdesign.co.uk` chatbot product: the portal provisions the bot and holds its knowledge
and conversations, and this is what the customer's own visitors see.

**2.0 replaced the front end entirely.** Up to 1.3.5 the plugin embedded the third-party
`@n8n/chat` package and bent it into shape from the outside. It now ships its own widget.

## What changed in 2.0, and why

| | 1.3.5 | 2.0 |
|---|---|---|
| Always-on payload | **~355 KiB gzipped**, fetched on every page view whether or not anyone opened the chat | **7.6 KiB gzipped**; the chat itself loads on first interaction |
| Third-party requests | `@n8n/chat` JS + CSS from jsDelivr, the CSS render-blocking in `<head>` | none |
| Style isolation | 262 lines of `#n8n-chat`-scoped overrides and `!important`, fighting the host theme | Shadow DOM |
| Accessibility | retrofitted onto someone else's DOM with MutationObservers | built in |
| Settings | 11 | ~50, in six groups |
| Response modes | streaming hardcoded on; a "Last Node" workflow rendered nothing | detected at runtime; both work |
| Restoring a conversation | one n8n execution per restore | replayed from the browser; zero executions |

The version pin was load-bearing — the CSS selectors, the tool-chatter stripping and the
accessibility patches all keyed off `@n8n/chat` 1.23.0's exact markup — and upstream had grown from
266 to 560 KiB gzipped in nine months. There was no good direction from there.

## Requirements

- **WordPress 6.3+**, **PHP 7.4+** (both declared in the plugin header).
- **Safari 15.4+, Chrome 108+, Firefox 101+** — the real floor, set by `100dvh`,
  `crypto.randomUUID` and `AbortSignal.reason`. Below Safari 14 the widget does not merely degrade,
  it dies: `matchMedia(...).addEventListener('change')` throws inside its mount and nothing renders.
  Older Safari 15.0–15.3 degrades rather than breaks — the desktop panel loses its height and a
  timeout is reported as a deliberate stop. The widget is served as-is with no build step and no
  transpiler, so these are genuine engine requirements, not build-target choices.
- **Outbound HTTPS to the n8n host from the visitor's browser.** The widget POSTs directly to the
  Chat Trigger webhook, because that node's Allowed Origins is locked per bot to the customer's own
  domain and proxying through WordPress would fail CORS on every bot already in production.
- **Outbound HTTPS to `api.github.com` from the server**, for updates. Without it the plugin runs
  fine, it just never sees a new version.
- **ACF is optional.** If an ACF (Pro) options page is present the settings appear as a tab there;
  otherwise the plugin provides its own screen.

## Install

Download `n8n-chatbot.zip` from the latest
[GitHub Release](https://github.com/dan-w-web/W-Web-N8N-Chatbot/releases), then **Plugins → Add New
→ Upload Plugin**. The zip's top-level folder is already `n8n-chatbot/`, so it lands in the right
place. No SSH, no git, no build step.

## Configure

The plugin picks one of two settings UIs automatically, so exactly one appears per site:

- **No ACF (most sites)** — a top-level **Chatbot** menu in wp-admin, with one tab per settings
  group and a live preview of the real widget beside them. Values live in one `n8nchat_options` row.
- **ACF (Pro) options page present** — settings appear as a **Chatbot** tab on that page (default
  slug `fsc-site-options`). Point it elsewhere with:

  ```php
  add_filter( 'n8nchat_options_page', fn() => 'my-theme-options' );
  ```

Both UIs are generated from the same schema, so they cannot drift.

### The live preview

The native screen renders the actual widget in a sandboxed iframe and updates it as you type. It is
not a mock-up: it is `assets/boot.js` and `assets/widget/widget.js` booted from a configuration the
server builds with the same `n8nchat_boot_config()` the front end uses, so what you see is what a
save would produce.

**It never reaches your workflow.** The webhook is replaced with a host on the `.invalid` TLD,
`fetch` is intercepted inside the frame and answers a canned n8n-format stream, and the document is
served with `connect-src 'none'`. Three independent guards, because a preview that spent a client's
n8n executions and OpenAI tokens every time somebody dragged a colour picker would be a bill, not a
bug. Browser storage is replaced with an in-memory shim for the same reason: wp-admin shares an
origin with the front end, so an unguarded preview would rewrite — and, at a zero history TTL,
delete — the conversation state belonging to your own visits to the live site.

The brand-colour picker carries a live contrast readout showing what the colour achieves as ink and
as text, and says so when a mid-tone brand had to be nudged to carry readable text at all.

### The settings, by group

| Group | What it covers |
|---|---|
| **Connection** | Webhook URL (required — nothing renders without it) and Bot ID |
| **Appearance** | Style preset, brand colour, colour scheme, position and offsets, launcher size/icon/label, assistant avatar, window size, corner rounding, density, font stack |
| **Messages** | Header title/subtitle, status line, opening message, starter prompts, input placeholder, sender names, error copy, out-of-hours line |
| **Behaviour** | Teaser bubble and its triggers, notification sound, page targeting rules, how long a conversation is remembered, consent mode |
| **Handoff** | Lead capture, where enquiries go, transcript email |
| **Advanced** | z-index, custom CSS |

**Only the Webhook URL is mandatory.** Everything else has a working default.

**Bot ID** is for the multi-tenant platform: when several sites share one n8n webhook, it travels as
chat `metadata.bot_id` so the workflow can route to the right bot. Leave it blank for a standalone
site with its own webhook and nothing is sent.

### Who can change what

The plugin's own settings screen is registered with `manage_options`, so on that path everything is
administrator-only. **The ACF path is not**: the field group attaches to an options page the *theme*
registered, and ACF's default capability for one is `edit_posts` — so on a typical site the chatbot
tab is reachable by any Editor. That was tolerable when the tab held a webhook URL and some labels.
It stopped being tolerable when the same tab gained the address enquiry emails go to and a second
address every lead is POSTed to.

The rule is: **anything that decides where data goes, or how long it is kept, is administrator-only.
Everything else is editorial.** An Editor trusted to write the site's copy is trusted to write the
chatbot's.

| Administrator only | Everyone who can reach the page |
|---|---|
| Webhook URL, Bot ID | Titles, subtitle, status line, greeting, starter prompts, placeholder, sender names, error copy |
| Handoff on/off, recipient, webhook | Brand colour, scheme, preset, position, offsets, sizes, radius, density, font, avatars |
| Transcript email on/off | Teaser and its triggers, sound, page rules |
| Consent mode and signal, history retention | |
| Custom CSS | |

Enforced twice. The restricted fields are omitted from the ACF group for a user who lacks the
capability, and `acf/update_value` refuses the write even if a value is submitted anyway — returning
the **stored** value, never a default, so a refused write can never blank a live webhook. An
administrator viewing an options page with a weaker capability gets a notice suggesting they raise
the page's own capability in the theme.

Filtering happens **only in wp-admin**, and that is load-bearing: `acf/init` fires on every request
including anonymous ones, and the front end resolves settings through `get_field()` *by key*, which
returns null for a key no registered group contains. Filtering the group outside wp-admin would not
hide a control from an Editor — it would unregister the webhook for every visitor and the widget
would disappear.

### Brand colour and contrast

`primary_color` is a free-form picker, so the plugin derives everything that has to be readable
rather than assuming it. Ink on the brand colour is chosen by measuring both candidates; the brand
as *text* is darkened or lightened until it clears 4.5:1 on the light and the dark surface
separately; and the hover state moves in whichever direction preserves the chosen ink.

There is also a narrow band of mid-tone colours — roughly 0.17 to 0.21 relative luminance, which
includes plenty of ordinary corporate blues and greys — where **neither** white nor near-black ink
reaches 4.5:1. A brand in that band is not a colour text can sit on, so the surface itself is nudged
by the minimum that makes it legible. 6 of the 216 web-safe colours need this;
`tests/schema.php` checks all 216.

## How it works

```
inc/schema.php     every setting, declared once. The ACF field group, the native form, the
                   sanitiser, the store fingerprint and uninstall.php are all generated from it
inc/theme.php      colour maths and the design-token layer; emits both themes as custom properties
inc/render.php     decides whether the widget runs on this request, prints the theme, enqueues boot
inc/settings.php   the ACF path, plus the ACF <-> native store migration
inc/native-settings.php  the non-ACF settings store: the reader, and the shared sanitiser
inc/admin/page.php       the non-ACF settings screen — one tab per schema group
inc/admin/preview.php    the live preview document, and its mock n8n backend
inc/rest.php       the two endpoints an anonymous visitor can reach: lead capture and transcript
inc/updates.php    self-update from GitHub releases

assets/boot.js                ~3 KB: launcher, teaser, unread badge, client state, lazy import
assets/widget/widget.js       the chat
assets/widget/stream.js       the n8n wire format
assets/widget/markdown.js     a small escape-first Markdown renderer
assets/widget/handoff.js      the "talk to a person" card and "email me this conversation"
assets/widget/widget.css      the chat's styles, loaded into the shadow root on demand
assets/admin/admin.js         the settings screen: tabs, presets, contrast readout, preview channel
assets/admin/admin.css        the settings screen's layout, over WordPress's own admin tokens
```

### The n8n contract

```
POST <webhook>
Content-Type: application/json
Accept: text/plain

{"action":"sendMessage","sessionId":"…","chatInput":"…","metadata":{"bot_id":"…"}}
```

n8n answers with `Transfer-Encoding: chunked` and `Content-Type: application/json` for **both**
response modes, so the headers cannot tell you which you got. The body is newline-delimited JSON:

```
{"type":"begin","metadata":{"nodeId":"…","nodeName":"AI Agent","runIndex":0}}
{"type":"item","content":"Hel","metadata":{…}}
{"type":"end","metadata":{…}}
```

…or, from a Last Node workflow, a single `{"output":"…"}`. The widget reads line by line and works
out which it was given, which is why there is no "enable streaming" setting. In 1.x there was one,
hardcoded to `true`, and a workflow left in Last Node mode rendered nothing at all while looking
exactly like a broken plugin.

Chunks are grouped by `nodeId` + `runIndex`. An agent that calls a tool part-way through an answer
emits a fresh `begin` either side of the call, so grouping by that key puts the halves in two
bubbles instead of splicing them into one paragraph.

**For streaming to work end to end** you need a Chat Trigger at typeVersion ≥ 1.2 with
`responseMode: streaming`, streaming enabled on the AI Agent node itself, n8n ≥ 1.103.0, and no
buffering proxy in front of it (`flush_interval -1` in the platform's Caddyfile is what allows it).
If any of that is missing the widget still works — it simply gets one lump instead of a stream.

### Conversation history

The transcript is replayed from `localStorage`, not fetched from n8n. 1.x restored it with a
`loadPreviousSession` POST, which n8n bills as a workflow execution — and because the widget mounted
on every page load whether or not anyone opened it, that was one execution per page view from
visitors who never touched the chat. It was comfortably the plugin's largest running cost.

n8n keeps the conversation memory against the same `sessionId` either way, so the next message has
full context. The only change is that we no longer pay a workflow run to be told what the browser
already knows — and the transcript appears instantly instead of after a spinner.

## Handoff and transcripts

Two settings on the **Handoff** tab put a person at the end of the conversation. Both are off by
default and both are inert until switched on.

- **Offer a human** adds a *Talk to a person* control under the transcript. It opens an inline card
  — name, email, an optional message — which is emailed to **Send enquiries to** (or, blank, to the
  site's admin address) and, if **Also POST to** is set, posted to that URL as JSON as well.
- **Let visitors email themselves the conversation** adds an *Email me this conversation* control,
  which appears once there is a conversation to send.

The card is inline in the transcript rather than a modal. A modal over a chat panel that is already
a dialog gives the page two focus traps, two `Escape` handlers and an `aria-modal` that is now wrong
about which of them owns the screen — and on a phone, where the chat fills the viewport, a second
layer over it conveys nothing.

### Letting the assistant offer it

The workflow can raise the same card itself. Have the reply contain a Markdown link to the fragment
`#n8nchat-handoff`, on a line of its own:

```
I can put you through to a colleague.

[Talk to a person](#n8nchat-handoff)
```

The link text is yours and is only ever shown, never read. Anything else after the fragment —
`#n8nchat-handoff-please` — is not a marker and renders as the link it is.

Two properties decided that shape:

- **It cannot collide with prose.** No model writing about anything at all emits a Markdown link to
  that exact fragment by accident, and unlike a bare sentinel (`[[handoff]]`, `::handoff::`, an HTML
  comment) there is no phrasing, quoted example or code sample in which it could appear innocently.
- **It degrades into something a person can read.** The workflow and the plugin are updated by
  different people at different times, so a bot will eventually emit this at a site still running an
  older widget. A sentinel would degrade into punctuation soup in the middle of a support answer;
  this degrades into an ordinary link whose text is the sentence you wrote, and the worst a visitor
  can do with it is jump to the top of the page.

An older widget therefore still shows the offer, in words, and nothing looks broken.

### The endpoints, and why they have no nonce

`POST /wp-json/n8n-chatbot/v1/lead` and `POST /wp-json/n8n-chatbot/v1/transcript`. Both are open to
anonymous visitors, because a visitor leaving their details is by definition not logged in.

The obvious defence — print a nonce into the page and verify it — is actively wrong here. A nonce
lives at most 24 hours and the page it is printed into is served by a full-page cache for as long as
that cache decides, so every visitor after the cache filled receives the same nonce and every one of
them receives it expired once it ages out. The form then works for whoever warmed the cache and
fails silently for everybody else, with a 403 nobody can reproduce because a developer's own
logged-in view is never cached.

What is there instead, in the order it is applied:

1. the feature has to be switched on at all;
2. `Origin` (falling back to `Referer`) has to be a host this site answers on;
3. a per-IP rate limit in a **fixed** hourly window — fixed rather than rolling, because
   `set_transient()` re-arms its expiry on every write, and a rolling window lets an office behind
   one NAT address hold its own lockout open indefinitely;
4. a honeypot field, named so that no browser autofill will ever complete it;
5. a floor on how long the page has been open;
6. validation, sanitisation and hard length caps on every field.

Beyond that: the recipient of a `/lead` is only ever the configured address, never a value from the
request; nothing a visitor typed reaches a mail header (`Reply-To` is deliberately not set — it is
the classic injection sink, and even done safely it hands a stranger the reply address for a
colleague's genuine answer); and every fragment of a transcript is escaped into an HTML body whose
content type is pinned for the duration of the send, because core applies the `wp_mail_content_type`
filter unconditionally and an SMTP plugin's global setting would otherwise decide how a stranger's
text is parsed in somebody's inbox.

**Nothing conversational is written to the database at either end.** The transcript arrives from the
browser, is emailed and is forgotten; the site has no copy to check it against, which is the whole
privacy position of the product and is why these endpoints are relays rather than stores.

Two things do write rows, and neither is conversational: the rate limiter's counters, which hold a
count and a hash of an address; and the answer-ratings tally written by `/feedback`, which holds a
running count of thumbs up and thumbs down plus the last fifty `{rating, page URL, timestamp}`
entries. That row deliberately carries **no session id, no message id and no message text** — a
tally that could be joined back to one visitor's conversation would be the conversation log this
product has decided not to keep. Anything richer is available through the `n8nchat_feedback` action,
which fires with the full payload before anything is stored and writes nothing itself.

## Accessibility

Built in rather than retrofitted. `@n8n/chat` rendered its launcher as a bare `<div onClick>` — no
role, no tabindex, no accessible name, which is WCAG 2.1.1 and 4.1.2 at Level A and a procurement
blocker for public-sector clients under the European Accessibility Act. 1.x patched what it could
from a MutationObserver and its own README admitted the result was not audit-clean.

- A real `<button>` launcher with `aria-expanded`, `aria-haspopup` and a name that reflects both
  open state and unread count.
- `role="dialog"`, and `aria-modal` **only** when the window actually covers the screen — claiming
  it on a desktop corner panel would tell a screen reader the rest of the page is inert when it
  plainly is not.
- A focus trap while full-screen, `Escape` to close, and focus returned to the launcher.
- `role="log"` with `aria-live="polite"` and `aria-atomic="false"` on the transcript, and one
  announcement of the finished reply rather than one per streamed token.
- `prefers-reduced-motion` removes every animation. `forced-colors` keeps the send button and the
  visitor's own messages visible in Windows High Contrast.
- 24×24 CSS px minimum targets (WCAG 2.2 SC 2.5.8), 44px in the full-screen composer.
- 16px minimum input font, so iOS Safari does not zoom the page the moment the field is focused.

Still to do: a full axe-core pass and a manual screen-reader run are listed in the plan, not done.

## Privacy and consent

- **Nothing conversational is stored on the WordPress site.** Conversations live in the portal, fed
  by the workflow's own logging node.
- **Remember a conversation for** sets an idle TTL, after which the session, transcript and open
  state are dropped — so the next person at a shared machine starts clean. **Setting it to 0 writes
  nothing to the browser at all**, and purges anything an earlier setting left.
- **Consent mode** (off by default) has two useful settings: store only once the visitor sends a
  message, or wait for a named consent signal (a cookie name, or a dotted path to a value on
  `window` such as `CookieYes.consent.functional`). Under either, the widget still works — the
  conversation lives in memory for the page and nothing is written down.
- **Answer ratings are counted, not logged.** A thumbs up or down writes to a running tally and
  records which page the visitor was on — enough for an owner to see that answers on a particular
  page are being marked wrong, and not enough to identify anyone. The settings screen shows the
  split and the pages behind recent thumbs-down.
- **The handoff card and the transcript email store nothing either.** What is typed into the card is
  posted and discarded; the transcript is read out of the browser's own copy. Neither endpoint
  writes a row. Under the "store once they send" consent mode, submitting the card unlocks storage
  on the same reasoning a sent message does — volunteering a name and an email address to be
  contacted is at least as unambiguous an act — and under every other mode it changes nothing.

## Multisite

Settings are per-subsite. Client state is namespaced with a **site scope** — a short hash of the
blog ID plus the webhook URL and bot ID — because `localStorage` is scoped by the browser to origin,
not path. On a **subdirectory** multisite every subsite is one storage area while each has its own
webhook, so without this subsite B would resume subsite A's conversation against B's backend.

The session id itself lives at a fixed key (so a conversation started under 1.x survives the
upgrade), so that one slot is treated as *claimable*: whichever scope last owned it is recorded, and
arriving under a different one drops the conversation rather than resuming it. On single sites and
subdomain multisite an *unowned* session is adopted, which is what carries a visitor who was
mid-conversation across the 2.0 upgrade.

Repointing a site at a different webhook or bot changes the scope, which retires conversations
belonging to the old backend instead of replaying them at the new one.

## Filters

| Filter | Use |
|---|---|
| `n8nchat_boot_config` | The whole widget configuration before it is printed. Replaces 1.x's `n8nchat_chat_config`, which described a third-party option object. |
| `n8nchat_schema` | Add a setting. That is enough for it to be stored, sanitised, rendered on both admin paths and cleaned up on uninstall. |
| `n8nchat_tokens` | The derived design tokens — the supported way to theme beyond what the settings expose. |
| `n8nchat_active` | Whether the widget renders on this request, for anything the page rules cannot express. |
| `n8nchat_options_page` | The ACF options page slug to attach to. |
| `n8nchat_uses_acf` | Force the native settings path. Can only narrow, never widen. |
| `n8nchat_presets` | What each style preset sets, beyond the preset value itself. |
| `n8nchat_preview_reply` | The canned Markdown the admin preview answers with. |
| `n8nchat_sanitize_options` | Last word on sanitisation. Anything added must be idempotent. |
| `n8nchat_allowed_origins` | Hosts the lead and transcript endpoints accept. For a domain alias, a staging hostname or a headless front end on its own domain. |
| `n8nchat_client_ip` | The address the rate limiter counts. `REMOTE_ADDR` by default; set this only if a trusted proxy in front of the site puts the real client somewhere else. |
| `n8nchat_rest_limits` | Rate limits, the timing floor and the field length caps. |
| `n8nchat_lead_recipient` | Where a lead is emailed, after the setting and the admin-address fallback have been resolved. |
| `n8nchat_lead_payload` | The JSON posted to the secondary handoff webhook. |

## Tests

Seven suites, run by CI on every push and again before a release zip is built. Six need nothing
installed; the seventh needs a browser and skips itself without one:

```bash
php  tests/schema.php          # the schema, the sanitiser, and the contrast guarantees
php  tests/store-migration.php # ACF <-> native settings-store migration
php  tests/rest.php            # the lead and transcript endpoints, and every guard on them
node tests/storage-scope.mjs   # per-site scoping, idle expiry, consent
node tests/markdown.mjs        # the renderer, and its security contract
node tests/stream-parser.mjs   # the n8n wire format
node tests/browser/run.mjs     # the widget itself, driven in a real browser
```

Most of them exist because the mechanism they cover fails **silently** on a live site. A mis-migrated
store serves the wrong webhook; unscoped client state hands one tenant's conversation to another;
a sanitiser that is not idempotent corrupts settings during a store flip; a response mode the parser
does not recognise renders an empty bubble; and a Markdown renderer that leaks a tag executes
script on a client's site. None of them raises an error, and none is visible from a rendered page.

`tests/rest.php` is the exception and covers the opposite risk. Its failures are anything but
silent — an origin check that lets another domain through, a rate limiter that counts nothing, a
form field that reaches a mail header — but they are heard first by the client's host, as a
suspension notice, and by then the release has auto-installed itself everywhere.

`tests/browser/` covers what none of the others can see. It serves a fixture page — a deliberately
hostile host theme, the theme block generated from `inc/theme.php`, and a mock n8n Chat Trigger that
streams NDJSON split at random byte offsets — and drives the real widget in it. Everything it
asserts is a DOM state machine or a layout fact: an HTML error page rendered as a reply, a launcher
announcing "Open chat" while the chat is open, a window that could not be un-expanded, an empty
bubble for the length of a retrieval, a composer that collapsed to nothing. Every other suite passed
on the day all six were found by hand.

Playwright is deliberately not a dependency of this repo, and there is no `package.json` here. The
runner looks for it locally, globally and in the npx cache, and if it cannot launch a browser it
says so and exits 0 rather than blocking anyone:

```bash
npx playwright install --with-deps chromium   # once
node tests/browser/run.mjs 'bug 4'            # just the tests whose title matches
```

`tests/` is excluded from the release zip, browser fixture included.

## Updates

The plugin updates itself through the bundled
[Plugin Update Checker](https://github.com/YahnisElsts/plugin-update-checker), from a **public**
repository — [`dan-w-web/n8n-chatbot-updates`](https://github.com/dan-w-web/n8n-chatbot-updates) —
that holds no source, only the zip CI builds for each release.

**Nothing needs configuring on a client site, and no credential is stored there.**

That is the whole reason for the separate repository. Checking a *private* repo means the check must
authenticate, which meant a GitHub personal access token on every site — in `wp-config.php` or in
the database. Three problems, none hypothetical:

- a live credential with repository read access sat in the config of every site running the plugin,
  surviving every backup, export and migration those sites ever made;
- fine-grained tokens expire, so every site had a date on which its updates would stop;
- and the failure was **silent**. The check returned nothing and the Plugins screen showed the site
  as up to date. Half of `inc/updates.php` used to be machinery for noticing that.

A public channel removes all three, and it does so **without moving the expiry somewhere else**.
The credential CI uses to publish there is an SSH **deploy key** (`MIRROR_DEPLOY_KEY`), not a
personal access token: deploy keys do not expire, are scoped to the one public repository they were
issued for, and can do nothing but write there. A PAT would have been fewer moving parts and would
have kept the same problem — "the token expired again" — just rarer.

CI pushes the artifact and a tag to the channel over SSH; the channel's own `publish.yml` turns that
tag into a release using its automatic `GITHUB_TOKEN`, so nothing in this arrangement holds
release-creating permissions for long. (A push authenticated with `GITHUB_TOKEN` would not trigger
that workflow; one authenticated with a deploy key does — which is the detail the whole thing rests
on.)

**Upgrading from 2.0.x:** the stored token is deleted from the database on the next admin request.
A `W_WEB_CHATBOT_UPDATE_KEY` constant left in `wp-config.php` is never read again and can be removed
whenever convenient. Revoke the tokens themselves at GitHub — nothing uses them now.

The plugin still raises an admin notice when an update *check* fails, because that can still happen:
GitHub rate-limits unauthenticated requests to 60 an hour per IP, and several client sites on one
shared server share an address.

### Cutting a release (maintainer)

1. Bump the version in **two** places in `n8n-chatbot.php`: the `Version:` header and the
   `N8NCHAT_VERSION` constant.
2. Commit, then create a GitHub Release tagged to match.
3. The `Build release zip` Action builds `n8n-chatbot.zip`, attaches it here, and mirrors it to the
   public update channel. **The mirror step is what client sites actually see** — it is deliberately
   not `continue-on-error`, because a release that exists here but not there is invisible to every
   site, and would only surface weeks later as "why has nobody got the fix".

CI fails the release build if the tag, the header and the constant disagree, because that failure
was invisible: the update checker re-reads the header from the tagged commit and lets it override
the tag, so tagging `v1.3.5` with a `1.3.4` header produced a green build, a correct-looking
release, and an update that was never offered to a single site.

## Not implemented

**Structured replies** — quick-reply buttons, cards and inline forms. These need an agreed extension
to what the workflow emits, rather than the single marker `#n8nchat-handoff` gets away with, so they
are a change in the platform repo as much as here.

**Per-reply follow-up suggestions.** The chip row appears on the empty state only. Populating it
after a reply means the workflow suggesting the follow-ups, which is the same conversation as above.

**File attachments and voice input were removed in 2.0.** Both had settings, both were passed to the
widget, and neither was ever read by a single line of it — so a site owner could switch them on and
watch nothing happen. Their names are retired rather than reused, and `uninstall.php` still sweeps
their rows, so if either is built properly later it can return under the same name.
