<?php
/**
 * Plugin Name:       n8n Chatbot Widget
 * Plugin URI:        https://wwebdesign.co.uk/
 * Description:        Embeds an n8n chat widget (window mode) with custom branding, sender
 *                     labels, a "New chat" button and a streaming-aware copy button. Theme-
 *                     independent. Works with or without ACF: configure it on the Site Options
 *                     → Chatbot tab when an ACF options page is present, otherwise on the
 *                     plugin's own top-level "Chatbot" settings screen.
 * Version:           2.1.1
 * Requires at least: 6.3
 * Requires PHP:      7.4
 * Author:            W Web Design
 * Author URI:        https://wwebdesign.co.uk/
 * License:           GPL-2.0-or-later
 * Text Domain:       n8n-chatbot
 * Update URI:        https://github.com/dan-w-web/W-Web-N8N-Chatbot
 *
 * Originally lived in the Fire Sector Confederation theme's "code injection" option; split
 * into a standalone plugin so it can be reused on any site. The per-site values (webhook URL,
 * titles, brand colour, labels) are stored in wp_options and everything else is shared CSS/JS.
 *
 * ACF is OPTIONAL. When an ACF (Pro) options page is registered with the slug returned by the
 * `n8nchat_options_page` filter (default "fsc-site-options", the FSC theme's Site Options page),
 * the plugin adds a "Chatbot" tab there and reads via ACF. Otherwise it registers its own
 * top-level "Chatbot" admin page (WordPress Settings API) and reads from a plain option. The
 * `n8nchat_uses_acf` filter can narrow that detection (force the native path) but cannot conjure
 * ACF into existence — see `n8nchat_uses_acf()` below. Switching a configured site from one path
 * to the other carries the settings across once, automatically (see inc/settings.php).
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Duplicate-copy guard. A leftover "n8n-chatbot-old/" left behind mid-rollback, or a client
 * uploading the zip twice so WordPress unpacks it to "n8n-chatbot-2/", means this bootstrap runs a
 * second time. Both copies then declare the same functions, and PHP's answer to that is a fatal —
 * "Cannot redeclare n8nchat_defaults()" — which white-screens the front end AND wp-admin at once,
 * leaving FTP as the only way back in.
 *
 * THIS FILE MUST DECLARE NO FUNCTIONS. That is the whole mechanism, and it is not obvious.
 *
 * PHP EARLY-BINDS unconditional top-level function declarations when a file is COMPILED, which
 * happens in full before any statement in it executes. So a `return` here — however early — cannot
 * prevent a second copy's declarations colliding with the first's: the fatal happens at compile
 * time and this line is never reached. Until 2.0 the guard sat above five such declarations and
 * therefore did nothing at all; it was verified broken on a real site that had two copies on disk.
 *
 * Everything the plugin declares now lives behind the `require_once` calls below, which are
 * runtime statements. A second copy returns here, never reaches them, and is genuinely inert.
 *
 * The sentinel is the CONSTANT rather than `function_exists( 'n8nchat_defaults' )` for a related
 * reason: with early binding, that function already exists inside the FIRST copy by the time this
 * line runs, so a function_exists() bail would disable the plugin on every site. Constants are
 * defined at runtime, so only a genuine second copy ever sees this as true.
 */
if ( defined( 'N8NCHAT_VERSION' ) ) { return; }

// Unconditional: the duplicate-copy guard above has already returned if this exists. The rest are
// wrapped defensively so a host or wp-config.php that pre-defines one doesn't trigger a notice.
define( 'N8NCHAT_VERSION', '2.1.1' );

if ( ! defined( 'N8NCHAT_FILE' ) ) { define( 'N8NCHAT_FILE', __FILE__ ); }
if ( ! defined( 'N8NCHAT_DIR' ) ) { define( 'N8NCHAT_DIR', plugin_dir_path( __FILE__ ) ); }
if ( ! defined( 'N8NCHAT_URL' ) ) { define( 'N8NCHAT_URL', plugin_dir_url( __FILE__ ) ); }

// Single wp_options row backing the native (non-ACF) settings path.
if ( ! defined( 'N8NCHAT_OPTION' ) ) { define( 'N8NCHAT_OPTION', 'n8nchat_options' ); }


/**
 * Load translations before anything asks the schema for a label.
 *
 * `init` priority 0, not `plugins_loaded`: since WordPress 6.7 a translation call made before
 * `init` triggers a _doing_it_wrong() notice about loading a text domain too early, and every
 * label and description in inc/schema.php is a __() call. Priority 0 puts this ahead of
 * n8nchat_migrate_schema() (init 1), ACF's own `acf/init` (fired from init 5) and
 * n8nchat_sync_stores() (init 99) — which between them are every path that reads the schema.
 */
add_action( 'init', function () {
	load_plugin_textdomain( 'n8n-chatbot', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}, 0 );

// Order matters. schema.php declares every setting; core.php resolves them; theme.php derives
// appearance from the result. All three are read by the files after them at include time as well as
// at runtime. Every one of these is a RUNTIME require, which is what lets the guard above work.
require_once N8NCHAT_DIR . 'inc/schema.php';
require_once N8NCHAT_DIR . 'inc/core.php';
require_once N8NCHAT_DIR . 'inc/theme.php';
require_once N8NCHAT_DIR . 'inc/settings.php';
require_once N8NCHAT_DIR . 'inc/native-settings.php';
require_once N8NCHAT_DIR . 'inc/render.php';
// After native-settings.php, which declares the n8nchat_mb_substr() the endpoints truncate with.
require_once N8NCHAT_DIR . 'inc/rest.php';
require_once N8NCHAT_DIR . 'inc/updates.php';

// The settings screen and its live preview, in wp-admin only. Every hook they register fires
// nowhere else, so on a front-end request these two files would be parsed for nothing — and this
// plugin's whole 2.0 argument is that a page view nobody interacts with should cost almost nothing.
// is_admin() is true for admin-ajax.php and admin-post.php as well as for a rendered screen, which
// between them are the only three contexts either file answers in.
if ( is_admin() ) {
	require_once N8NCHAT_DIR . 'inc/admin/page.php';
	require_once N8NCHAT_DIR . 'inc/admin/preview.php';
}
